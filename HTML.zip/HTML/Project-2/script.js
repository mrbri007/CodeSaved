let name = "shubham";
let name1 = "Rohan";
// it is global scope 
let name2 = "Sagar";
let name3 = "harry";
let morn = "Good morning";

// function myfunction(name, morn){
function myfunction(name, morn="hello world")  // morn ki value default value hai
{
    let name1 = "local or block scope and only function know and does not affect outside"
    console.log(name + " is a good boy");
    console.log(morn + " " + name);
};  

myfunction(name, morn);
myfunction(name1, morn);
myfunction(name2, morn);
// myfunction(name3, morn);
myfunction(name3,);

// console.log(person1 + "is a good boy");
// console.log(person2 + "is a good boy");
// console.log(person3 + "is a good boy");
// console.log(person4 + "is a good boy");