export {car } from "./script1.js"
export {network } from "./script1.js"