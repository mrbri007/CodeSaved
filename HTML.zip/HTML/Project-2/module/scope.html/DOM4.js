// function myfunction(){
//     alert("Oops ! there is sno error occured")
// }


// document.getElementById("main2").onclick = para
// document.getElementById("main2").onmouseenter = para
// function para(){
//     document.getElementById("main2").style.backgroundColor = 'lightgreen'
// }

// document.getElementById("main2").onmouseenter = para
// document.getElementById("main2").onclick = para
// document.getElementById("main2").addEventListener('click', para)
// document.getElementById("main2").addEventListener('mouseenter', para);
// document.getElementById("main2").addEventListener('click', para);
// document.getElementById("main2").addEventListener('click', function(){
// document.getElementById('main2').style.border = '2px solid #333'
// this.style.border = '2px solid #333'   // this : id ko refer karta hai 
// })

// function para(){
    // document.getElementById("main2").innerHTML = " The metaverse is the next evolution of social connection. Our company's vision is to help bring the metaverse to life, so we are changing our to reflect our commitment to this future."
// }

// document.getElementById("main2").addEventListener('click', functionName, usecaptureEvents(true and false));


// document.querySelector("#inner").addEventListener('click', function(){
// document.getElementById("inner").addEventListener('click', function(){
    // alert(" Oops ! there is something error found");
// })
// },true)
// },false)

// document.querySelector("#outer").addEventListener('click', function(){
// document.getElementById("outer").addEventListener('click', function(){
    // alert("there is something error found");
// })
// },true)
// },false) // default

// document.getElementById("inner").addEventListener('click', para)
// function para(){
//     alert("Oops ! there is something error found")
// }

// document.getElementById("main2").addEventListener('mouseleave', para)
// function para(){
//     document.getElementById("main2").style.backgroundColor = 'red'
// }

// document.getElementById("main2").addEventListener('click', remove)
// function remove(){
//     document.getElementById("main2").removeEventListener('mouseleave', para)
// }

















