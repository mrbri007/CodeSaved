// Regular expression 
// Basic function 
// Metacharacter Symbols 
// Character sets  []

// let reg = /^h/
// reg = /^h/i
// reg = /harry/ 
// reg = /h[a-z]rry/   // any character between a to z ( shortcut way) instead of abcdefghijkl
// reg = /h[iry]rry/  // can be either i or r or y 
// reg = /h[iay]rry/  
// str = "harry bhai "
//  reg = /h[^iay]rry/   // ^ means  NoT : can not be ant of i, a or y 
//  reg = /h[^iay]rr[yYu]/  y an dY is case- sensitive
// str = "hlrrY bhai "
//  reg = /h[^iay]rr[tu]/  
//  reg = /h[a-z A-Z]rr[yu 0-9]/    // a-z or A-Z 
 // str = "hArrY bhai "
 // str = "hArru bhai "
 // str = "hArr9 bhai "
//  reg = /h[a-z A-Z]rr[yu 0-9][11-20]/    
 // a-z or A-Z & multiple character 3 or 4 set laga sakte hai 
//  character set ko square bracket ki help se bante hai 
//  str = "hArry11 bhai "    // y ke bad ek aur character hona chahiye


// Quanitifiers in regex : quanity{}
// reg = /har{2}y/  // r can occur two times  
// str = "harry bhai "
// reg = /har{3}y/ 
// reg = /har{0,3}y/         // 0 or 1, 2, 3 times 
// str = "harrry bhai "  // 3 times
// str = "hay bhai "       //  0 times

// grouping in regex : use parentless () for grouping
// reg = /har{2}/  // wrong 
// reg = /(har){2}/   // 2 is quanity & har mera two times occur ho i'm saying   
// str = "harharr bhai "  
// str = "harhar bhai " 

// reg = /(har){2}([0-9]r){3}/   
// reg = /(har){2}([0-9]r){2}/   
// str = "harhar1r5r bhai " 

// result = reg.exec(str);
// console.log(result);

// if (reg.test(str)) {
//   console.log(`Absolutely Yes !`);
// } 

// else {
//   console.log(`Absolutely Not !`);
// }
