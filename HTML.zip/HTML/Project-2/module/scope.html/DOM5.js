// Metacharacter symbol

// reg = /^The/; // ^ : if string start with : true
// reg = /^Thefvdsvsd/; // ^ : if string doesn't start with : false

// reg = /tion.$/; // ^ : if string end with : true
// reg = /tion$/; // ^ : if string  doesn't end with : false

// reg = /metaverse/; // if match : true
// reg = /metavecscsrse/; // if not match : false

// reg = /me.averse/; // matches any one character
// reg = /h*rry/; // matches 0 to more charcter

// reg = /ha?rryi?/; // character with ? is : optional 
// reg = /ha\*rry/; //  it sis not metacharacte symbol, is text 

// let reg = /metaverse/
// console.log(reg);

// str =
//   "The metaerse is the next evolution of social connection."; // for . charchater : one character
//   "The hgyhyftrry is the next evolution of social connection."; // for . charchater : 0 to more character
//   "The hrryi is the next evolution of social connection."; // for . charchater : 0 to more character
  // "The ha*rry is the next evolution of social connection."; // for . charchater : 0 to more character
//   "The metaverse is the next evolution of social connection."; // for . charchater
// str = "The metaverse is the next evolution of social connection."
// result = reg.exec(str);
// console.log("Return array", result);

// // reg = /metavvdvderse/   // Eles testing
// if (reg.test(str)) {
//   console.log(`${reg.source} Absolutely Yes ! ${str}`);
// } 

// else {
//   console.log(`${reg.source} Absolutely Not ! ${str}`);
// }
