// // set and get both we can do with queryselector
// x = document.querySelector(".container5")   
// x = document.querySelector(".container5").getAttribute("class")  
// x = document.querySelector("#main3") 
// console.log(x);


// // where array occur : indexing kar sakte ho and innerhtml 
// x = document.querySelectorAll("#main1 ul")
// x = document.querySelectorAll("#main1 ul li")
// x = document.querySelectorAll("#main1")[0]
// x = document.querySelectorAll("#main1")[0].innerHTML  
// // Id

// x = document.querySelectorAll(".container1 ul")
// x = document.querySelectorAll(".container1 ul li")
// x = document.querySelectorAll(".container1 ul li")[1]
// x = document.querySelectorAll(".container1 ul li")[1].innerHTML
// x = document.querySelectorAll(".container1 ul li")[1].innerHTML = "Facebook"
// x = document.querySelectorAll(".container5")
// x = document.querySelectorAll(".container5")[1]
// x = document.querySelectorAll(".container5")[1].innerHTML 
// // Class  

// x = document.querySelectorAll("div ul")
// x = document.querySelectorAll("div ul li")
// x = document.querySelectorAll("div")[1]
// x = document.querySelectorAll("div")[1].innerHTML  
// // Tag
// console.log(x);

