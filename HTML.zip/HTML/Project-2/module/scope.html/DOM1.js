// let x = document.body

// DOM : Get method 
// x = document.getElementById("header")
// x = document.getElementById("header").innerText
// x = document.getElementById("header").innerHTML
// x = document.getElementById("main2").innerText
// x = document.getElementById("main2").innerHTML 
// innerHTML : Return with html 
// innerText : Return without html element
// console.log(x);

// x = document.getElementById("header").getAttribute('id')
// x = document.getElementById("header").getAttribute('class')
// x = document.getElementById("header").getAttribute('style')
// x = document.getElementById("header").getAttribute('onclick')
// Return = value 
// console.log(x);

// x = document.getElementById("header").getAttributeNode('id')
// x = document.getElementById("header").getAttributeNode('class')
// x = document.getElementById("header").getAttributeNode('style')
// x = document.getElementById("header").getAttributeNode('onclick')
// Return = property : value 
// console.log(x);

// x = document.getElementById("header").attributes
// x = document.getElementById("header").attributes[3]
// x = document.getElementById("header").attributes[3].name
// x = document.getElementById("header").attributes[3].value
// Return = all property with value : array value
// console.log(x);



// DOM : Set method 
// x = document.getElementById("header").innerText = "Hello world"
// x = document.getElementById("header").innerText = "<p> Hello world </p>"  // Doesn't work
// x = document.getElementById("header").innerHTML = "Hello world"
// x = document.getElementById("header").innerHTML = '<input type="button" value="SUMBIT"> </input>'
// console.log(x);

// x = document.getElementById("header").setAttribute("id", "set1")
// x = document.getElementById("header").setAttribute("class", "set2")
// x = document.getElementById("header").setAttribute("style", "color : red")
// x = document.getElementById("header").setAttribute("onClick", "header()")
// console.log(x);

// x = document.getElementById("header").attributes[0].value = "code1"
// x = document.getElementById("header").attributes[1].value = "code2"
// x = document.getElementById("header").attributes[2].value = "color : blue"
// x = document.getElementById("header").attributes[3].value = "code3()"
// console.log(x);

// x = document.getElementById("header").removeAttribute("id")
// x = document.getElementById("header").removeAttribute("class")
// x = document.getElementById("header").removeAttribute("style")
// x = document.getElementById("header").removeAttribute("onClick")
// No set and no get only remove
// console.log(x);
