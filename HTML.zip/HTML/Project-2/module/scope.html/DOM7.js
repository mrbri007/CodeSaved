console.log('Shorthand charcater classes in (Regualr expression)');
// charcater classes

// reg = /\wrr/     // word charcter : _ or number and alphabet must be single
// reg = /\war/    
// reg = /\w+ar/     // \w+ : one or more word character
reg = /\wbhai/      // non word charcter : space
// str = "harry bhai" 
// str = "9arry bhai" 
// str = "_arry bhai" 
// str = "*arry bhai"   // false
// str = "hhjsfujyv%xxvharry bhai"   // % is not an character
// str = "hhjsfujyv%xxvharry bhai"   // % is not an character
str = "harry bhai" 

result = reg.exec(str);
console.log(result);

if (reg.test(str)) {
  console.log(`Absolutely Yes !`);
} 

else {
  console.log(`Absolutely Not !`);
}







