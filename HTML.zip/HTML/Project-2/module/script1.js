// Method 1
// export { message, user, obj } 

// Method 2
// export let message = "Hello world";
// export function user(Guys){
//     // console.log(`This is too much intresting ${Guys}`);
//     return `This is too much intresting ${Guys}`;
// }

// export const obj = {"Students":[
//             {"Firstname":"Brijesh","age":20,"class":"FYJC"},
//             {"Firstname":"Arvind","age":25,"class":"SYJC"}
//         ]}

        // console.log(obj)


// export default function(){
//     console.log('Hello world');
// }

export function car () {
    console.log('ES6 : Module');
}



export const network = {"Distribution":[
    "Manufacture", "wholesaler", "retailer"
]}