// import {message , user} from "./script1.js";
// import {message} from "./script1.js";
// import {user as us } from "./script1.js";
// import {obj} from "./script1.js";

// document.body.innerHTML = message;
// console.log(message)

// user("Guys")
// console.log(user("guys"));
// console.log(us("guys"));

// let x = JSON.stringify(obj)
// console.log(x)

// const objson = '{"Students":[{"Firstname":"Brijesh","age":20,"class":"FYJC"},{"Firstname":"Arvind","age":25,"class":"SYJC"}]}'
// const myobj = JSON.parse(objson)
// console.log(myobj);
// console.log(typeof myobj);

// Most important 
// Use a comman name to access all the javascript variable, function and class and so on  from export file to import file
// import * as tech from "./script1.js"

// console.log(tech.user("guys"));

// console.log(tech.message);
// console.log(tech.obj);

// let x = JSON.stringify(tech.obj)
// console.log(x)

// let s = JSON.parse(x)
// console.log(s);

// import {default as yt } from "./script1.js"
// import  yt  from "./script1.js"
// yt()

// import{car} from "./script1.js"
// import {car} from "./link.js"
// car()

// import {network} from "./link.js"
// console.log(" Aggregate Module", network);












