import React from 'react'

export default function About() {
  return (
	<>
		<div>
			<h1>jjjjjjjjjjjj</h1>
			<p>llllllllllllllll</p>
		</div>
	</>
  )
}
