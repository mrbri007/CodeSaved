// Deault import
// Anyname for importing default function  
// import random_name from './module1.mjs'
// console.log(random_name)

// Named import
// Particular_Name for importing default function  
// import a from './module1.mjs'
// console.log(a)

// Named and Deault import
// import random_name, {b,c,d} from './module1.mjs'
// console.log(random_name)
// console.log(b)
// console.log(c)
// console.log(d)
