const a = 'Lorem_1'
const b = 'Lorem_2'
const c = 'Lorem_3'
const d = 'Lorem_4'

// export default a
// export default b
// export default c
// export default d

// export {a}
// export {b}
// export {c}
// export {d}

export default a
export {b}
export {c}
export {d}
