// ----- via installation(create-react-app)[Pre-built-package]
import React from 'react';
import ReactDOM from 'react-dom/client';

import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';


// ----- Transfering COMPONENTS in index.html with element with id 'root
const root = ReactDOM.createRoot(document.getElementById('root'));

// ----- Adding COMPONENTS in index.js
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

reportWebVitals();

// NOTE : Used only to ADD and TRANSFER components.That's it.