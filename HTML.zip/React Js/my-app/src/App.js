// // To use <React.Fragment>: IMPORT React
// import React from 'react';
// import './App.css';



// // Creating COMPONENTS 

// // ----------
// // JSX allows us to write HTML directly within the JavaScript code.
// const myElement1 = <h3>I Love JSX!</h3>;
// // const myElement1 = "<h1>I Love JSX!</h1>";


// // ----------
// // To write HTML on multiple lines, put the HTML inside parentheses():
// const myElement2 = (
//   <ul>
//     <li>Lorem ipsum dolor sit amet consectetur adipisicing.</li>
//     <li>Lorem ipsum dolor sit amet consectetur adipisicing.</li>
//     <li>Lorem ipsum dolor sit amet consectetur adipisicing.</li>
//   </ul>
// );


// // ----------
// // Wrap two paragraphs inside one DIV element:
// const myElement3 = (
//   <div>
//     <p>Lorem ipsum dolor sit amet consectetur adipisicing.</p>
//     <p>Lorem ipsum dolor sit amet consectetur adipisicing.</p>
//   </div>
// );
// // Will Throw Error 
// // const myElement3 = (
// //   <p>I am a paragraph.</p>
// //   <p>I am a paragraph too.</p>
// // );
// // Alternatively, you can use a "fragment" to wrap multiple lines.
// // A fragment looks like an empty HTML tag: <></>. 
// // const myElement3 = (
// //   <>
// //     <p>I am a paragraph.</p>
// //     <p>I am a paragraph too.</p>
// //   </>
// // );


// // ----------
// // To be able to use conditional statements in JSX, you should put the if statements outside of the JSX, or you could use a ternary expression instead:
// const x = 20;
// let myElement5 = "false_state"; 
// if (x < 10) {
//   myElement5 = "true_state";
// }


// // ----------
// // JavaScript in JSX with Curly Braces
// let myElement6 = "Lorem ipsum dolor sit amet consectetur adipisicing."



// // ----------
// // JSX follows XML rules, and therefore HTML elements must be properly closed.
// const myElement4 = <input type="submit"/>;

// // NOte :it supports heading/input/conditional/string/list/




// // ----- COMPONENTS : 1 
// function App() {
//   return (
//     <React.Fragment>
//       <div> 
//         <h1>Javscript library : React</h1><br/>
//         <img src="https://pbs.twimg.com/media/FyqzpqnaUAI2apz?format=jpg&name=large" alt="Hedy Lamarr" width='600px'/>
//         <br />
//         <ul>
//           <li>Lorem ipsum dolor sit amet consectetur adipisicing.</li>
//           <li>Lorem ipsum dolor sit amet consectetur adipisicing.</li>
//         </ul>
//         <br />
//         <p>Ternary expressions : {(x < 10 ? "true_state" : "false_state")}</p>
//         <p>Expressions in JSX : {9+56}</p>
//         <br />

//         <p>{myElement1}</p><br/>
//         <p>{myElement2}</p><br/>
//         <p>{myElement3}</p><br/>
//         <p>{myElement6}</p><br/>
//         <p>{myElement5}</p><br/>
//         <p>{myElement4}</p><br/>


//       </div>
//     </React.Fragment>
//   );
// }
// export default App;





// // ----- COMPONENTS : 2 
// // function App() {
// //   return (
// //     <>
// //     </>  
// //   );
// // }
// // export default App;

import { BrowserRouter, Routes, Route} from "react-router-dom";
import React from 'react';
import './App.css'
import About from "./About";


function App() {
  return (
    <BrowserRouter>
      <Routes>
          <Route path="/" element={<div>Hello world</div>}/>
          <Route path="/about" element={<About/>}/>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
