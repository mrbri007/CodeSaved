import React, { useState, useCallback } from 'react';

const NavHooks6 = () => {
  const [count, setCount] = useState(0);

  const increment1 = () => {
    setCount(count + 1);
  };

  const increment2 = useCallback(() => {
    setCount(prevCount => prevCount + 1);
  }, []);

  console.log('ExampleComponent rendered');

  return (
    <div>
      <p>Count: {count}</p>
      <button onClick={increment1}>Increment 1</button>
      <button onClick={increment2}>Increment 2</button>
    </div>
  );
};

export default NavHooks6



// By using useCallback, you can optimize the performance of your components, especially when passing functions as props to child components. It helps to prevent unnecessary re-renders and ensures consistent behavior across renders.
// The key difference between useState and useCallback in terms of function re-rendering is that useState does not prevent the re-creation of function references, while useCallback memoizes and caches the function instance, allowing it to be reused across renders when the dependencies do not change. This can help optimize performance, especially when passing functions as props to child components.









// small Application = big Application
// useState =  useReducer
// useMemo =  useCallback
// teacher -- student 1 --- question solved by teacher (5min) --- output :15 
// teacher -- student 2 --- question solved by teacher (5min) Again --- output :15 
// teacher -- student 3 --- question solved by teacher (5min) Again --- output :15 
// but - using of usecallback and usememo
// teacher -- student -1--- question solved by teacher once (5min) --- stored output :15 
// teacher -- student -2--- question solved on paper and dekh le bhai(1sec)

// import React, { useState } from 'react';
// const MyComponent = () => {
	// 	// The items state represents a list of items.
	//   const [items, setItems] = useState(["Passed Successfully"]);
	//   const addItem = () => {
		//     const newItem = Math.floor(Math.random() * 10000000);
		//     setItems(prevItems => [...prevItems, newItem]);
		//   };
		
		//   return (
//     <div>
//       <button onClick={addItem}>Add Item</button>
//       <ul>
//         {items.map(element => (
//           <li key={element}>{element}</li>
//         ))}
//       </ul>
//     </div>
//   );
// };
// export default MyComponent;
// The addItem function is called when the "Add Item" button is clicked. It generates a random number and updates the items state by creating a new array with the previous items (using the spread operator ...) and appending the new item to it.
// const [count, setCount] = useState(null);

// function rerender hota automatically 