// import React, { useReducer } from 'react'

// const initialValue = 0;
// const reducer = (state, action) => {
// 		// console.log(state, action)
// 		// return state // it alwys return something

// 		if (action.type === "Increment") {
// 			console.log(state, action)
// 			return (state = state + 1);
// 		}
// 		if (action.type === "Drecrement") {
// 			console.log(state, action)
// 			let newnum = 0;
// 			(state >= 1) ? (newnum = state -1) : (newnum = 0)
// 			return newnum
// 		}
// 		return state; 

// 	};
	
// 	export default function NavHooks2() {
// 	const [state, dispatch] = useReducer(reducer, initialValue)

//   	return (
// 		<>
// 			<div>
// 				<h2>UseState Hook : {state}</h2>
// 				<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet, corrupti. Rerum fugiat, voluptatum minus iste fugit dolorem sequi nobis tempore est saepe, deserunt in distinctio ratione quaerat optio culpa facilis ab, doloremque cum eum.</p>
// 				<button type="button" 
// 						onClick={() => {dispatch({type : "Increment"})}}>Increment
// 				</button>
// 				<br/>
// 				<br/> 
// 				<button type="button" 
// 						onClick={() => {dispatch({type : "Drecrement"})}}>Drecrement
// 				</button>
// 			</div>
// 		</>
//   )
// }



import React, { useReducer } from 'react'
const initialValue = 0;
const reducer = (state, action) => {

		if (action.type === "Increment") {
			return (state = state + 1);
		}
		if (action.type === "Drecrement") {
			let newnum = 0;
			(state >= 1) ? (newnum = state -1) : (newnum = 0)
			return newnum
		}
		return state; 

	};
	
	export default function NavHooks2() {
	const [state, dispatch] = useReducer(reducer, initialValue)

	const incrementValue = () =>{
		dispatch({type : "Increment"})
	}
	const decrementValue = () =>{
		dispatch({type : "Drecrement"})
	}

  	return (
		<>
			<div>
				<h2>UseState Hook : {state}</h2>
				<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet, corrupti. Rerum fugiat, voluptatum minus iste fugit dolorem sequi nobis tempore est saepe, deserunt in distinctio ratione quaerat optio culpa facilis ab, doloremque cum eum.</p>
				<button type="button" onClick={incrementValue}>Increment</button>
				<br/>
				<br/> 
				<button type="button" onClick={decrementValue}>Decrement</button>
			</div>
		</>
  )
}






// The useReducer Hook is similar to the useState Hook.
// usestate = useReducer : used for state managment
// useReducer is more powerful and efficient than useState
// useState : better use for small application
// useReducer : better use for big application

// synatx
// return array of two element and accept two arguments
// const [stateVarible, dispatch] = useReducer(reducer, intialvalue)
// reducer function has two parameter : state and action 
// dispatch : updatedfunction
// stateVarible : intial value 
// kuch opertion perform karne ke liye hum dispatch ko call kareneg 
// and vo trigger karega reducer function and usme se vo action method of reducer function ans play with stata


// jab aap dispatch method ko call karoge to usme ek amdatory property hai type
// dispatch hai vo reducer ke andar action method ko call karega
// reducer function ke liye new file 
// Whenever a value changes(useState hook , useEffect hook), the component is re-rendered.

// The useReducer Hook returns the current stateand a dispatchmethod.
// multiple state ko mamange karne ke liye usereducer hota hai 
// intialvalue : objecr vslu holds but aawys

// reducer is a fuction that take in a state and actiona nd return new state 
//fucntion defien karte samaay : paarmeter

// to trigger action method : dispatch 
// state : current state : intialstate = sab ek hi hai 


// action and dispatch : relation hai dono mai
// state and dispatch : kuch bhi name likh sakte ho but conviction is 
// to triger action method : use of dispatch and kya perform karna hai vo type property se paat chlaeg actin ko 