import React, { useMemo, useState } from 'react'

export default function NavHooks5() {
	const [count, setCount] = useState(0);

	// Compute the square of the count on every render
	// const squareNumber = count * count;

	// Compute the square of the count using useMemo
 	const squareNumber = useMemo(() => {
    console.log('Computing square...');
    return count * count;
 	}, [count]);

  	return (
	<>
		<div>
			<h2>UseMemo Hook</h2>
			<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Architecto quibusdam optio impedit recusandae, velit nesciunt similique ipsa natus aspernatur hic et cupiditate laudantium sed ullam vitae sequi non consequatur id dolorum, reprehenderit facilis dolorem!</p>
		</div>
		<div>
    		<p>Count: {count}</p>
    		<p>Square: {squareNumber}</p>
    		<button onClick={() => setCount(count + 1)}>Increment</button>
   		 </div>
	</>
  )
}
 
// applicaltion ke performace ko increse and opitimize karna 
// same as useffect but having an differnce like isme hum data ko return kar sakte hai 
// data return nahi kar sakte hai in useEFfect
// const varibleName =  useMemo(callBack function , Array [Dependency])
// ........ Return the value ...........
// callback value ko hum varible mai store karenge
// jo value return ho rha hai hum varible mai store karenge
// usememo mai hum callback ki throigh hum data ko retur kar sakte hai and ek vairble mai store kar sakte ahI 

// n this version, the square calculation is directly performed in the component body, without using useMemo. Consequently, on each render, the square value will be re-computed, regardless of whether the count value has changed or not.
// While this may not pose a significant issue for simple calculations like squaring a number, it can become problematic for more complex computations or expensive operations. The unnecessary re-computations could lead to performance degradation and impact the responsiveness of your application.
// Therefore, when you have expensive computations or complex operations that depend on certain values and need to be optimized, using useMemo can help ensure that the calculations are only performed when necessary.











// import React, { useState, useMemo } from 'react';
// const MyComponent = () => {
//   const [firstName, setFirstName] = useState('');
//   const [lastName, setLastName] = useState('');
//   // Concatenate the first name and last name using useMemo
//   const fullName = useMemo(() => {
//     console.log('Computing full name...');
//     return (`${firstName} ${lastName}`);
//   }, [firstName, lastName]);
// //   }, [firstName]);
//   return (
//     <div>
// 	<h2>UseMemo Hook</h2>
// 	<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil dolores nisi aliquam sunt ipsum incidunt tenetur amet minus nam culpa? Nobis sapiente sed omnis deserunt optio cumque dolores numquam commodi, quisquam praesentium ipsum ipsam!</p>
//       <input
//         type="text"
//         placeholder="First Name"
//         value={firstName}
//         onChange={(e) => setFirstName(e.target.value)}
//       />
// 	  <br/>
// 	  <br/>
//       <input
//         type="text"
//         placeholder="Last Name"
//         value={lastName}
//         onChange={(e) => setLastName(e.target.value)}
//       />
//       <p>Full Name: {fullName}</p>
//     </div>
//   );
// };
// export default MyComponent;
// Whenever the firstName or lastName changes, the function inside useMemo will be re-evaluated
// This way, unnecessary concatenation operations and re-renders are avoided, optimizing the performance of the component.
// The useMemo Hook only runs when one of its dependencies update.
// The React useMemo Hook returns a memoized value.
// The useMemo and useCallback Hooks are similar. The main difference is that useMemo returns a memoized value and useCallback returns a memoized function.
// The useMemoHook accepts a second parameter to declare dependencies. The expensive function will only run when its dependencies have changed.


