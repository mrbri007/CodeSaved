// import React  from 'react'
// import{ useState } from 'react'

// export default function NavHooks1() {
// 	// const [count, setCount] = useState(0)
// 	// const IncrementValue = () =>{
// 	// 	setCount(count + 1)
// 	// }
// 	// const DecrementValue = () =>{
// 	// 	(count === 0) ? setCount(0) : setCount(count - 1)
// 	// }

// 	const [first, setfirst] = useState({
// 		fname : "",
// 		lname : "",
// 		email : "",
// 		password : "",
// 	})

// 	const userInputHandle = (e)=> {
// 		const userName = e.target.name
// 		const userValue = e.target.value
		
// 		// console.log(userName, userValue)
// 		// setfirst(e.target.value)
// 		// callback function : fetching object data from useState({})
		
// 		setfirst((prev)=>{
// 			return{...prev, [userName] : userValue } ; // previous state stored
// 			// return{[userName] : userValue } ;  // previous state not stored
// 		})
// 	}

//   return (
// 		// <>
// 		// <div>
// 		// 	<h2>UseState Hook : {count}</h2>
// 		// 	<button type="button" 
// 		// 			onClick={()=>
// 		// 			{setCount(count + 1)}}>Increment
// 		// 			</button>
// 		// 			<br />
// 		// 			<br/>
// 		// 	<button type="button" 
// 		// 			onClick={()=>
// 		// 			{setCount(count - 1)}}>Drecrement
// 		// 			</button> 
// 		// 	<button type="button" 
// 		// 			onClick={()=> (count === 0) ? setCount(0) : setCount(count - 1)}>Drecrement</button>
// 		// </div>
// 		// </>


// 		// <>
// 		// <div>
// 		// 	<h2>UseState Hook : {count}</h2>
// 		// 	<button type="button" 
// 		// 			onClick={IncrementValue}>Increment
// 		// 	</button>
// 		// 	<br />
// 		// 	<br/>
// 		// 	<button type="button" 
// 		// 			onClick={DecrementValue}>Drecrement
// 		// 	</button>
// 		// </div>
// 		// </>


// 		<>
// 		<div>
// 			<h2>UseState Hook</h2>
			
// 			<span>fName : </span>
// 			<input type="text" 
// 				   name="fname" 
// 				   value={first.fname}  
// 				   onChange={userInputHandle}/>
// 				   <br />
// 				   <br />
// 			<span>lName : </span>
// 			<input type="text" 
// 				   name="lname" 
// 				   value={first.lname} 
// 				   onChange={userInputHandle} />
// 				   <br />
// 				   <br />
// 			<span>Email : </span>
// 			<input type="text" 
// 				   name="email" 
// 				   value={first.email}  
// 				   onChange={userInputHandle}/>
// 				   <br />
// 				   <br />
// 			<span>Password : </span>
// 			<input type="text" 
// 				   name="password" 
// 				   value={first.password}  
// 				   onChange={userInputHandle}/>
// 				   <br /><br />
// 			<button type="submit">Submit</button>


// 			<p>Hey, {first.fname} {first.lname} </p>
// 			<h2>Welcome to uber App</h2>
// 			<p>Check your inbox <em>'{first.email}'</em> 
// 			and confirm your password <em>'{first.password}'</em></p> 
			
// 		</div>
// 		</>

//   )
// }


