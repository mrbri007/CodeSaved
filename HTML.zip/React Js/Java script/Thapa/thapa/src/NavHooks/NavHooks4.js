import React, { useEffect, useLayoutEffect, useState } from 'react'



export default function NavHooks4() {
  const [number, setNumber] = useState(0) 

  // // Runs on every render mens jaise si refresh kart hu tab  : old value  -- 0 -- ne wvalue 
  // useEffect(() => {
  //   if (number === 0 ) {
  //     setNumber(number + Math.floor(Math.random() * 10000))
  //   }
  // }, [number])
  
  useLayoutEffect(() => {
    if (number === 0 ) {
      setNumber(number + Math.floor(Math.random() * 10000))
    }
  }, [number])
  

  // Excution from top to bottom in multiple useeffect case
  // useEffect(() => {
  //   console.log("Passed Successfully : 1")
  // }, [])
  // useEffect(() => {
  //   console.log("Passed Successfully : 2")
  // }, [])
  // useEffect(() => {
  //   console.log("Passed Successfully : 3")
  // }, [])
  // useEffect(() => {
  //   console.log("Passed Successfully : 4")
  // }, [])
  // useLayoutEffect(() => {
  //   console.log("Passed Successfully : 5")
  // }, [])

  
  return (
	<>
    <div>
      <h2>UseLayoutEffect Hook </h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum et, reiciendis culpa, magnam ipsam autem nihil ullam hic voluptates eius maxime earum quae nobis deserunt vero perferendis quis pariatur atque debitis incidunt dolore voluptate!</p>
    </div>
    <p>Password Genertor : {number}</p>
    <button type="button" onClick={() => {setNumber(0)}}> Random Number</button>
  </>
  )
}







// but 99% mai hum useEffect ka use karte hai because of asynchrous
// useefect runs asynchrous and after a render is painted to the screen
// uselayputeffect runs synchrouous after a render but before the screen is updated 
// syantax and functionality sab kuch hai same hai dono ke 
// uselayouteffect screen mai data update hone se pahele hi vo background mai render ho jata hai 
// uselayouteffect and useffect mai sabse pahele uselayout chalega 
// The main difference between the useEffect hook and the useLayoutEffect hook is that the useEffect hook serves asynchronously, whereas the useLayoutEffect hook works synchronously. In simple words, we can say that the difference between useEffect and useLayoutEffect is in the time at which these functions are invoked.

// in case of useeffect : screen update hota hai and uske baad data display hota hai 
// in case of uselayoputeffect : screen mai data update hone se pahele hi vo bacakground mai update ho jata hai 

