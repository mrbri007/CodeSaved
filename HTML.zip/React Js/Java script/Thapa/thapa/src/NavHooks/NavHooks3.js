import React, { useEffect , useRef, useState} from 'react'

export default function NavHooks3() {
	// const [userInput, setserInput] = useState("");
	// const [count, setCount] = useState(0);

	// Warning: Maximum update depth exceeded. This can happen when a component calls setState inside useEffect, but useEffect either doesn't have a dependency array, or one of the dependencies changes on every render : infinite loop 
	// useState(setCount) --- re- render components --- useeffect call -- rerender
	// useState : Re-redirecting again
	// setcount ek usesate ka part hai and ye component ko update karke unko rerender kar dega and useffect bhi mai chalt ajayega
	// useState ko useEfect ke andar call ajkaroge to vo components ko re - render kar dega 
	// useEffect(() => {setCount((count) => count + 1)})
	// useEffect(() => {setCount((count) => count + 1)},[])

	// return object with preoperty : current  and it has intial value
	// re-render nahi hoga so no need to pass any dependeny
	// console.log(refHook)
	// const refHook = useRef(0) 
	// useEffect(() => {
	// 	refHook.current = refHook.current + 1  
	// });

	// useref name ek varible refHook means ek object define kit ahai  
	const inputRef = useRef()
	const domUpdate = () => {
		inputRef.current.focus()
		inputRef.current.style.backgroundColor = "red"
	}
  return (
	<>
		<div>
			<h2>useRef Hook</h2>
			<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Magni corrupti qui sequi autem esse neque aspernatur, tempora consequuntur! Rerum aut expedita blanditiis impedit, sed, minima voluptas commodi exercitationem nostrum iure, sapiente accusamus voluptate sequi.</p>
			{/* <span>UserName : </span> */}
			{/* <input type="text" 
				   value={userInput}
				   onChange={(e)=>setserInput(e.target.value)}/> */}
			{/* <p>Number of times components Rendering : {count}</p> */}
			{/* <p>Number of times components Rendering : {refHook.current}</p> */}
		</div>
		{/* you have to pass the refernce like jisme tumhe dom apply karn ahai  */}
		{/* iss reference ke through hum input feitld ke property add akrte sakte hai  */}
		<span>UserName : </span>
		<input type="text" ref={inputRef}/><br /><br />
		<button type="button" onClick={domUpdate}>Submit</button>
	</>
  )
}












// useRef ek obejct ko return karta hai with property called "current" and hum object ko directyl call nahi kar sakte hai and object is {render_Components}

// it creates a mutable varible which will npt re-render the componnets
// used to access the DOM element directly
// usestate/ useeffect : re-render karta hai 
// useefect
// Some examples of side effects are: fetching data, directly updating the DOM, and timers.
// The useEffect hook is called after the component has rendered
// This code will be executed after the component renders



// import React, { useEffect, useState } from 'react';
// const ExampleComponent = () => {
//   const [count, setCount] = useState(0);
//   useEffect(() => {
//     // This function will be executed after each render
//     // Update the document title
//     document.title = `Count: ${count}`;
//   });
//   return (
//     <div>
//       <p>Count: {count}</p>
//       <button onClick={() => setCount(count + 1)}>Increment</button>
//     </div>
//   );
// };
// export default ExampleComponent;

// Certainly! The useContext hook in React allows you to access the value of a context object defined by the createContext function. It provides a simple way to share data across components without prop drilling.



// useEffect(() => {
// 	setTimeout(() => {
// 		setCount((count) => count + 1);
// 	}, 1000);
// })

