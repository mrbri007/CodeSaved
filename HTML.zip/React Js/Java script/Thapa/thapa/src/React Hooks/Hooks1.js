import React, {useState, useEffect} from 'react'

export default function Hooks1() {
	const [count, setcount] = useState(0)
	const [time, settime] = useState(0);
	// const [countNumber, setcountNumber] = useState(0)

	// useEffect(() => {
	// 	//Runs on every render
	//   });
	// useEffect(() => {
	// 	alert("Passed Successfully")}, []);
		// [] : empty array first time refreshkarne par ek bar alert show hogA uake baad nahi
		// [] : //Runs on the first render
		// only click on first button not second wale par
		// alert("Passed Successfully")}, [count]);
		
	
	// useEffect(() => {
	// 		setTimeout(() => {
	// 			// settime((a) => a + 1);
	// 			// settime(() => time + 1);
	// 			settime(time + 1);
	// 		}, 1000);
	// 	  });
		
	
	// useEffect(() => {
	// 		setTimeout(() => {
	// 			// settime((a) => a + 1);
	// 			// settime(time + 1);
	// 			settime(() => time + 1);
	// 		}, 1000);
	// 	  },[]);

	useEffect(() => {
		//   document.title=`Passed Successfully : ${count}`
		  document.title = setTimeout(() => {
						settime((time) => time + 1);
					}, 1000)
	})
	
  return (
	<>
	<h1>Javscript : React </h1>
	<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed sit rem maiores nam molestiae ullam doloribus. Nesciunt, ex deserunt nam voluptas sit iure quae?</p>
	<p>Passed Successfully : {time}</p>
	<button 
		type="button" 
		onClick={(()=>{
		setcount(count + 1);
		})}>  
		Click Me {count}
	</button>

		<br />
		<br />

	{/* <button 
		type="button" 
		onClick={(()=>{
		setcountNumber(countNumber + 1);
		})}>
		Click Me {countNumber}</button> */}

	{/* <button 
		type="button" 
		onClick={(()=>{
		setcount(count + 1);
		},
		()=>{
			alert("Hello world");
		})}>
		Click Me {count}</button> */}
	</>
  )
}
// after completing all work , kuch bach gay hai too kaise kare
// components render hone ke baad kya kare 
// ypu tell react that your components needs to do something after render
// value increment hone par alert dikhe like aisa ho kuch anki clickkarne par
// jab jab <App/> components mai kuch changes hoga tab render method call karenge /chalega 
// uske liye useEffect and it gets automatically called :sync
// root.render(
// 	<React.StrictMode>
// 	  <App />
// 	</React.StrictMode>
//   );
// app page relaod and showing alert  : sync
// useEffect runs on every render. That means that when the count changes, a render happens, which then triggers another effect.
// update / change / refresh : useEffect