import React from 'react'
// import { firstName } from '../App'
// import { lastName } from '../App'

export default function Context3() {
	return (
		// <>
		// 		<firstName.Consumer>
		// 		{(fname) => {
		// 			return <h1>Context API 3 : {fname}</h1>
		// 		}}
		// 		</firstName.Consumer>
		// </>

		// <>
		// 		<firstName.Consumer>
		// 		{(fname) => {
		// 			return <h1>{fname}</h1>
		// 		}}
		// 		</firstName.Consumer>
		// </> 

		// <>
		// 	<firstName.Consumer>
		// 	{(fname) => {
		// 		return (
		// 			<lastName.Consumer>
		// 			{(lname) => {
		// 				return (
		// 					<>
		// 						<h1>Context API 3 : </h1>
		// 						<p>{fname}{lname}</p>
		// 					</>
		// 				)
		// 			}}
		// 			</lastName.Consumer>
		// 		)
		// 	}}
		// 	</firstName.Consumer>
		// </>

		// <>
		// 	<h1></h1>
		// </>

		<>
			<h1 className='bg-cyan-500'>Context API 3 :</h1>
		</>

	)
}
