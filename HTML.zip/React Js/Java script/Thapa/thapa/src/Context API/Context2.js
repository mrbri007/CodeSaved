import React from 'react'
// import Context3 from './Context3'
import { firstName, lastName } from '../App'
import { useContext } from 'react'


export default function Context2() {
	const fname = useContext(firstName)
	const lname = useContext(lastName)

  return (
		<>
			<h1> Context API </h1>
			<p>{fname}</p>
			<p>{lname}</p>
		</>


	  // <>
	  // 	<h1>Context API 2</h1>
	  // 	<Context3/>
	  // </>
  )
}


// firstName, lastName : context ki Value 
// contextvalue ko varible mai store karke use karo
