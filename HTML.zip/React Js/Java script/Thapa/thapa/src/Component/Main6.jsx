const arr =[
	{	
		id : 1, //// Used in JSX as a key
		Title : " Netflix Original Series",
        Heading : "Extra Curricular 1",
        Link : "https://www.netflix.com/in/",
        Img : "https://images.unsplash.com/photo-1586899028174-e7098604235b?ixlib=rb-4.0.3ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8bmV0ZmxpeHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60"
	},
	{	
		id : 2,
		Title : " Netflix Original Series",
        Heading : "Extra Curricular 2 - Apple",
        Link : "https://www.netflix.com/in/",
        Img : "https://pbs.twimg.com/media/Fx8IVKoaQAEdOVK?format=jpg&name=large"
	},
	{	
		id : 3,
		Title : " Netflix Original Series",
        Heading : "Extra Curricular 3",
        Link : "https://www.netflix.com/in/",
        Img : "https://images.unsplash.com/photo-1489824904134-891ab64532f1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OXx8Y2FyfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60"
	},
	{	
		id : 4,
		Title : " Netflix Original Series",
        Heading : "Extra Curricular 4  ",
        Link : "https://www.netflix.com/in/",
        Img : "https://images.unsplash.com/photo-1493238792000-8113da705763?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTZ8fGNhcnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60"
	},
	{	
		id : 5,
		Title : " Netflix Original Series",
        Heading : "Amazon Prime Video",
        Link : "https://www.netflix.com/in/",
        Img : "https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8YW1hem9ufGVufDB8fDB8fHww&auto=format&fit=crop&w=600&q=60"
	},
	{	
		id : 6,
		Title : " Netflix Original Series",
        Heading : "Extra Curricular 6",
        Link : "https://www.netflix.com/in/",
        Img : "https://images.unsplash.com/photo-1591293836027-e05b48473b67?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTh8fG11c3Rhbmd8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60"
	}


]

export default arr


// think like JSON  data and fetching api from server
// class ek reserved keyword hai 
// to give a unique idenity to evevry element inside the array, a key is required 