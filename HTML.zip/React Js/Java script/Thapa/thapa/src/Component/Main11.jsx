import React, { useState } from 'react'

export default function Main11() {
	// const [text, settext] = useState()
	// const CurrentDate = () =>{
	// 	settext(new Date().toLocaleDateString())
	// }
	// const CurrentTime = () =>{
	// 	settext(new Date().toLocaleTimeString())
	// }


	// let newTime = new Date().toLocaleTimeString()
	// const [text, settext] = useState(newTime)
	// const UpdateTime = () =>{
	// 	//already defined so no need to write let
	// 	// newTime = new Date().toLocaleTimeString() 
	// 	// here newcurrentTime should be defined with let keyword 
	// 	let newcurrentTime = new Date().toLocaleTimeString() 
	// 	settext(newcurrentTime)
	// }

	let newTime = new Date().toLocaleTimeString()
	const [text, settext] = useState(newTime)
	const UpdateTime = () =>{
		let newcurrentTime = new Date().toLocaleTimeString() 
		settext(newcurrentTime);
	}
	setInterval(UpdateTime, 1000);
	
  return (
	<>
		{/* <h2 className='heading'>Current Date : {text}</h2> */}
		{/* <button type="button" onClick={CurrentDate} className='btn'> Date </button> */}
		{/* <button type="button" onClick={CurrentTime} style={{marginLeft : "10px"}} className='btn'> Time </button> */}

		{/* <h2 style={{fontWeight : 400}}>Current Date : {newTime}</h2> */}
		{/* <h2 style={{fontWeight : 400}}>Current Time : {text}</h2> */}
		{/* <button type="button" onClick={UpdateTime} className='btn'> Time </button> */}

		<h2 className='heading'>Current Time : {text}</h2>
	</>
  )
}
