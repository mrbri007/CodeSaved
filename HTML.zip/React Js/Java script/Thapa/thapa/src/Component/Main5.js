const company1 = "Lorem ipsum dolor sit amet consectetur adipisicing elit. ";
const company2 = "Lorem ipsum dolor sit amet consectetur adipisicing elit.";
function company3(){
	let a = "Lorem ipsum dolor sit amet consectetur adipisicing elit."
	return a
}
function company4(){
	let b = "Lorem ipsum dolor sit amet consectetur adipisicing elit."
	return b
}
export default company1
export {company2, company3, company4}