import React from 'react'

export default function Main7(props) {
  return (
  //coming from Main6
	<img src={props.imggggggg} alt="ImgLoading" className='card_img' /> 
  )
}
