import React from "react";

export default function Main1() {
  // CSS as a object
  // const myStyle = {
  // 	color: "white",
  // 	backgroundColor: "DodgerBlue",
  // 	padding: "10px",
  // 	fontFamily: "Sans-Serif"
  // };

  return (
    <>
      <div className="conatiner">
        <h1>Javascript Library </h1>
        <p>{<Hello />}</p>
        {/* <button type="button" className="btn">Get Started</button><br/> */}
        {/* <img src={"https://shorturl.at/qzKV5"} alt="loading" /> */}
      </div>
      <div>
        {/* <p style={myStyle}>Internal CSS Styling</p> */}
        {/* <p style={{color: "red"}}>Internal CSS Styling</p> */}
      </div>
    </>
  );
}

const Hello = () => {
  return (
    <>
      <p>JSX is an extension of the JavaScript language based on ES6</p>
    </>
  );
};
// export default Hello()
