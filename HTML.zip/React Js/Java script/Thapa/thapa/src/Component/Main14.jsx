import React, {useState} from 'react'

export default function Main12() {
	const [text, settext] = useState("")
	const [text2, settext2] = useState("")
	
	const [heading, setheading] = useState("")
	const [heading2, setheading2] = useState("")

	const userText = (event) => {
		settext(event.target.value)
	}

	const userText2 = (event) => {
		settext2(event.target.value)
	}

	const formResult = (e) => {
		e.preventDefault() 
		alert(1`Passed Successfully : ${text}`)
		setheading(text);
		setheading2(text2);
	}



  return (
	<div>
		<h2 className='heading'>Hello {heading} {heading2}</h2>
		<form onSubmit={formResult}>
			<span>Username :</span> <input type="text" onChange={userText} value={text}/><br /><br />
			<span>Password :</span> <input type="password"  onChange={userText2} value={text2}/><br /><br />
			<button className='btn' type='Submit'>Submit</button>
		</form>
	</div>
  )
}
