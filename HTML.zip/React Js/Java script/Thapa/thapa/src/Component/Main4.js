import React from 'react'
import './Main4.css'
import Image from './Main7'

export default function Main4(props) {
  // console.log(props) //sare props as a object store ho jate hai
  return (
	<>
   <div className="cards">
    <div className="card">
      {/* <img src={props.Img} alt="ImgLoading" className='card_img' /> */}
      <Image imggggggg ={props.Img}/>
      <div className="card_info">
        <span className='card_category'>{props.Title}</span>
        {/* <h3 className='card_title heading_style'>{props.className}</h3> */}
        <h3 className='card_title heading_style'>{props.Heading}</h3>
        <a href={props.Link} target='_blank' rel="noopener noreferrer">
          <button>Watch Now</button>
        </a>
      </div>
    </div>
   </div>
  </>
  )
}
  
//  components ki heierchy