import React, { useState } from 'react'

export default function Main13() {

  let primaryBtn = "rgba(255, 157, 175, 0.56)"
  const [text, settext] = useState(primaryBtn)
  
  let title = "Click Me"
  const [InsideBtn, setInsideBtn] = useState(title)

  const UpdateBtn = () =>{  
    settext("#9ddfff87")
    setInsideBtn("Learn More")
  }

  const UpdateDoubleBtn = () =>{
    let bgColor = "rgba(255, 157, 175, 0.56)"
    settext(bgColor)
    setInsideBtn("Click Me")
  }


  return (
    <>
      
      {/* <div style={{backgroundColor : "#9ddfff87"}} className='main'> */}

      <div style={{backgroundColor : text}} className='main'>
        <h2 className='heading'>React Event Handling</h2>
        {/* <button type="button" onClick={UpdateBtn} className='btn'>Click Me</button> */}
        {/* <button type="button" onClick={UpdateBtn} className='btn'>{InsideBtn}</button> */}
        {/* <button type="button" onClick={UpdateBtn} onDoubleClick={UpdateDoubleBtn} className='btn'>{InsideBtn}</button> */}
        <button type="button" onMouseEnter={UpdateBtn} onMouseLeave={UpdateDoubleBtn} className='btn'>{InsideBtn}</button>
      </div>
    </>
  )
}

// Notes 
// Inline css use akrte samay hum usse styling ko object consider karte hai
// 
