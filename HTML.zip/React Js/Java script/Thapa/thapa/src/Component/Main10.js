import React, {useState} from 'react'

export default function Main10() {

	// const [statevarible, updaterfunction] = useState(intialvalue)
	const [count, setcount] = useState(0)
	
	// let count= 1
	// For Increment
	const iNumber = () =>{
		// console.log("Passed Successfully", count++);
		// setcount(100)
		console.log("Passed Successfully");
		setcount(count + 1)  // for increment
	}

	// For Decrement
	// const [count, setcount] = useState(10)
	// const iNumber = () =>{
	// 	if (count > 0) {
	// 		setcount(count - 1) 
	// 	}
	// }

	return (
	<>
		<h1 style={{fontWeight : 400}}>Javascript library : React</h1> 
		<p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Obcaecati iure perspiciatis, eligendi autem quae natus sunt aut numquam blanditiis voluptate vitae ipsum nostrum sapiente accusamus, repellat maxime minus animi recusandae at debitis quos. Soluta. Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto mollitia repellendus doloribus omnis, rerum accusamus deserunt est quis placeat? Hic, tenetur est? Facere iste, numquam odit inventore nesciunt nostrum libero facilis magni magnam hic, saepe, laborum obcaecati aliquid ducimus.</p>
		<h2 style={{fontWeight : 400}}> Get the result : {count}</h2>
		<button onClick={iNumber} className='btn'> Learn More</button>
	</>
  )
}
