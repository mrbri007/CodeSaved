import React from 'react'
// import './Main2.css'

// It creates a new div in console.log like // can create a newproblem in css grid and flexbox
//  <div id="root">
//  <div>
// 		<h1></h1>
// 		<p></p>
//  </div>
// </div> 
// export default function Main2() {
//   return (
// 		<div>
// 			<h3>Lorem, ipsum dolor.</h3>
// 			<p>Lorem ipsumentore cumque. Aspernatur suscipit ab quia consequatur est? Voluptates.</p>
// 		</div>
//   )
// }

// It does not crete a new div in console.log like
// <React.Fragment><React.Fragment/> or <.></> oth are same
// <div id="root">
// 		<h1></h1>
// 		<p></p>
// </div> 
// const Hello = () => {
//   return (
// 	<React.Fragment>
// 		<div>
// 			<h3>Lorem, ipsum dolor.</h3>
// 			<p>Lorem ipsum dolor sit amet consecteturtur suscipit ab quia consequatur est? Voluptates.</p>
// 		</div>
// 	</React.Fragment>
//   );
// };

// Objects are not valid as a React child 
// const a = new Date()
// const currentDate = new Date().toLocaleDateString()
// const CurrentTime = new Date().toLocaleTimeString()
// const animalImg = "https://images.unsplash.com/photo-1684109500005-0b17834a8711?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHx0b3BpYy1mZWVkfDE4N3xKcGc2S2lkbC1Ia3x8ZW58MHx8fHx8&auto=format&fit=crop&w=500&q=60";
// const animalURL = "https://unsplash.com/t/animals";
// let cureDate = new Date(2020,6,5,17).getHours()
// const AppStyle = {} // empty object
// let greeting = ""; //declartion
// if (cureDate >= 1 && cureDate < 12) {
// 	greeting = "Mac"; //updated value
// 	AppStyle.color = "green"; // objet ki properties use kar sakte hai 
// } 
// else if (cureDate >= 12 && cureDate < 19) {
// 	greeting = "Ipod";  //updated value
// 	AppStyle.color = "red";
// } 
// else{
// 	greeting = "Vision pro"; //updated value
// 	AppStyle.color = "blue";
// }


// const heading ={
// 	marginLeft : "35px",
// 	marginTop : "20px"
// }
export default function Main2() {
  return (
	<>
		{/* <div style={heading}> */}
		<div>
			{/* <h1>Javascript library : React</h1> */}
			{/* <p>Lorem ipsumentore cumque. Aspernatur suscipit ab quia consequatur est? Voluptates. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, soluta. Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam excepturi, nobis quis et reiciendis enim odit vero voluptatibus a deleniti! Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque officiis voluptate hic est numquam recusandae a quas quasi corporis. Iusto distinctio a ab. Labore ut eius obcaecati iure porro? Quisquam, consequatur corrupti veritatis iure possimus quasi excepturi maiores aperiam quia repellat, eos ab. Debitis, cum!
			</p> */}
		</div>

		<div>
			{/* <p>Javascript Expression: {2+3} </p> */}
			{/* <p>Javascript Statement :{
				if(7){
					console.log(true)
				}else{
					console.log(false)
				}}
			</p> */}
		</div>

		<div>
			{/* <p>The current Date is : {currentDate}</p>
			<p>The current Time is : {CurrentTime}</p> */}
		</div>

		<div>
			{/* <p contentEditable='true'>Lorem ipsum dolor sit amet elit. Exercitationem, expedita!</p> */}
			{/* <img src="https://images.unsplash.com/photo-1684109500005-0b17834a8711?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHx0b3BpYy1mZWVkfDE4N3xKcGc2S2lkbC1Ia3x8ZW58MHx8fHx8&auto=format&fit=crop&w=500&q=60" alt="Error Loading" /> */}
			{/* <img src={animalImg} alt="Error Loading" /> */}
			{/* <a href={animalURL} target="_blank" rel="noopener noreferrer">
				<img src={animalImg} alt="Error Loading"/>
			</a> */}
		</div>

		<div>
			 {/* <div class="main" id="section1">
				<h2>Section 1</h2>
				<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla cum dignissimos minima nemo! Neque ipsum magnam, esse quod libero, possimus iure quia amet cupiditate totam alias harum, autem commodi enim laudantium dolores magni reiciendis voluptate sed consequuntur reprehenderit velit impedit nobis illo. Facilis voluptatum, harum excepturi neque nesciunt hic fugit! Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi, recusandae ratione numquam debitis quaerat officia nam natus quisquam earum temporibus accusamus veritatis nihil labore fuga iure repellat veniam, voluptatibus sed molestias? Ad reprehenderit cupiditate libero non deserunt dolorum amet quas dolorem vero autem rem assumenda consectetur, modi laborum explicabo laudantium. Tempora accusamus nostrum explicabo officiis! Illo soluta natus eaque error officia eveniet atque dolorem ipsa magni sint optio cum voluptates saepe, dolore ea in, dignissimos nostrum ex fugit rem repudiandae ratione minima sit. Cupiditate asperiores laudantium quos ipsum repudiandae minus! Commodi deserunt veritatis iure neque voluptate praesentium, enim expedita. Expedita, tempore veniam voluptatibus itaque commodi eos dolorum cum necessitatibus officia esse ullam sunt atque sit aliquid enim quasi, cupiditate explicabo? Perspiciatis at nobis vitae recusandae eligendi quam, odit amet ipsa facere, distinctio ullam repellat delectus blanditiis? Dignissimos, cupiditate rerum. Dolorem, consectetur sunt, dignissimos recusandae quidem ipsa saepe iure minima vitae officiis cumque modi sint laborum doloremque quam animi mollitia aspernatur provident, vel soluta corrupti reprehenderit. Voluptas a delectus beatae asperiores at qui, fugiat consequuntur doloribus? Distinctio porro expedita libero qui ipsa beatae? Explicabo non, officia dolore quis iure molestiae pariatur! Id obcaecati provident voluptas modi distinctio at saepe sit molestias!</p>
				<a href="#section2">Learn More</a>
			</div> */}
{/* 
			<div class="main" id="section2">
				<h2>Section 2</h2>
				<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sunt, ipsum delectus doloremque numquam dolorem neque alias illo omnis a, voluptas molestiae debitis est explicabo magnam. Atque perferendis ad enim? Praesentium voluptates vero nobis obcaecati eos alias iste cupiditate, delectus est fuga ex dicta accusamus numquam sed fugiat inventore corrupti neque? Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi, recusandae ratione numquam debitis quaerat officia nam natus quisquam earum temporibus accusamus veritatis nihil labore fuga iure repellat veniam, voluptatibus sed molestias? Ad reprehenderit cupiditate libero non deserunt dolorum amet quas dolorem vero autem rem assumenda consectetur, modi laborum explicabo laudantium. Tempora accusamus nostrum explicabo officiis! Illo soluta natus eaque error officia eveniet atque dolorem ipsa magni sint optio cum voluptates saepe, dolore ea in, dignissimos nostrum ex fugit rem repudiandae ratione minima sit. Cupiditate asperiores laudantium quos ipsum repudiandae minus! Commodi deserunt veritatis iure neque voluptate praesentium, enim expedita. Expedita, tempore veniam voluptatibus itaque commodi eos dolorum cum necessitatibus officia esse ullam sunt atque sit aliquid enim quasi, cupiditate explicabo? Perspiciatis at nobis vitae recusandae eligendi quam, odit amet ipsa facere, distinctio ullam repellat delectus blanditiis? Dignissimos, cupiditate rerum. Dolorem, consectetur sunt, dignissimos recusandae quidem ipsa saepe iure minima vitae officiis cumque modi sint laborum doloremque quam animi mollitia aspernatur provident, vel soluta corrupti reprehenderit. Voluptas a delectus beatae asperiores at qui, fugiat consequuntur doloribus? Distinctio porro expedita libero qui ipsa beatae? Explicabo non, officia dolore quis iure molestiae pariatur! Id obcaecati provident voluptas modi distinctio at saepe sit molestias!</p>
				<a href="#section1">Get Started </a>
			</div> */}
		</div> 

		<div>
			{/* <h3>When it comes to privacy, we don't blink.<span style={AppStyle}> {greeting} </span> </h3> */}
		</div>
	</>
  ) 
}

   

