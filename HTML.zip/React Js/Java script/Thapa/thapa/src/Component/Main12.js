import React, {useState} from 'react'

export default function Main12() {
	const [text, settext] = useState("")
	const [fullname, setfullname] = useState("")

	const userText = (event) => {
		settext(event.target.value)
		// console.log(event.target.value);
		// console.log(event);
	}

	// user jo bhi type kar rha hai vo text name ke state varible mai store hp rha hai
	// form submit karne par page refresh na ho uske liye
	const final_output = (e) => {
		e.preventDefault() // form ka deault behaiour remove kar do bhai
		setfullname(text);
		// console.log(text);/
	}

	

  return (
	// <div>
	// 	<h2 className='heading'>Hello {fullname}</h2>
	// 	{/* <h2 className='heading'>Hello {text}</h2> */}
	// 	{/* <input type="text" placeholder='enter your name'/><br /><br /> */}
	// 	{/* <input type="text" placeholder='enter your name' value={""}/><br /><br /> */}
	// 	{/* <input type="text" placeholder='enter your name' value={"Hello world"}/><br /><br /> */}
	// 	{/* <input type="text" placeholder='enter your name' defaultValue={""}/><br /><br /> */}
	// 	{/* <input type="text" placeholder='enter your name' defaultValue={"Hello world"}/><br /><br /> */}
	// 	{/* <input type="text" placeholder='enter your name' /><br /><br /> */}
	// 	<span>Username :</span> <input type="text" placeholder='enter your name' onChange={userText} value={text}/><br /><br />
	// 	<button className='btn' type='Sumbit' onClick={final_output}>Submit</button>
	// </div>
	// State mai store ho rha tha 2 data : one is typing and another one is submit
	// form sumbit karne par refresh nahi rha tha bcoz not using form tags
	// see the difference



	// form tag use karne par form refresh ho jata hai and state mai data store nahi hota becox of refresh
	// form sumbit karte samay refresh hoo jana default behaviour of html
	// form sumbit karne ke bad backened yani database mai store ho jata hai
	// form ka apna event hai onSubmit()
	// input feild  = onchange()
	// button  = onclick()
	<div>
		<h2 className='heading'>Hello {fullname}</h2>
		<form onSubmit={final_output}>
			<span>Username :</span> <input type="text" placeholder='enter your name' onChange={userText} value={text}/><br /><br />
			<button className='btn' type='Submit'>Submit</button>
			{/* {no need to write onclick event on button becasue already defied type="submit" and when it is clicked then onsubmit function will trigger } */}
			{/* <button className='btn' type='Sumbit' onClick={final_output}>Submit</button> */}
		</form>
	</div>
  )
}










//event. target. value represents the field's current value
//in form value props and onchange handlershould be used hand in hand 
// Warning: You provided a `value` prop to a form field without an `onChange` handler. This will render a read-only field. If the field should be mutable(changeable) use `defaultValue`. Otherwise, set either `onChange` or `readOnly`.
// value + onchnage handler(recommeneded) or defaultvalue and 
// only value = readonly

// Note :This will not work in HTML(No restriction) because input feild form data is controlled by react components
// two types of components : by react and by dom
// controlled(via React) and uncontrolled(via DOM) components
// input form element is managed by react

// button ke liye : oncLick function (event calling)
// input ke liye : onchange function  (event calling)

// event function call karte samamy hum event as aobject use kar sakte haiansd function ke apparmeter mai uslo access akr sakte hai and use kar skte ahi 

// javascript mai varible ko likhne ka tarika : name
// jsx mai varible ko likhne ka tarika  : {name} 

// {/* <input type=" " name="" value={text}> */} 
// this input field and value is controlled by react componnets and but in html ye input field controlled by dom itself
// wehn using event handler , we can use event object properties and method
// jab bhi event call karte hai to voh object pass karta hai usse hum as a parameter access kar sakte hai 
// form ke element ko form nahi balki react components controlled kart ahi  