import React, {useState} from 'react'

export default function Main12() {
	
	// usestate ko value ko fullname access kar sakt hai and also setfullname bhi by fillname ke through
	const [fullName, setfullName] = useState({
		fname : "",
		lname : "",
		email : "",
		phone : ""
	})

	const inputEvent = (event) => {
		console.log(event.target.value) 
		console.log(event.target.name) 
		// console.log(event.target.placeholder) 
		
		// it could be anything : fname or lname (value)
		// it could be anything : fname or lname (name)
		// const value = event.target.value
		// const name = event.target.name
		// array destructing
		const {value, name} = event.target

		//useState ke andar jo oject hai usse access akrne ke liye
		setfullName((previousValue)=>{
			// console.log(previousValue);
			// console.log(previousValue.fname);
			// console.log(previousValue.lname);
			// if (name === 'fname'){
			// 	return{
			// 		fname : value,
			// 		lname : previousValue.lname,
			// 		email : previousValue.email,
			// 		phone : previousValue.phone
			// 	};
			// } 
			// else if (name === 'lname'){
			// 	return{
			// 		fname : previousValue.fname,
			// 		lname : value,
			// 		email : previousValue.email,
			// 		phone : previousValue.phone
			// 	};
			// } else if (name === 'email'){
			// 	return{
			// 		fname : previousValue.fname,
			// 		lname : previousValue.lname,
			// 		email : value,
			// 		phone : previousValue.phone
			// 	};
			// } else if (name === 'phone'){
			// 	return{
			// 		fname : previousValue.fname,
			// 		lname : previousValue.lname,
			// 		email : previousValue.email,
			// 		phone : value
			// 	};
			// }
			return{
				...previousValue,
				[name] :value
			}
		});
	}

	const formResult = (e) => {
		e.preventDefault() 
		alert("Passed Successfully")
	}



  return (
	<div>
		<h2>Preview : {fullName.fname} {fullName.lname}</h2>
		<p>Preview : {fullName.email} {fullName.phone}</p>
		<form onSubmit={formResult}>
			<span>FirstName : </span> 
			<input 	type="text" 
					onChange={inputEvent} 
					placeholder='enter your fname'
					value={fullName.fname} 
					name='fname'/>
			<br/>
			<br/>
			<span>LastName : </span> 
			<input 	type="text" 
					onChange={inputEvent} 
					placeholder='enter your lname'
					value={fullName.lname} 
					name='lname'/>
			<br/>
			<br/>
			<span>Email : </span> 
			<input 	type="email" 
					onChange={inputEvent} 
					placeholder='enter your email'
					value={fullName.email} 
					name='email'/>
			<br/>
			<br/>
			<span>Contact No : </span> 
			<input 	type="number" 
					onChange={inputEvent} 
					placeholder='enter your number'
					value={fullName.phone} 
					name='phone'/>
			<br/>
			<br/>
			<button className='btn' type='Submit'>Submit</button>
		</form>
	</div>
  )
}

// lets make it short
// har ek inpit feiedl ke liye ek hi onchange event handler ko call karenge
// jab bhi user input field mai kuch value type karta tha to backend mai access karne ke liye name attribute as a key varible mai store ho jata tha
	//formResult means onsumbit par hame koi sumbit nahi karn hai as of now  
	// /event method
	// Tristan Berrimore
	// Or, we can just use one state and include an object instead!
	// const [value, setValue] = useState({})
	// setValue((prevState) => {
	//   if (condition to not update) {
	// 	return prevState;
	//   } else {
	// 	return newState;
	//   }
	// https://www.xvideos.com/video77180185/all-natural_curvy_teen_fucked_in_the_shower_after_taking_milk_bath
	// https://www.xnxx.tv/video-19y8m1d7/big_tits_and_ass_teen_nympho_fucked_by_an_older_milk_man
	// });

	
// let a = "b"
// console.log(a)

// let c = {[a]: "d"}
// console.log(c)

// let e = {a: "d"}
// console.log(e)

// details examine
// [a] value containe "b"
// so c obejct represent like this
// var c = {b : "d"}
// https://la.spankbang.com/51yqb/video/tristan+berrimore+milk+man