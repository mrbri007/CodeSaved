import React from 'react'
import arr from './Main6'
import Main4 from './Main4'

export default function Main8() {
	return (
		<Main4 
			   keys ={arr[1].id}
			   Title = {arr[1].Title}
			   Heading = {arr[1].Heading}
			   Link = {arr[1].Link}
			   Img = {arr[1].Img}
		/> 
	   )
}

// Netflix