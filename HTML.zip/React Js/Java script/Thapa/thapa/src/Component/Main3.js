import React from 'react'
// import Main5 from './Main5'
// import randomName, {company2, company3, company4} from './Main5'
import * as varName from './Main5'

// we can import everything as a objet using import '*' as <obj> for instrance
// export ka data yaha pe fetch ho jata hai as a object varname mai store ho jata hai

export default function Main3() {
  return (
	<>
		<div>
			<h2>UI Based Framework</h2>
			{/* <p>{Main5}</p> */}

			{/* <p>{randomName}</p>
			<p>{company2}</p>
			<p>{company3()}</p>
			<p>{company4()}</p>  */}

			<p>{varName.default}</p>
			<p>{varName.company2}</p>
			<p>{varName.company3()}</p>
			<p>{varName.company4()}</p>
		</div>
	</>
  )
}
