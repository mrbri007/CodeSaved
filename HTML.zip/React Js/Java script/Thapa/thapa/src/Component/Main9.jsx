import React from 'react'
import arr from './Main6'
import Main4 from './Main4'

export default function Main9() {
	return (
		<Main4 
			   keys ={arr[4].id}
			   Title = {arr[4].Title}
			   Heading = {arr[4].Heading}
			   Link = {arr[4].Link}
			   Img = {arr[4].Img}
			   
		/> 
	   )
}

// Aamzon