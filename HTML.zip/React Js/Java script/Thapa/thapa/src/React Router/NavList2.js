import React from 'react'
import NavList3 from './NavList3'

export default function NavList2(props) {
  return (
	<>
			<NavList3/>
		<div>
			<h2>NavList 2 : This is ABOUT page</h2>
			<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint ad, ipsam blanditiis delectus provident tenetur dolore accusamus. Culpa impedit, ad quos ratione ut vitae iusto quod voluptas nulla quisquam est harum officia! Nobis, vel? : {props.name}</p>
		</div>
	</>
  )
}
