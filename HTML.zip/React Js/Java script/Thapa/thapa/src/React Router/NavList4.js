import React from 'react'
// import NavList3 from './NavList3'
// import { NavLink } from 'react-router-dom'
// import { useParams, useLocation  } from 'react-router-dom'
import { useNavigate } from 'react-router-dom';

export default function NavList4() {
    // Get the userId param from the URL.
    // as a object mai add karna 
  // const {fname, lname} = useParams();
  // const location = useLocation(); //varible defined krn hai 
  const Naviagte = useNavigate();
  // console.log(Naviagte);
  // console.log(location)
  return (
    <>
		<div>
			{/* <NavList3/> */}
			<h2>NavList 4 : This is ERROR page  </h2>
			{/* <h2>NavList 4 : This is USER page  </h2> */}
			{/* <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint ad, ipsam blanditiis delectus provident tenetur dolore accusamus. Culpa impedit, ad quos ratione ut vitae iusto quod voluptas nulla quisquam est harum officia! Nobis, vel? : </p> */}
      {/* <h3>Namste {fname }{lname}, how can i help you ?</h3> */}
      {/* <p>My current location is {location.pathname}</p> */}
      {/* <p>My random value is {location.key}</p> */}
        {/* <button type="button" onClick={()=>{console.log("HellO WORld")}} */}
        {/* <button type="button" onClick={()=>{Naviagte(-1)}} */}
      {/* {location.pathname === `/user/Brijesh/gupta` ?  */}
        {/* <button type="button" onClick={()=>{Naviagte('/')}} */}
		{/* >Click Me</button> : null} */}
    {/* <NavLink to="/">Go Back</NavLink> */}
    <button type="button" onClick={()=>Naviagte("/")}>Go Home</button>
   
		</div>
	</>
  )
}


// // user/:name main name mai user ne ky alikh ath auko pata karne ke lye hum ek parameter pass karte hai 
// // without hooks 
// // In order to install React Router, you will need to use a package manager such as npm or yarn. 
// // This can be useful if you want to dynamically render content based on the URL parameters. 

// // The useParams() hook will return an object with a key of articleId and a value of 123. You can access the values of the URL parameters by destructuring the object returned by useParams(). For example:

// // user/class10/5 roll no ka data dikhaoygo 
// // fname and lname sab jagh sam hona chahiye s

// // useparams : jab aap paramter k ause karte ho to mulitple data/parameter fetch krne ke liye { } use karte hai
// // but in the caese of use locatio

// // to fund currnet location of page/componnets  : useLocation




// import React from 'react';
// import { useParams  } from 'react-router';

// const NavList4 = () => {
//     const { fname , lname } = useParams();
//     const name = "vinod";
//     const surname = "thapa";
    
//     return(
//         <React.Fragment>
//             <h1>hii {fname} {lname} </h1>
//             <p>My current location is : localhost:3000/{fname}/{lname}</p>
//             {(name === fname && surname === lname) ? (
//                 <button onClick={()=>alert("hii vinod thapa")}>Click Me</button>
//             ):null}
//         </React.Fragment>
//     )
// };

// export default NavList4
// useParams returns an object of key/value pairs of URL parameters

// Basically, this hook gives you access to history objects and you have access to several functions to navigate your page. It's all about navigation. This is how you can use useHistory.



// If you are using react-router-dom@6 then the useHistory hook was replaced by the useNavigate hook.




// uselocation found in usehistory : so waht is the difference ? 
// because it is mutable usehistory so that's why 



// agar koi user predefined path ke alava kuch search kart th ato hum uslo error page dilhate rhe par ab hame usko error page pe nahi balki home page par redirectr kar denge 