import React from 'react'
// import { Link } from 'react-router-dom'
import { NavLink } from 'react-router-dom'

export default function NavList3() {
  return (
	// <>
	// 	<h2>NavList 3 : This is Contact page</h2>
	// 	<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint ad, ipsam blanditiis delectus provident tenetur dolore accusamus. Culpa impedit, ad quos ratione ut vitae iusto quod voluptas nulla quisquam est harum officia! Nobis, vel?</p>
	// </>

	// <>
	// 	<a href="/">Home</a><br />
	// 	<a href="/about">About</a>
	// </>

	// <>
	// 	<Link to="/">Home</Link> <br />
	// 	<Link to="/about">About</Link>
	// </>

	<>
		<NavLink activeclassname="active_class" to="/">Home</NavLink> <br />
		<NavLink activeclassname="active_class" to="/about">About</NavLink><br />
		<NavLink activeclassname="active_class" to="/search">search</NavLink><br />
		<NavLink activeclassname="active_class" to="/user">User</NavLink>
		{/* <NavLink activeclassname="active_class" to="/user/Brijesh">User</NavLink> */}
		{/* <NavLink activeclassname="active_class" to="/user/Brijesh/gupta">User</NavLink> */}
	</>

  )
}


// a: page refresh hoga bhai
// html atrribute : props :
// - doble time select and _ one time select
// {/* <NavLink activeclassname="active_class" to="/user/dfgsjdgfshgfsj">User</NavLink> */}
// by default : /user/cgjhsdfjsdhbm

// The useParams hook returns an object of key/value pairs of the dynamic params from the current URL 
