       // import React from "react";
       import './App.css';


       // // import Main1 from './Component/Main1';
       // // import Main2 from "./Component/Main2";
       // // import Main3 from './Component/Main3';
       // // import Main4 from './Component/Main4';

       // // Main3 : kuch bhi varible name likh sakte hai and use it <Apple/>
       // // import Main3 from './Component/Main3';
       // // import Apple from './Component/Main3';

       // // import arr from './Component/Main6'
       // // import Main8 from './Component/Main8';
       // // import Main9 from './Component/Main9';
       // // import Main10 from './Component/Main10';
       // // import Main11 from "./Component/Main11";
       // // import Main12 from "./Component/Main12";
       // // import Main15 from "./Component/Main15";
       // // import Main14 from "./Component/Main14";
       // // import TodoList from "./Project/TodoList";
       // // import Nav1 from "./Main/Nav1";
       // // import Nav2 from "./Main/Nav2";
       // // import Nav3 from "./Main/Nav3";
       // // import Nav4 from "./Main/Nav4";
       // import Context1 from "./Context API/Context1";
       // import Context2 from "./Context API/Context2";
       // import Context3 from "./Context API/Context3";
       // // import Main13 from "./Component/Main13";
       // // console.log(arr[0]);
       // // console.log(arr[0].Title);

       // // function myfun(value){
       // //        return(
       // //        <Main4
       // //               Title = {value.Title}
       // //               Heading = {value.Heading}
       // //               Link = {value.Link}
       // //               Img = {value.Img}
       // //        />
       // //        )
       // // }

       // // const favseries = 'Amazon';
       // // const favseries = 'Netflix';
       // // const favseries = prompt("Enter your fav Series");

       // // const Favs = () =>{
       // //        if (favseries === "Netflix") {
       // //              return (
       // //                      <Main8/>
       // //               )
       // //        }
       // //        else{
       // //               return (
       // //                      <Main9/>
       // //                     )
       // //        }
       // // }

       // // agar if else condition functiona mai ho TO  hum  return statement use kar salte ahi

       // // const Favs = () =>{
       // //        if (favseries === "Netflix") {
       // //              return (
       // //               <Main4
       // //                      keys ={arr[1].id}
       // //                      Title = {arr[1].Title}
       // //                      Heading = {arr[1].Heading}
       // //                      Link = {arr[1].Link}
       // //                      Img = {arr[1].Img}
       // //               />
       // //              )
       // //        }
       // //        else{
       // //               return (
       // //                      <Main4
       // //                             keys ={arr[4].id}
       // //                             Title = {arr[4].Title}
       // //                             Heading = {arr[4].Heading}
       // //                             Link = {arr[4].Link}
       // //                             Img = {arr[4].Img}
       // //                      />
       // //                     )
       // //        }
       // // }



       // function App() {
       //   return (
       //     <>
       //       {/* <Main10/> */}
       //       {/* <Main11 /> */}
       //       {/* <Main12 /> */}
       //       {/* <Main14 /> */}
       //       {/* <Main15/> */}
       //       {/* <TodoList/> */}
       //       {/* <Nav1/> */}
       //       {/* <Nav2/> */}
       //       {/* <Nav3/> */}
       //       {/* <Nav4/> */}
       //       <Context1/>
       //       <Context2/>
       //       <Context3/>
       //       {/* <Main13/> */}
       //       {/* <Main1/> */}
       //       {/* <Main2 /> */}
       //       {/* <Main3/> */}

       //       {/* <Main4 
       //             Title = " Netflix Original Series"
       //             Heading = "Dark"
       //             Link = "https://www.netflix.com/in/"
       //             Img = "https://images.unsplash.com/photo-1586899028174-e7098604235b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8bmV0ZmxpeHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60"
       //             />
       //      <Main4 
       //             Title = " Netflix Original Series"
       //             Heading = "The Night Things"
       //             Link = "https://www.netflix.com/in/"
       //             Img = "https://images.unsplash.com/photo-1586899028174-e7098604235b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8bmV0ZmxpeHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60"
       //             />
       //      <Main4 
       //             Title = " Netflix Original Series"
       //             Heading = "Extra Curricular"
       //             Link = "https://www.netflix.com/in/"
       //             Img = "https://images.unsplash.com/photo-1586899028174-e7098604235b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8bmV0ZmxpeHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60"
       //             />
       //      <Main4 
       //             Title = " Netflix Original Series"
       //             Heading = "Extra Curricular"
       //             Link = "https://www.netflix.com/in/"
       //             Img = "https://images.unsplash.com/photo-1586899028174-e7098604235b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8bmV0ZmxpeHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60"
       //             /> */}
       //       {/* components mai agr className as props pass kart hu to vo usse csss propteries nahi karega */}
       //       {/* prosp : html attribute */}

       //       {/* props : components  = className */}
       //       {/* css properties : jsx  = className */}

       //       {/* for example : does not work
       //                .helloworld{
       //                      color :red
       //                }

       //              */}
       //       {/* <Main4 
       //        //      className = "helloworld " // not a css properties just only props
       //             Title = {arr[0].Title}
       //             Heading = {arr[0].Heading}
       //             Link = {arr[0].Link}
       //             Img = {arr[0].Img}
       //             />
       //      <Main4 
       //             Title = {arr[1].Title}
       //             Heading = {arr[1].Heading}
       //             Link = {arr[1].Link}
       //             Img = {arr[1].Img}
       //             />
       //      <Main4 
       //             Title = {arr[2].Title}
       //             Heading = {arr[2].Heading}
       //             Link = {arr[2].Link}
       //             Img = {arr[2].Img}
       //             />
       //      <Main4 
       //             Title = {arr[3].Title}
       //             Heading = {arr[3].Heading}
       //             Link = {arr[3].Link}
       //             Img = {arr[3].Img}
       //             />
       //      <Main4 
       //             Title = {arr[4].Title}
       //             Heading = {arr[4].Heading}
       //             Link = {arr[4].Link}
       //             Img = {arr[4].Img}
       //             /> */}
       //       {/* You will often want to display multiple similar components from a collection of data. You can use the JavaScript array methods to manipulate an array of data. On this page, you’ll use filter() and map() with React to filter and transform your array of data into an array of        components. */}

       //       {/* when using map method, keys asa props hon CHhiye   */}
       //       {/* You need to give each array item a key — a string or a number that uniquely identifies it among other items in that array: */}
       //       {/* {arr.map((value, index, array) => {
       //               console.log(value)
       //               return(

       //                      <Main4 
       //                             keys ={value.id}
       //                             Title = {value.Title}
       //                             Heading = {value.Heading}
       //                             Link = {value.Link}
       //                             Img = {value.Img}
       //                       /> 
       //               )
       //               })};
       //                */}

       //       {/*        
       //             {arr.map(function myfun(value){
       //               return(
       //                      <Main4 
       //                             Title = {value.Title}
       //                             Heading = {value.Heading}
       //                             Link = {value.Link}
       //                             Img = {value.Img}
       //                       /> 
       //               )
       //             })}  */}

       //       {/* function calling  */}
       //       {/* <Favs/>  */}
       //       {/* no need to write return in terniary opertor */}
       //       {/* {(favseries === "Netflix") ?  <Main8/> :  <Main9/>} */}
       


       //     </>

       //   );
       // }

       // export default App;





// import React from "react";
// import React, { createContext } from "react";
// import Context1 from "./Context API/Context1";
// // import Context3 from "./Context API/Context1";
// import './App.css';

// const firstName = createContext();
// const lastName = createContext();

// function App() {
//        const a = "Often, components in different files will need access to the same context. This is why it’s common to declare contexts in a separate file. Then you can use the export statement to make context available for other files:"
//        const b = "Now the Page component and any components inside it, no matter how deep, will “see” the passed context      values. If the passed context values change, React will re-render the components reading the context as well."

//   return (
//     <>
//       <firstName.Provider value={"Hello world"}>
//                 <Context3/>
//       </firstName.Provider>
//     </>

//      <>
//       <firstName.Provider value={"Hello world"}>
//                 <Context1/> 
//       </firstName.Provider>
//     </> 

//     <>
//       <firstName.Provider value={a}>
//          <lastName.Provider value={b}>
//                <Context3/>
//          </lastName.Provider>
//       </firstName.Provider>
//     </>

//     <>
//       <firstName.Provider value={a}>
//          <lastName.Provider value={b}>
//                <Context1/>
//          </lastName.Provider>
//       </firstName.Provider>
//     </>

//     <>
//       <firstName.Provider value={"Hello"}>
//          <lastName.Provider value={"world"}>
//                <Context3/>
//          </lastName.Provider>
//       </firstName.Provider>
//     </>

//     <>
//     <Context1/>
//     </>

//   );
// }

// export default App;
// export {firstName};
// export {lastName};

// First, you need to create a context object using the createContext function
// This context object will hold the data that you want to share across your application. 
// Create a parent component that wraps child components with a Provider
// reverse heierchy from bootom to top

// create : createContext
// Provider : it is components which works provider
// consumer : it is components which receive data from provider
// firstname ek context hai usse custom components samjhkar use kar rha hu 

//Create context using the createContext method.
// context API vs useContext vs redEXs


// import Hooks1 from './React Hooks/Hooks1'
// {/* <Hooks1/> */}







// import React from 'react'
// import { BrowserRouter, Route, Routes} from 'react-router-dom';
// import Router1 from './Router/Router1';
// import Router2 from './Router/Router2';
// import Router3 from './Router/Router3';
// import Router4 from './Router/Router4';
// import Router5 from './Router/Router5';
// import Main from './Router/Main';

// export default function App() {
//   return (
    // // URL : ADDRESS BAR KE SATH KAISE CONNECT KARTE HAI 
    // <>
    // <BrowserRouter>
    // <Routes>
    //       <Route path='/' element={<div>This is Home page</div>} />
    //       <Route path='/about' element={<div>This is about page : NO need "/"</div>} />
    //       <Route path='/contact' element={<div>This is contact page: NO need "/"</div>} />
    //       <Route path='/service' element={<div>This is service page : NO need "/"</div>} />
    //       <Route path='blog' element={<div>This is blog page : NO need "/"</div>} />
    // </Routes>
    // </BrowserRouter>
    // </>


    // //PAGE KE SATH KAISE CONNECT KARTE HAI 
    // <>
    // <BrowserRouter>
    // <Routes>
    //       <Route path='/' element={<Router1/>} />
    //       <Route path='/about' element={<Router2/>} />
    //       <Route path='/contact' element={<Router3/> } />
    //       <Route path='/blog' element={<Router4/>} />
    // </Routes>
    // </BrowserRouter>
    // </>

    // //LINK KE SATH KAISE CONNECT KARTE HAI 
    // <>
    // <BrowserRouter>
    // <Routes>
    //       <Route path='/' element={<Router1/>} />
    //       <Route path='/about' element={<Router2/>} />
    //       <Route path='/contact' element={<Router3/> } />
    //       <Route path='/blog' element={<Router4/>} />
    // </Routes>
    // </BrowserRouter>
    // </>
    
    // NAVLINK ACTIVE CLASS 
    // //ERROR PAGE KE SATH KAISE CONNECT KARTE HAI 
    // <>
    // <BrowserRouter>
    // <Routes>
    //       <Route path='/' element={<Router1/>} />
    //       <Route path='/about' element={<Router2/>} />
    //       <Route path='/contact' element={<Router3/> } />
    //       <Route path='/blog' element={<Router4/>} />
    //       <Route path='*' element={<Router5/>} />
    // </Routes>
    // </BrowserRouter>
    // </>

    // // //NESTING ROUTING 
    // problem is only home page ke data render ho rha hai and child components ka na hau 
    // <>
    // <BrowserRouter>
    // <Routes>
    //       <Route path='/' element={<Router1/>}>
    //           <Route path='/about' element={<Router2/>} />
    //           <Route path='/contact' element={<Router3/> } />
    //           <Route path='/blog' element={<Router4/>} />
    //           <Route path='*' element={<Router5/>} />
    //       </Route>
    // </Routes>
    // </BrowserRouter>
    // </>

    // // //NESTING ROUTING and shared layout
    // <>
    // <BrowserRouter>
    // <Routes>
    //       <Route path='/' element={<Router1/>}>
    //           <Route path='/about' element={<Router2/>} />
    //           <Route path='/contact' element={<Router3/> } />
    //           <Route path='/blog' element={<Router4/>} />
    //           <Route path='*' element={<Router5/>} />
    //       </Route>
    // </Routes>
    // </BrowserRouter>
    // </>

    // //index props 
    // <>
    // <BrowserRouter>
    // <Routes>
    //       <Route path='/' element={<Main/>}> 
    //           <Route index element={<Router1/>}/>
    //           <Route path='/about' element={<Router2/>} />
    //           <Route path='/contact' element={<Router3/> } />
    //           <Route path='/blog' element={<Router4/>} />
    //           <Route   path='*' element={<Router5/>} />
    //       </Route>
    // </Routes>
    // </BrowserRouter>
    // </>


//   )
// }


// nested routing and shared layout sath mai use hona chahiye otherwise error
// <Route path='/' element={<Router1/>}>  // is par bas header dikhaung 
//    <Route element={<Router1/>}/>  // is par apna home page ka data dikhaunga
//    <Route path='/about' element={<Router2/>} />
//    <Route path='/contact' element={<Router3/> } />
//    <Route path='/blog' element={<Router4/>} />
//    <Route path='*' element={<Router5/>} />
// </Route>


// jab mai <main> is route pe visit karunga to mujhe <main> dikhega basically ek navbar apr iske sath mujhe home page ka data bhi dikhna hai 
// main and home page ka routes same hai "/"
// by default route : main
// index ka matlab agr usko ye path dikha "/" to main ke sath stah jome page ka bhi data dispaly kara dena 








// import React from 'react'
// import NavList1 from './React Router/NavList1';
// import NavList2 from './React Router/NavList2';
// // import NavList3 from './React Router/NavList3';
// import { BrowserRouter, Route, Routes, Navigate} from 'react-router-dom';
// import NavList4 from './React Router/NavList4';
// import SearchFilter from './Router Hooks/SearchFilter';

// export default function App() {
//   return (
//     // <>
//     // <BrowserRouter>
//     //     <Routes>
//     //         <Route exact path='/' element={<NavList1/>}/>
//     //         <Route path='/about' element={<NavList2/>}/>
//     //         <Route path='/about/contact' element={<NavList3/>}/>
//     //     </Routes>
//     // </BrowserRouter>
//     // </>

//     <>
//     <BrowserRouter>
//         <Routes>
//             <Route path='/' element={<NavList1/>}/>
            
//             {/* <Route path='/about' element={<NavList2 />}/> */}
//             <Route path='/about' element={<NavList2 name="Hello world"/>}/>

//             {/* <Route path='/user' element={<NavList3/>}/> */}
//             {/* <Route path='/contact' element={<NavList3/>}/> */}
//             {/* <Route path='/contact' Component={<NavList3/>}/> */}
//             {/* <Route path='/contact' render={<NavList3/>}/> */}

//             {/* <Route path='*' element={<NavList4/>}/> */}
//             <Route path='/user' element={<NavList4/>}/>
//             {/* <Route path='/user/:fname' element={<NavList4/>}/> */}
//             {/* <Route path='/user/:fname/:lname' element={<NavList4/>}/> */}
//             <Route path='/search' element={<SearchFilter/>}/>
//             <Route path='*' element={<Navigate to="/" />}/>
//         </Routes>
//     </BrowserRouter>
//     </>
   
//   )
// }

// Functions are not valid as a React child.This may happen if you return a Component instead of <Component /> from render. Or maybe you meant to call this function rather than return it.
// comonnets and render 
// components :it creates new componnets can call out 
// render : ek bar call hoga componnts and uske badd usi exixiting componnets ko update karte jayeg aand will not create new 

// components : when no props 
// render : when props : jo update karna wala part hota hai and baki sabko usi tarah se render kar deta hai 

// react router ke pass bhi hooks hai e.x
// useHistory/useLocation/useRouteMatch/useparams
// <Route path='/user/:name' element={<NavList4/>}/> 

// :name : this is extra parmeter
// user/ ke baad jo bhi user type karta hai vo hame dukh jana chahoye means hame usko fetch karn ahai 
// jaise vino dlikha to vindha dispaly ho jana chaiye

// user/vinod /dkjdcbkbck
// after user ke baad kafi sare / / / / ho sakte hai to uske liye fname ko {} andar add akrna hoga 

// mai root mai user/vinod after user ke baad ek hi parametr pass kiy aha isliye ek hi data fetch hoga
// user/ddf/dsfsf : define karo pahele main root mai  
// thndo parametr ko dynamacailly fech kar sakte jpapne compnnets mia 




// import React from 'react'
// import SearchFilter from './Router Hooks/SearchFilter';

// export default function App() {
//   return (
//     <>
//     <SearchFilter/>
//     </>
//   )
// }

// // useParam : servie ke andar jo web developemt hai vo dikhayo




import React from 'react'
// import NavHooks1 from './NavHooks/NavHooks1';
// import NavHooks2 from './NavHooks/NavHooks2';
// import NavHooks3 from './NavHooks/NavHooks3';
// import NavHooks4 from './NavHooks/NavHooks4';
// import NavHooks5 from './NavHooks/NavHooks5';
import NavHooks6 from './NavHooks/NavHooks6';
// import NavHooks7 from './NavHooks/NavHooks7';

export default function App() {
  return (
   <>
    {/* <NavHooks1/> */}
    {/* <NavHooks2/> */}
    {/* <NavHooks3/> */}
    {/* <NavHooks4/> */}
    {/* <NavHooks5/> */}
    <NavHooks6/>
    {/* <NavHooks7/> */}
   </>
  )
}


