import React from 'react'

export default function Router5() {
  return (
	<>
		<h2>This is ERROR page</h2>
	</>
  )
}
