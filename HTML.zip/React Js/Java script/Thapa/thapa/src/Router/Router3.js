import React from 'react'
// import { useNavigate } from 'react-router-dom'
// import { Link } from 'react-router-dom'
// import { NavLink } from 'react-router-dom'
// import Header from './Header'

export default function Router3() {

	// const navigate = useNavigate() 
	// const gotohome = () =>{
	// 	// alert("Passed Successfully")
	// 	navigate("/")
	// 	// navigate("/home") : not defined s
	// }
  return (
	// <>
	// <header>
	// <h2>This is Contact page</h2>
	// <nav>
	// 		<ul>
	// 			<li><NavLink to="/">Home</NavLink></li>
	// 			<li><NavLink to="/About">About</NavLink></li>
	// 			<li><NavLink to="Contact">Contact</NavLink></li>
	// 			<li><NavLink to="/Blog">Blog</NavLink></li>
	// 		</ul>
	// 	</nav>
	// 	<img 
	// 		src="https://images.unsplash.com/photo-1597131527856-13cdb8dc050e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mjl8fHZhbnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=600&q=60" 
	// 		alt="..." 
	// 		style={{width: "500px"}}
	// 		/>
	// 	<p >Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque voluptas architecto eaque excepturi inventore porro veritatis officiis provident temporibus velit reiciendis ab dignissimos, sequi repellendus, animi earum dolorem optio est in cum nobis doloribus.</p>
	// </header>
	// </>
	// <>
	// <header>
	// <h2>This is Contact page</h2>
	// <Header/>
	// 	<img 
	// 		src="https://images.unsplash.com/photo-1597131527856-13cdb8dc050e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mjl8fHZhbnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=600&q=60" 
	// 		alt="..." 
	// 		style={{width: "500px"}}
	// 		/>
	// 	<p >Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque voluptas architecto eaque excepturi inventore porro veritatis officiis provident temporibus velit reiciendis ab dignissimos, sequi repellendus, animi earum dolorem optio est in cum nobis doloribus.</p>
	// </header>
	// </>
	<>
	<header>
	<h2>This is Contact page</h2>
		<img 
			src="https://images.unsplash.com/photo-1597131527856-13cdb8dc050e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mjl8fHZhbnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=600&q=60" 
			alt="..." 
			style={{width: "500px"}}
			/>
		<p >Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque voluptas architecto eaque excepturi inventore porro veritatis officiis provident temporibus velit reiciendis ab dignissimos, sequi repellendus, animi earum dolorem optio est in cum nobis doloribus.</p>
		{/* <button type="button" onClick={gotohome}>gotohome</button> */}
	</header>
	</>
  )
}
