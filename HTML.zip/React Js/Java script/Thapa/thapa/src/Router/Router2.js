import React from 'react'
// import { Link } from 'react-router-dom'
// import { NavLink } from 'react-router-dom'
// import Header from './Header'
// import { useNavigate } from 'react-router-dom'

export default function Router2() {	
	// const navigate = useNavigate() 

	//useNavigate() hook : is hook ke andar jo p and m hai vo navigae mai store ho chuka hai 
	//navigate varibake mai ab sare properties and method store ho chuk ahau 

	// ek page se durse page mai redirect/ navigate karneke kiye useNavigate Hook ka use karna padega
	// const gotocontact = () =>{
	// 	// alert("Passed Successfully")
	// 	navigate("/contact")
	// }

  return (
	// <>
	// <header>
	// 	<h2>This is About page</h2>
	// 	<nav>
	// 		<ul>
	// 			<li><Link to="/">Home</Link></li>
	// 			<li><Link to="/About">About</Link></li>
	// 			<li><Link to="/Contact">Contact</Link></li>
	// 			<li><Link to="/Blog">Blog</Link></li>
	// 		</ul>
	// 	</nav>
	// 	<img 
	// 		src="https://plus.unsplash.com/premium_photo-1676122796020-19c6df3a78b5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8dmFufGVufDB8fDB8fHww&auto=format&fit=crop&w=600&q=60" 
	// 		alt="..." 
	// 		style={{width: "500px"}}
	// 		/>
	// 	<p >Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque voluptas architecto eaque excepturi inventore porro veritatis officiis provident temporibus velit reiciendis ab dignissimos, sequi repellendus, animi earum dolorem optio est in cum nobis doloribus.</p>
	// </header>
	// </>

	// <>
	// <header>
	// 	<h2>This is About page</h2>
	// 	<nav>
	// 		<ul>
	// 			<li><NavLink to="/">Home</NavLink></li>
	// 			<li><NavLink to="/About">About</NavLink></li>
	// 			<li><NavLink to="/Contact">Contact</NavLink></li>
	// 			<li><NavLink to="/Blog">Blog</NavLink></li>
	// 		</ul>
	// 	</nav>
	// 	<img 
	// 		src="https://plus.unsplash.com/premium_photo-1676122796020-19c6df3a78b5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8dmFufGVufDB8fDB8fHww&auto=format&fit=crop&w=600&q=60" 
	// 		alt="..." 
	// 		style={{width: "500px"}}
	// 		/>
	// 	<p >Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque voluptas architecto eaque excepturi inventore porro veritatis officiis provident temporibus velit reiciendis ab dignissimos, sequi repellendus, animi earum dolorem optio est in cum nobis doloribus.</p>
	// </header>
	// </>

// 	<>
// 	<header>
// 		<h2>This is About page</h2>
// 		<Header/>
// 		<img 
// 			src="https://plus.unsplash.com/premium_photo-1676122796020-19c6df3a78b5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8dmFufGVufDB8fDB8fHww&auto=format&fit=crop&w=600&q=60" 
// 			alt="..." 
// 			style={{width: "500px"}}
// 			/>
// 		<p >Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque voluptas architecto eaque excepturi inventore porro veritatis officiis provident temporibus velit reiciendis ab dignissimos, sequi repellendus, animi earum dolorem optio est in cum nobis doloribus.</p>
// 	</header>
// 	</>
//   )

	<>
	<header>
		<h2>This is About page</h2>
		<img 
			src="https://plus.unsplash.com/premium_photo-1676122796020-19c6df3a78b5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8dmFufGVufDB8fDB8fHww&auto=format&fit=crop&w=600&q=60" 
			alt="..." 
			style={{width: "500px"}}
			/>
		<p >Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque voluptas architecto eaque excepturi inventore porro veritatis officiis provident temporibus velit reiciendis ab dignissimos, sequi repellendus, animi earum dolorem optio est in cum nobis doloribus.</p>


		{/* {this si callback function or anonymous funtion s}
		<button type="button" onClick={()=>{
			gotocontact()
		}}>Go to Contact Page</button><br /><br />
		<button type="button" onClick={()=>{navigate(-1)}}>Go back</button> */}

	</header>
	</>

	
  )
}
