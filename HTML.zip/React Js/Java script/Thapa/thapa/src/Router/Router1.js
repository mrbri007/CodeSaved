import React from 'react'
import Header from './Header'
// import { Link } from 'react-router-dom'
// import { NavLink } from 'react-router-dom'
// import Header from './Header'
// import { Outlet } from 'react-router-dom'

export default function Router1() {
  return (
	// // URL : ADDRESS BAR KE SATH KAISE CONNECT KARTE HAI 
	// <>
	// <div>
	// 	<h1>Router 1</h1>
	// 	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellendus dolorem dolor animi maxime voluptatum, doloribus aut cumque, tenetur similique explicabo repellat dolore quia quas atque eum commodi ipsum itaque laborum. Excepturi ad repellat alias.</p>
	// </div>
	// </>

    // //PAGE KE SATH KAISE CONNECT KARTE HAI 
	// <>
	// <header>
	// <h2>This is Home Page</h2>
	// 	<nav>
	// 		<ul>
	// 			<li>Home</li>
	// 			<li>About</li>
	// 			<li>Contact</li>
	// 			<li>Blog</li>
	// 		</ul>
	// 	</nav>
	// </header>
	// </>


    // //LINK KE SATH KAISE CONNECT KARTE HAI 
	// <>
	// <header>
	// 	<h2>This is Home Page</h2>
	// 	<nav>
	// 		<ul>
	// 			<li><Link to="/">Home</Link></li>
	// 			<li><Link to="/About">About</Link></li>
	// 			<li><Link to="Contact">Contact</Link></li>
	// 			<li><Link to="/Blog">Blog</Link></li>
	// 		</ul>
	// 	</nav>
	// 	<img 
	// 		src="https://images.unsplash.com/photo-1532015804402-87817ed02d2a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NjN8fHZhbnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=600&q=60" 
	// 		alt="..." 
	// 		style={{width: "500px"}}
	// 		/>
	// 	<p >Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque voluptas architecto eaque excepturi inventore porro veritatis officiis provident temporibus velit reiciendis ab dignissimos, sequi repellendus, animi earum dolorem optio est in cum nobis doloribus.</p>
	// </header>
	// </>



    // //NAVLINK KE SATH KAISE CONNECT KARTE HAI 
	// <>
	// <header>
	// 	<h2>This is Home Page</h2>
	// 	<nav>
	// 		<ul>
	// 			<li><NavLink to="/">Home</NavLink></li>
	// 			<li><NavLink to="/About">About</NavLink></li>
	// 			<li><NavLink to="Contact">Contact</NavLink></li>
	// 			<li><NavLink to="/Blog">Blog</NavLink></li>
	// 		</ul>
	// 	</nav>
	// 	<img 
	// 		src="https://images.unsplash.com/photo-1532015804402-87817ed02d2a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NjN8fHZhbnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=600&q=60" 
	// 		alt="..." 
	// 		style={{width: "500px"}}
	// 		/>
	// 	<p >Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque voluptas architecto eaque excepturi inventore porro veritatis officiis provident temporibus velit reiciendis ab dignissimos, sequi repellendus, animi earum dolorem optio est in cum nobis doloribus.</p>
	// </header>
	// </>
    //NAVLINK KE SATH KAISE CONNECT KARTE HAI 


	// //ERROR PAGE ROUTE
	// <>
	// <header>
	// 	<h2>This is Home Page</h2>
	// 	<Header/>
	// 	<img 
	// 		src="https://images.unsplash.com/photo-1532015804402-87817ed02d2a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NjN8fHZhbnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=600&q=60" 
	// 		alt="..." 
	// 		style={{width: "500px"}}
	// 		/>
	// 	<p >Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque voluptas architecto eaque excepturi inventore porro veritatis officiis provident temporibus velit reiciendis ab dignissimos, sequi repellendus, animi earum dolorem optio est in cum nobis doloribus.</p>
	// </header>
	// <Outlet/>
	// </>


	// //ERROR PAGE ROUTE
	// <>
	// <header>
	// 	<Header/>
	// 	<Outlet/>
	// </header>
	// </>

	
	//ERROR PAGE ROUTE
	<>
	<header>
		<h2>This is Home Page</h2>
		<img 
			src="https://images.unsplash.com/photo-1532015804402-87817ed02d2a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NjN8fHZhbnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=600&q=60" 
			alt="..." 
			style={{width: "500px"}}
			/>
		<p >Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque voluptas architecto eaque excepturi inventore porro veritatis officiis provident temporibus velit reiciendis ab dignissimos, sequi repellendus, animi earum dolorem optio est in cum nobis doloribus.</p>
	</header>
	</>

  )
}


// <Outlet/> : kisi particular components ko sabke sath shrae karna ho to whther it is about / blog / contact 
// An <Outlet> should be used in parent route elements to render their child route elements.
// is used within the parent route element to indicate where a child route element should be rendered. 
// parents ka data + child ka data dono sath mai render honge
// home page ab ek navbar ki tarha kam kar rh hai jo har jagah render ho rha hai 
// par w what about home page ka use mebhi to data rahnea chahiye 
// home ke pass bas ek header jo apne child compents share kar rh ahi
// home ke pass jo bhi data hai by default uske chil compon mai dikhega 



