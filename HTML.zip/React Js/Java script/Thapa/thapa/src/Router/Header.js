import React from 'react'
import { NavLink } from 'react-router-dom'


export default function Header() {
  return (
	<>
	<header>
		<nav>
			<ul>
				<li><NavLink to="/">Home</NavLink></li>
				<li><NavLink to="/About">About</NavLink></li>
				<li><NavLink to="/Contact">Contact</NavLink></li>
				<li><NavLink to="/Blog">Blog</NavLink></li>
				<li><NavLink to="/error">Error</NavLink></li>
			</ul>
		</nav>
	</header>
	</>
  )
}
