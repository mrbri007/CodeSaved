import React from 'react'

export default function SearchUser(props) {
	const randomImg= `https://source.unsplash.com/random/100×100/?${props.name}`
  return (
	<>
	<img src={randomImg} alt="..." />
	</>
  )
}



// not datbase mot json
// <h1>This is ERROR page </h1>
// <NavLink to "/"> go back </NavLink>
//<a href="/"> go back </a>