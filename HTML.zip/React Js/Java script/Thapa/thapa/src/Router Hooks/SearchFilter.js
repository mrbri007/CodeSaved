import React, { useState } from 'react'
import NavList3 from '../React Router/NavList3'
import SearchUser from './SearchUser'

export default function SearchFilter() {
	// const [text, settext] = useState("fruits")
	// const [text, settext] = useState("computer")
	const [text, settext] = useState("")
	const InputEvent = (event)=>{
		// const userInfo  = event.target.value
		// console.log(userInfo)
		// settext(userInfo)

		settext(event.target.value)
	}

  return (
	  <>
		<NavList3/>
		<h2> This is SEARCH Page </h2>
		<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Veritatis vel at voluptate labore! Itaque, incidunt eum vitae voluptate aperiam atque distinctio nostrum alias aliquam perferendis delectus deleniti perspiciatis, minima rem nisi, quas architecto soluta.</p>
		<input type="text" placeholder='Search' value={text} className='searchbar searchbarINput' onChange={InputEvent} />
		{/* <SearchUser name={text}/> */}
		{text === "" ? null : <SearchUser name={text}/> }
	</>
  )
}

// input ke satb kam karte samaay onchange event use karte hai 
// event object  as aprops and uski evevnt proipserties and method use kar sakte hai 
// ye event ibject yab milt ahai jab aap event handler use karte ha 
