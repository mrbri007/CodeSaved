import React from "react";
import Button from '@mui/material/Button';

export default function Nav2() {
  return (
    <>
      <div>
        <h1 className="bg-orange-700 text-s text-6xl">Tailwind CSS </h1>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam
          unde praesentium porro eaque minima recusandae id quo asperiores velit
          esse harum itaque voluptates ex, consequuntur eius quis omnis sit?
          Ipsa vel ullam dicta? Quam quod quidem, maiores labore temporibus
          necessitatibus!
        </p>
      </div>

      <div>
        <h1 className="bg-primary text-white">Bootstrap CSS</h1>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam
          unde praesentium porro eaque minima recusandae id quo asperiores velit
          esse harum itaque voluptates ex, consequuntur eius quis omnis sit?
          Ipsa vel ullam dicta? Quam quod quidem, maiores labore temporibus
          necessitatibus!
        </p>
      </div>

      <div>
        <h1 className="primary.main">Material UI </h1>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam
          unde praesentium porro eaque minima recusandae id quo asperiores velit
          esse harum itaque voluptates ex, consequuntur eius quis omnis sit?
          Ipsa vel ullam dicta? Quam quod quidem, maiores labore temporibus
          necessitatibus!
        </p>
		<Button variant="contained">Contained</Button>
      </div>

    </>
  );
}
