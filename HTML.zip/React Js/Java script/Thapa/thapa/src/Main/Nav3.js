import React from "react";

export default function Nav3() {
  return (
    <>
      <h2 className="text-center text-danger text-capitalize my-5">Welcome to Metaverse </h2>
      <div className="container">
        <div className="row">
          <div className="col-sm">
				<div className="card" style={{ width: "18rem" }}>
				<img className="card-img-top" src="https://images.unsplash.com/photo-1682686580003-22d3d65399a8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHw2Nnx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=60" alt="" height="200px"/>
				<div className="card-body">
					<h5 className="card-title">Card title</h5>
					<p className="card-text">
					Some quick example text to build on the card title and make up
					the bulk of the card's content.
					</p>
					<a href="..." className="btn btn-primary">Go somewhere</a>
				</div>
				</div>
          </div>

          <div className="col-sm">
		  <div className="card" style={{ width: "18rem" }}>
				<img className="card-img-top" src="https://images.unsplash.com/photo-1682686580003-22d3d65399a8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHw2Nnx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=60" alt="" height="200px"/>
				<div className="card-body">
					<h5 className="card-title">Card title</h5>
					<p className="card-text">
					Some quick example text to build on the card title and make up
					the bulk of the card's content.
					</p>
					<a href="..." className="btn btn-primary">Go somewhere</a>
				</div>
				</div>
		  </div>

          <div className="col-sm">
		  <div className="card" style={{ width: "18rem" }}>
				<img className="card-img-top" src="https://images.unsplash.com/photo-1682686580003-22d3d65399a8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHw2Nnx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=60" alt="" height="200px"/>
				<div className="card-body">
					<h5 className="card-title">Card title</h5>
					<p className="card-text">
					Some quick example text to build on the card title and make up
					the bulk of the card's content.
					</p>
					<a href="..." className="btn btn-primary">Go somewhere</a>
				</div>
				</div>
		  </div>
        </div>
      </div>
    </>
  );
}
