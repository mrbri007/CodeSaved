import React, {useState} from 'react'
import Button from '@mui/material/Button';
import Tooltip from '@mui/material/Tooltip';

export default function TodoList() {
	const [listName, setlistName] = useState(0)
	const Increment = () =>{
		setlistName(listName + 1)
	}
	
	const Decrement = () =>{
		if (listName > 0) {
			setlistName(listName - 1)
		} else{
			setlistName(0)
			alert("Reached")
		}
	}
  return (
	<>
		<div className="container">
			<div className="main">
				<h1 className='heading'>Note Taking Apps</h1>
				<h2 className='heading' style={{marginLeft :"70px"}}>{listName}</h2>
				<div className="btn_section">
					<button onClick={Increment} type='button' variant="contained">Increment</button>
					<button onClick={Decrement} type='button' style={{marginLeft :"10px"}}>Decrement</button> 
					<br/>
					<br/>
					<Tooltip title="Increment">
						<Button onClick={Increment} type='button' variant="outlined" >Increment</Button>
					</Tooltip>
					<Tooltip title="Decrement">
						<Button onClick={Decrement} type='button' style={{marginLeft :"10px"}} variant="contained">Decrement</Button>
					</Tooltip>
				</div>
			</div>
		</div>

	</>
  )
}

// materila ui ke component ko use karne ke liyte fisrt iport and uye
