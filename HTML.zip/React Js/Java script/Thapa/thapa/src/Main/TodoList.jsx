import React, {useState} from 'react'
// import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
// import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';

export default function TodoList() {
	const [listName, setlistName] = useState(0)
	const Increment = () =>{
		setlistName(listName + 1)
	}
	
	const Decrement = () =>{
		if (listName > 0) {
			setlistName(listName - 1)
		} else{
			setlistName(0)
			alert("Reached")
		}
	}
  return (
	<>
		<div className="container">
			<div className="main">
				<h1 className='heading'>Note Taking Apps</h1>
				<h2 className='heading' style={{marginLeft :"70px"}}>{listName}</h2>
				<div className="btn_section">
					<button onClick={Increment} type='button'>Increment</button>
					<button onClick={Decrement} type='button' style={{marginLeft :"10px"}}>Decrement</button>

					{/* Materila Icons */}
					{/* <button onClick={Increment} type='button'><ArrowBackIosIcon/></button> */}
					{/* <button onClick={Decrement} type='button' style={{marginLeft :"10px"}}><ArrowForwardIosIcon/></button> */}

					{/* Fontawesome Icons */}
					{/* <button onClick={Increment} type='button'><i class="fa-regular fa-plus"></i></button> */}
					{/* <button onClick={Decrement} type='button' style={{marginLeft :"10px"}}><i class="fa-regular fa-clipboard"></i></button> */}
					
				</div>
			</div>
		</div>

	</>
  )
}


// fontawesome vs material Ul : 
// NO major differce but the processs is a little bit different
// fontawesome ke liye cdn and icon and if not cdn and then it will throw an error 
// materila ui : two process import and use 