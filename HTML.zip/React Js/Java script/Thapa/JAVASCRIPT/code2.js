// JS Advance
		// falsy value : 0 false null undefined NaN document.all
		// truty value : all expect falsy value 
		// Integer value (7) or string value ("Harsh") 
		// if (7) {
		// 	console.log('Passed successfully');
		// } else {
		// 	console.log('Failed successfully');
		// }

		// js mein kai saare feautures hai par kuch feautures aise hai jo js mai nahi hai par phirbhi hum use kar sakte hai jisse window kahete hai, window is box of feature given by browser to use with javascript
			
		// Classes
		// OOPS
		// Asynchronous
		// Async
		// Promises
		// Callbacks
		// Async/Await
		// JSON
		// jQuery
		// AJAX
	


// AJAX
		// AJAX just uses a combination of:
		// A browser built-in XMLHttpRequest(class) object (to request data from a web server)
		// JavaScript and HTML DOM (to display or use the data)

		// HTTP response status codes indicate whether a specific HTTP request has been successfully completed. Responses are grouped in five classes:
		// Informational responses (100 – 199)
		// Successful responses (200 – 299)
		// Redirection messages (300 – 399)
		// Client error responses (400 – 499)
		// Server error responses (500 – 599)

		// AJAX stands for Asynchronous(multiple task at one time) JavaScript And XML(data format)
		// JSON NEW Method and XML OLD Method to send data
		// modern website use JSON instead or xml for data transfer
		// AJAX is a technique for accessing fast and dynamic web pages (like react router)
		
		// How AJAX works 
		// web browser -- request(particular web page) -- web server -- response(file, data) -- web browser 
		// Note : In this process web pages ka content refresh ho jata hai

		// web browser -- request(particular web page) through XMLHttpRequest -- web server -- response -- web browser 
		// without refeshing web pages(content)
		// content format : text file/ xml data / json data

		// 5 step process : readystate(name)
		// readystate(0) : request not intialized
		// readystate(1) : server connection established
		// readystate(2) : request recevied by server
		// readystate(3) : processing request by server
		// readystate(4) : request fincished and response is ready

		// Server : resonse format(2)
		// 1. responseText or responseXML  
		// 2. status : // code: response proper aaaya hai ki nah 
		// so many status code but mainly used  status code
		// 200 : "ok"           // request = proper response
		// 403 : "forbidden"	// request = not responding proper dut to some reason
		// 404 : "Not found"	// request = does not exist file in server



		// AJAX : OLD Method [ES5]
		// function loadData(){
		// 	const xhttp = new XMLHttpRequest() 

		// onreadystatechange: Defines a function to be called when the readyState property changes
		// 	xhttp.onreadystatechange = function(){
		// 		if (this.readyState == 4 && this.status == 200) {
		// 			document.getElementById("para").innerHTML = (this.responseText);
		// 			console.log(this.responseText);
		// 		} 
		// 		else if (this.readyState == 4 && this.status == 400){
		// 			document.getElementById("para").innerHTML = (this.responseText);
		// 			console.log(this.responseText);
		// 		}
		// 	}
		// 	xhttp.open("GET",'readme.txt',true) //true : false = Asynchronous
		// 	xhttp.send()
		// }

		// Shorter way
		// function loadData() {

		// 	// Create an XMLHttpRequest object
		// 	const xhttp = new XMLHttpRequest();

		// 	// Define a callback function
		// 	xhttp.onload = function() {

		// 	// Here you can use the Data
		// 	//   document.getElementById("para").innerHTML = this.responseText; 
		// 	  console.log(this.responseText);
			  
		// 	  //	Returns the response data as a string
		// 	  //	Returns the response data as a XML data
		// 	}

		// 	// xhttp.open("GET", "readme.txt", true);
		// 	// xhttp.open("GET", "https://jsonplaceholder.typicode.com/posts", true);
		// 	xhttp.open("GET", "readme.json", true);
		// 	xhttp.send();
		// }
		
		// Send a request
		// open(method, url, async,)
		// method: the request type GET or POST
		// url: the file location
		// The file can be any kind of file, like .txt and .xml, or server scripting files like .asp and .php 
		// async: true (asynchronous) or false (synchronous)
		// (async = false) is not recommended because the JavaScript will stop executing until the server response is ready. 
		// If the server is busy or slow, the application will hang or stop.
		// Fetch API : NEW Method [ES6]

		//Fetching or requesting data from server or database to web pages : USE AJAX
		// AJAX with jquery and php 


		// why use  AJAX
		// better user experinece 
		// no page reload/ refresh 
		// interactive 
		// saves network bandwith ( the capacity at which a network can transmit data.)

		//Data can be transfered in any format and protocol(https, http) : .txt .php .asp .json(popular) .html
		// AJAX use XMLhttpRequest object(xhr object)(in-built object) : has object methods and properties
		// vanilla(pure) javascript means without using any js library or framework

