// Map() : Like forEach function and return Array // create a new array
// 		let arr = [10, 45, 67, 89, 92]
// 		arr.map((value , index, array) => {
// 		console.log(value, index, array);
// 		})
// 		let a = arr.map((value , index, array) => {
// 			console.log(value, index, array);
// 			//retrun new array with thr given statement
// 			return value + index
// 		})
// 		console.log(a);
// 		Map return always something you ahve givne something to return
// 		let table = [10,20,30,40,50]
// 		let result = table.map((value)=>{
// 			value++
// 			console.log(value);
// 			// return value * 2
// 		})
// 		console.log(table); // does not change original array

// 		let table = [10, 20, 30, 40, 50]
// 		let result = table.forEach(value => {
// 			value++
// 			console.log(value);
// 		})
// 		console.log(table); 
		
// 		console.log(result);
// 		// foreach return nothing : always undefined
// 		let result1 = table.forEach((value)=>{
// 			console.log(value * 2);
// 			return value * 2
// 		})
// 		console.log(result1);

// 		const product = [
// 			{
// 				Accessories : "Mac",
// 				Price : "M100",
// 			},
// 			{
// 				Accessories : "ipad",
// 				Price : "M200",
// 			},
// 			{
// 				Accessories : "Watch",
// 				Price : "M300",
// 			}
// 		]
		
// 		let acc = product.map(value=> {return (value.Price +" "+ value.Accessories)})
// 		console.log(acc); // to print the value
		


// Filter() : Like forEach function and return Array
// 		condtion true (return) and false (unreturn) 
// 		let arr = [10,45,67,89,92]
// 		let a = arr.filter((a) => {
// 			return a > 50
// 		})
// 		console.log(a);

// 		Real life example 
// 		// console.table(["Audi", "Volvo", "Ford"]);
// 		const player = [
// 			{
// 				name:'Ronaldo',
// 				age :37,
// 				team : ["Madrid", "United"]
// 			},
// 			{
// 				name:'Messi',
// 				age :30,
// 				team : ["rome", "liverpool"]
// 			},
// 			{
// 				name:'Neymar',
// 				age :22,
// 				team : ["dortmund", "city"]
// 			},
// 			{
// 				name:'Haaland',
// 				age :31,
// 				team : ["wolfburg", "city"]
// 			}
// 		];
// 		let a = player.filter(p=> {
// 			return p.age<30
// 		})
// 		console.log(a);
// 		let a = player.filter(b=> {
// 			return b.team.includes("city")
// 		})
// 		console.log(a);
		

// reduce() : return sigle value and addition
// 		This is how addition is done 
// 		1 + 2 = 3
// 		3 + 3 = 6
// 		6 + 4 = 10
// 		10 + 5 = 15
// 		let arr = [1,2,3,4,5]
// 		// let e = arr.reduce((a , b) => {
// 		// 	return a + b
// 		// })
// 		const q = (a , b) => {
// 			return a + b}
// 		let e = arr.reduce(q)
// 		console.log(e);


// forEach() method
// 		The forEach() method calls a function for each element in an array.
// 		array.forEach(function(Value, index, array){}) // it takes three value
// 		variable (Value, index, array) name kuch bhi le sakte hai and imp is order
// 		const cars = ["Saab", "Volvo", "BMW"];
// 		cars.forEach((element1, element2, element3) => {
// 			console.log(element1);
// 			console.log(element2);
// 			console.log(element3);
// 		});
// 		cars.forEach(myfun);
// 		function myfun(element1, element2, element3){
// 				console.log(element1);
// 				console.log(element2);
// 				console.log(element3);
// 			}
// 			let a = function(element1, element2, element3){
// 				console.log(element1);
// 				console.log(element2);
// 				console.log(element3);
// 			}
// 		   cars.forEach(a);
// 			let a = (element1, element2, element3)=>{
// 				console.log(element1);
// 				console.log(element2);
// 				console.log(element3);
// 			}
// 		   cars.forEach(a);
		


		
	
