const a = [
	{
		fname : "elon musk",
		lname : "Doe",
	},
	{
		fname : "steve",
		lname : "Doe",
	},
	{
		fname : "bill",
		lname : "Doe",
	},
]

// console.table(a)
// console.table(a, ['lname'])