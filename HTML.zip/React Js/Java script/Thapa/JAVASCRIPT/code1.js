// Array Destructing : (Key : value)
	// const myarr1 = ['lorem_1', 'lorem_2', 'lorem_3', 'lorem_4']
	// const [a, b,c,d,e]  =  myarr1
	// console.log(a); // lorem1
	// console.log(b); // lorem2
	// console.log(e); // undefined value
	// // you can also skip the value
	// const myarr2 = ['hello_1', 'hello_2', 'hello_3', 'hello_4']
	// const [e,,,h]  =  myarr2
	// console.log(e); // hello_1
	// console.log(h); // hello_4

	// //   Object Destructing
	//   const friend = {
	//   	fname : "John",
	//   	lname : "doe"
	// }

	//   const friend = {
	//   	fname : "John",
	//   	lname : "doe",
	// 	age : 78
	// }

	// let {fname, lname, age} = friend
	// console.log(fname);
	// console.log(lname);
	// console.log(age);

	// Not like an array
	// let {fname, age} = friend
	// console.log(fname);
	// console.log(age);

	// alias name : shortcut
	// let {fname : f, age : a} = friend
	// console.log(f);
	// console.log(a);

	//   function myfun(friend){
	//   	console.log(friend.fname);
	//   	console.log(friend.lname);}
	//   myfun(friend)

	//   function myfun({fname,lname}){
	//   	console.log(fname);
	//   	console.log(lname);}
	//   myfun(friend)

	//   function hello(){
	//   	return(console.log('The return statement stops the execution of a function and returns a value.'))
	//   	console.log('The return statement stops the execution of a function and returns a value.');
	//   }
	//   hello()


// NOTE : by yahoo baba
// Destructing Arrays
		// Here is the old way of assigning array items to a variable:

		// const company = ['Apple', 'Google', 'Microsoft', 'Facbook', "Netflix"];

		// // old ways
		// const Tech1 = company[0]
		// const Tech2 = company[1]
		// const Tech3 = company[2]
		// const Tech4 = company[3]
		// const Tech5 = company[4]
		// console.log(Tech1, Tech2, Tech3, Tech4, Tech5 );

		// // new ways
		// // const [lorem1,,,,lorem5] = company
		// // console.log(lorem1, lorem5 );
		// const [lorem1, lorem2, lorem3, lorem4, lorem5  ] = company
		// console.log(lorem1, lorem2, lorem3, lorem4, lorem5 );

		// // Destructuring comes in handy when a function returns an array:
		// function calculate(a, b) {
		//   const add = a + b;
		//   const subtract = a - b;
		//   const multiply = a * b;
		//   const divide = a / b;

		//   return [add, subtract, multiply, divide];
		// }

		// const [add, subtract, multiply, divide] = calculate(4, 7);
		// console.log(add, subtract, multiply, divide);



// Destructuring Objects
		// const car = {brand: 'Ford',model: 'Mustang',type: 'car',year: 2021, color: 'red'}
		//old ways
		// function myfun(param1) {
		// 	console.log(param1.brand, param1.model, param1.color);
		// }
		// myfun(car)
		//New way
		// function myfun({brand, model, year, color}) {
		// 	console.log(brand +" "+ model +" "+ year +" "+ color);
		// }
		// myfun(car)

		// 	const car = {
		// 	brand: 'Ford',
		// 	model: 'Mustang',
		// 	type: 'car',
		// 	registration: {
		// 			city: 'Houston',
		// 			state: 'Texas',
		// 			country: 'USA'}
		// 	}

		// function myfun({brand, registration:{country}}) {
		// 	console.log(brand +" "+ country);

		// }
		// myfun(car)



//Rest opertor : last mai hona chahiye
		// arguments :In-built function and typeof object return

		// function sum(a, b) {
		// 	console.log(a + b);}
		// sum(10, 20)
		// sum(10, 20, 30, 40) // Throw Error because only two arguement will be added

		// before Rest Opertor : problem with string means (string + number)
		// function sum() {
		// 	console.log(arguments);
		// 	let addition = 0;
		// 	for( let i in arguments){
		// 		addition += arguments[i]
		// 	}
		// 	console.log(addition);
		// }
		// sum(10, 20, 30, 40)

		// After Rest opertor : problem solved : convert to array
		// function sum(name, ...rest_arguments) {
		// 	console.log(arguments);
		// 	let addition = 0;
		// 	for( let i in rest_arguments){
		// 		addition += rest_arguments[i]
		// 	}
		// 	console.log(addition);
		// 	console.log(name);
		// }
		// sum("Hello world", 20, 30, 40)
		// sum("Hello world", 20, 30, 40, 50, 60)

		// rest opertor deal with multiple function argument value for example
		// rest opertor convert multiple argument into one array
		// here it assume array as a argument with one value(20,30,40)
		// Note :Only two argument ( string + array )

		// Wrong way because it(rest opertor) will be considered one arguement
		// let arr = [20, 30, 100]
		// sum("Hello world", arr)



// Spread opertor : array as a argument
		// convert array into multiple argument
		// Note : four argument ( string + indiviual value )
		// sum("Hello world", ...arr)

		// NoTE : when using function
		// Rest Opertor : Function declaration
		// Spread opertor : Function calling

		// let arr1 = [10, 20, 30 ,40 ,50]
		// console.log(arr1);

		// No more array value , seperated and indivual value
		// console.log(...arr1);

		// clone of array for example
		// let arr2 = arr1
		// arr1.push(50)

		// console.log(arr1);
		// console.log(arr2);

		//Using Spread Opertor
		// array ko clone nahi ho rha hai : can not update
		// array2 mai spread opertor ko assaign kar diya hai
		// let arr2 = [...arr1]
		// arr1.push(50)

		// console.log(arr1);
		// console.log(arr2);

		// console.log([...arr1]);

		// Array concating
		// let arr2 = [60, 70, 80]
		// let arr3 = arr1.concat(arr2)

		// Spread opertor : no need of using concating
		// first add arr1 and then arr2
		// let arr3 = [...arr1, ...arr2]

		// Sequence changing
		// let arr3 = [...arr2, ...arr1]

		// Adding more value
		// let arr3 = [1000 , ...arr2, ...arr1 , 3000]
		// console.log(arr3);

		// object concating
		//  let obj1 = {
		// 	fname : "John",
		// 	age : 100
		//  }

		//  let obj2 = {
		// 	lname : "Doe",
		// 	age : 10
		//  }

		//  let obj3 = {...obj1 , ...obj2}
		//  console.log(obj3);



// Array destructing
		// const user = ["Hello", "world"]
		// console.log(user[0] + user[1]);

		// const user = ["Hello", "world"]
		// const [a, b, c] = user
		// console.log(c); //undefined value

		// const user = [ , ,100]
		// const [a, b, c] = user
		// console.log(a);
		// console.log(b);
		// console.log(c);

		// const user = ["Hello", "world" ,100]
		// const [a, b, c] = user
		// console.log(a);
		// console.log(b);
		// console.log(c);

		// const user = ["Hello", ,100]
		// const [a, b="default value", c] = user
		// console.log(a);
		// console.log(b);
		// console.log(c);

		// // Nested array
		// const user = ["Hello", ["male", 1000]]
		// const [a, [gender, salary]] = user
		// console.log(a);
		// console.log(gender);
		// console.log(salary);

		// We can also swap(exchange) values using array destructuring
		// For Example
		// let a = 1;
		// let b = 2;
		// [a, b] = [b, a];
		// console.log(a, b);
		// For Example elements in array
		// let arr = [1, 2, 3];
		// [arr[0], arr[1], arr[2]] = [arr[2], arr[1], arr[0]];
		// console.log(arr);

		// Rest opertor : converted remaining items into array
		// const user = ["Hello", "world" ,100]
		// const [a, ...remaining] = user
		// console.log(a);
		// console.log(remaining);

		//Array destructing in function
		// function user([a, b , c]){
		// 	console.log(a);
		// 	console.log(b);
		// 	console.log(c);
		// }
		// function argument as a array
		// user(["Prime", "Minister", 2024])

		// user return value as array
		// function user(){
		// 	return ["Prime", "Minister", 2024]
		// }
		// user()
		// //array value ko assign kar deta hu alaga alag varible mai
		// let[a, b, c] = user()
		// console.log(a);
		// console.log(b);
		// console.log(c);

// Strict mode
