// Promise and catch
			// 3 state : Pending / fulfilled / failed
			// condition specify - two result
			// if fulfilled means resolve() and then()
			// if failed means reject() and catch()
			// automatically get called based on the condition
			// then and catch : callback function(inbuilt)
			// let complete = true ;
			// prom ek ibject hai jisme ek promise function hai
			// let prom = new Promise(function(resolve, reject){
			// 	if (complete) {
			// 		resolve("Passed Successfully")
			// 	} else {
			// 		reject("Failed Successfull")
			// 	}
			// })
			// console.log(prom);
			// function prom(complete) {
			// 	return new Promise(function(resolve, reject){
			// 		if (complete) {
			// 			resolve("Passed Successfully")
			// 		} else {
			// 			reject("Failed Successfull")
			// 		}
			// 	})
			// }
			// console.log(prom(true));
			// function prom(complete) {
			// 	return new Promise(function(resolve, reject){
			// 		if (complete) {
			// 			resolve("Passed Successfully")
			// 		} else {
			// 			reject("Failed Successfull")
			// 		}
			// 	});
			// }
			// let onfulfilment = (result) =>{
			// 	console.log(result)}
			// let onrejection = (error) =>{
			// 	console.log(error)}
			// // upar ke function ko call karne ke liye then and catch callback function ka use kareneg
			// // isme do function call ho rahe hai
			// prom(true).then(onfulfilment)
			// prom(false).catch(onrejection)
			// function prom(complete) {
			// 	return new Promise(function(resolve, reject){
			// 		console.log('Fetching Data');
			// 		setTimeout(() => {
			// 			if (complete) {
			// 				resolve("Passed Successfully")
			// 			} else {
			// 				reject("Failed Successfull")
			// 			}
			// 		}, 3000);
			// 	});
			// }
			// function prom() {
			// 	return new Promise(function(resolve, reject){
			// 		console.log('Fetching Data');
			// 		setTimeout(() => {
			// 			fetch("https://jsonplaceholder.typicode.com/users")
			// 			.then((response)=>{
			// 				return (response.text());
			// 			})
			// 			.then((result)=>{
			// 				console.log(result);
			// 			})
			// 		}, 5000)
			// 	});
			// }
			// function prom(a,b) {
			// 	return new Promise(function(resolve, reject){
			// 		console.log('Fetching Data');
			// 		let d = a/b
			// 		setTimeout(() => {
			// 			if (d) {
			// 				resolve(`Your answer is : ${d}`)
			// 			} else {
			// 				reject("Failed Successfull")
			// 			}
			// 		}, 3000);
			// 	});
			// }
			// let onfulfilment = (result) =>{
			// console.log(result)}
			// let onrejection = (error) =>{
			// console.log(error)}
			// prom(true).then(onfulfilment)
			// prom(false).catch(onrejection)
			// prom(true).then(onfulfilment).catch(onrejection)
			// prom(true).then((result) =>{
			// console.log(result)
			// }).catch((error) =>{
			// console.log(error)
			// })
			// prom(3,4).then((result) =>{
			// 	console.log(result)
			// }).catch((error) =>{
			// 	console.log(error)
			// })
			// prom().then((result) =>{
			// 	console.log(result)
			// }).catch((error) =>{
			// 	console.log(error)
			// })

// Closure
			// Global Variables are the variables that can be accessed from anywhere in the program.
			// a closur is a function having access to the parent Scoop. it preserve the adta from outside
			// can not access from outside
			// for every closure
			// 1. local scope
			// 2. Global scope
			// 3. outer function scope (function inside function)
			// 	  outer function inside inner function (has access outer function's varible)
			// nested function = closure function
			// var a = 20
			// function myfun() {
			// 	var b = 10;
			// 	console.log(a+b);
			// }
			// myfun()
			// jab hum inner function mai outer function ke varibkle ko access karte hai then it becomes closure function
			// outer function cant access vaible form inner function but inner function can do thsis !1
			// innerfunction  can access local / function ke outside varible  /outside avible
			// var a3 = "Global Varible"
			// function outerfun() {  // Execute(2)
			// 	var a1 = "This is Outer-function";
			// 	console.log(a1);
			// 	function innerfun() {  //Execute(4)
			// 		var a2 = "This is Inner-function"
			// 		console.log(a2);
			// 		console.log(`${a1}`);
			// 		console.log(a3);
			// 	}
			// 	innerfun() // Execute(3)
			// 	console.log(a2);
			// }
			// outerfun()  // Execute(1)

			// function init() {
			// 	var name = "Mozilla";
			// 	function displayName() {
			// 	  console.log(name);
			// 	}
			// 	return displayName;

			//   }
			//   c = init();
			//   c()

			// function myfun() {
			// 	return "hello world"
			// }
			// let a = myfun()
			// a()
			// // a is a function



			// function myfun() {
			// 	const x = () => {
			// 		let a = 1;
			// 		console.log(a);

			// 			const y = () => {
			// 				// let b = 2;
			// 				// console.log(b);
			// 				console.log(a);

			// 						const z = () => {
			// 							// let c = 3;
			// 							// console.log(c);
			// 							console.log(a);
			// 						}
			// 						z()

			// 			}
			// 			// innerfunction using outer fuction's varible 
			// 			a = 23
			// 			y()

			// 	}
			// 	return x
			// }

			// let d = myfun()
			// d()

// Async and Await
			// async[ES 2017]after : return promises[ES6]before // ease to make and read
			// promises : has some complication and lengthy code
			// works similar but having some difference
			// async function(){} // syntax

		// async function myfun() {
		// 	return ("hello world")
		// }
		
		// let myfun = async function(){
		// 	return ("hello world")
		// }
		
		// let myfun = async () =>"hello world"

		// // console.log(myfun());
		// // no need to write resolve and reject function and yaha pe direct then and catch call skate hai 
		// // function jo return karega value bo result namak varible mai store hojatega 
		// myfun().then((result)=>{ 
		// 	console.log(result);
		// }).catch((error)=>{
		// 	console.log(error);
		// })


		// await : bhai intezar akr tu just for example
		// jab data ko server se fetch akrna ho to thoda sa time ()second minutelagta hai usme to uske refernece mai use hoa hai 

		// async function fname() {
		// 	  		console.log('A'); // run1
		// await 	console.log('B'); // run2 taking some time and after completion the next code will run // railway ticket booking
		// 	  		console.log('C'); // run5
		// 	  		console.log('D'); // run6
		// 	  		console.log('E'); // run7
		// }
		// fname()
		// console.log('F'); // run3
		// console.log('G'); // run4

		// // async le sath karta hai await otheerswi error throw 
		// async function fname() {
		// 	  	// console.log('1'); 
		// // await 	console.log('2'); 
		// // console.log('3'); 
		// // const response = await fetch("https://jsonplaceholder.typicode.com/users")
		// // // console.log('2'); 
		// // // console.log('4'); 
		// // // fetch bhi promise return akrat hai 
		// // const student = await response.json();
		// // return student

		// return(await fetch("https://jsonplaceholder.typicode.com/users")).json()

		// first server se data fetch karke lao pura and data ko json format mai dalke ko return kar do 
			// }
			
		// Execution will start from here 
		// console.log('5'); 
		// fname();
		// let f = fname();
		// console.log('6'); 
		// console.log('7'); 
		// console.log(f);

		// jo dsta  return ho rha ahi vo rews varible mi store akr leta ahu 
		// fname().then((res)=>{
		// 	console.log(res);
			
		// agr  test function ko bar bar use karna pada to catch error ko bar bar likhna padega to avoid this use error Handling
		// }).catch((err)=>{
		// 	console.log(err);

		// })
		

		// error ahndling  
		async function fname() {
			// ERROR Handling
			try {
				const response = await fetch("https://jsonplaceholder.typicode.com/users")
				const student = await response.json();
				return student
			} catch (error) {
				console.log(error);
			}
	  }

	  fname().then((res)=>{
		console.log(res);
		
		})
