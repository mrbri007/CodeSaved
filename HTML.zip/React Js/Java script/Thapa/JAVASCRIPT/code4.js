// API : API stands for Application Programming Interface.
	// Zomoto/uber/ola -- API(Google Maps API) -- Google Maps
	// Company1 -- request/response to access data -- API -- request/response -- Company2
	// because they cant access data from google map directly so it work like an messanger
	// API kisi bhi system ke liye 'WHAT' ka kam karta hai not 'HOW'
	// WHAT : Burger (Final)
	// HOW : Burger (Receipe)

	// Google and facebook sign up in Website ke interface why this feautures exist
	// new app/web mai har ek user ke details/credentials information sahi hai ya nahi yeh verify na karne pade isliye  vo google/facebook API ka use karte hai because they have millions of user data 
	//  user ke credentials information ko verify karne ke liye vo google/facebook API ka use karte hai because they have millions of usedatr a 
	// new app -- ask Google/facebook API -- vaild user exist in their database or not if not then denied and if exist then it allowed

	// restaurent 
	// customer(App) --- waiter(API) ---- chef(System)
	// Usage of API : Online ticket railway or airline/food/Ecommerce  



	// fetch("readme.txt")

	// fetch("readme.txt")
	// .then(function(response){
	// })

	// fetch("readme.txt")
	// .then((response)=>{
	// 	return (
	// 		response.text()
	// 	);
	// })
	// .then((reuslt)=>{
	// 	console.log(reuslt);
	// })

	// data format : json and text
	// server ke throgh file ke data ko read karna 
	// fetch("readme.txt")
	// fetch("https://jsonplaceholder.typicode.com/users")
	// // .then(response=>response.json1())
	// .then(response=>response.json())
	// // .then(result=>console.log(result))
	// .then((result)=>{
	// 	console.log(result) //object return 
	// 	for (let x in result){
	// 		// document.write(x); // displaying key value
			
	// 		// object ke andar object hai and uske andar ki object ko cant access/print directly 
	// 		// uske value ko access karne k eliye key ka name dena padega
	// 		// document.write(result[x]); 
	// 		// document.write(`${result[x].name} - ${result[x].email} <br>`);
	// 		// document.write(`${result[x].address.city}<br>`);

	// 		 var a = `${result[x].name} - ${result[x].email} <br>`;
	// 		document.write(a);
			
	// 	}
	// })
	// .catch(error=>console.log("Failed Successfully"))
	
	// // server se data fetch karke web page ko print karna
	// //online se json data 
	// // agar system pe kahi json ak txt ka data hai to usko kaise fetch karmege 
	// // 

	// fetch("student.json")
	// .then(response=>response.json())
	// .then((result)=>{
	// 	console.log(result) 
	// 	for ( x in result){
	// 		document.write(`${result[x].name} -${result[x].city} -${result[x].company}`)
	// 	}
	// })
	// .catch(error=>console.log("Failed Successfully"))




	// data ko server pe read karna ho to 
	// data ko server pe insert upadate delete karna ho to 
	// server side scripting language file la URL/path with some parameter 
	// fetch(file/URL,{
	// 	// properties : key and value

	// 	// to send data or fetch (retrieve), many ways , we are working with json, has many method 
	// 	// 1. property 
	// 	// method :"GET" // data Read // default
	// 	// method :"POST" // data insert
	// 	// method :"PUT" // data update
	// 	// method :"DELETE" // data delete

	// 	// 2. property : to save data on server (R/I/U/D)
	// 	body:  data, // (data format) : form data/json data/Normaltext

	// 	// 3. property
	// 	Header :{
	// 		// to pass data format sent to server
	// 		// content -type ahs 2 type
	// 		'Content-Type' : 'application/json', // json ka format mostly used
	// 		'Content-Type' : 'application/x-www-form-unlencoded',  // form ak data
	// 	}

	// }) 

	// ot raed data on server ( previously dekh chuke hai)


	// to insert data on server(database)
	// let obj = { 
	// 	title: 'foo',
	// 	body: 'bar',
	// 	userId: 1,
	//   }
	// fetch('https://jsonplaceholder.typicode.com/posts', {
	// 	// to send data on server
	// 	method: 'POST', 
	// 	// object ko server pe send najikar sakte islye json mai convert karna padega
	// 	// server pe jo hum data send akrte hai bo json raheta hai 
	// 	// json ek universal data format : amy programming can read it 
	// 	body: JSON.stringify(obj),
	// 	headers: {
	// 	  'Content-type': 'application/json;',
	// 	},
	//   })
	// 	.then((response) => response.json())
	// 	.then((json) => console.log(json));


	// console.log(' ');
	// 100 pahelel sa tha  and added 1 adat so 101
	// {id: 101}
	
	// 	fetch('https://jsonplaceholder.typicode.com/posts/1', {
	//   method: 'PUT', // update 
	//   body: JSON.stringify({
	//     id: 1,
	//     title: 'foo',
	//     body: 'bar',
	//     userId: 1,
	//   }),
	//   headers: {
	//     'Content-type': 'application/json; charset=UTF-8',
	//   },
	// })
	//   .then((response) => response.json())
	//   .then((json) => console.log(json));

	// fetch('https://jsonplaceholder.typicode.com/posts/1', { // : /1 : file number
	//   method: 'DELETE',
	// });

	// user se input lene ke liye hum form ak use karte hai na ki object ka 
	// for example

	// 	document.getElementById("savedata").addEventListener('click', function(e){
	// 	e.preventDefault(); // prevent from reloading the page
	// 	// server pe hum jo data send akrte hai ya receive karte hai vp asyncrofym hpta hi mean background

	// 	let obj = {
	// 		fname:document.getElementById("fname").value,
	// 		lname:document.getElementById("lname").value,
	// 	}
	// 		fetch('https://jsonplaceholder.typicode.com/posts', {
	// 	  method: 'POST', 
	// 	  body: JSON.stringify(obj),
	// 	  headers: {
	// 		'Content-type': 'application/json; charset=UTF-8',
	// 	  },
	// 	})
	// 	  .then((response) => response.json())
	// 	  .then((json) => console.log(json));
	// })

	// 	document.getElementById("savedata").addEventListener('click', function(e){
	// 	e.preventDefault(); 
			
	// 	// two way to make form data 
	// 	// 1. object banke and then JSON.stringfy inndirectly
	// 	// 2. form data directly
	// 		fetch('https://jsonplaceholder.typicode.com/posts', {
	// 	  method: 'POST', 
	// 	  body: new FormData(document.getElementById("myform")) ,
	// 	  headers: {
	// 		// server pe jo data bheja ja rh ahai vo ek form data hai
	// 		'Content-type': 'application/x-www-form-unlencoded',
	// 	  },
	// 	})
	// then((function(){ resolve ka kam karega }))
	// 	  .then((response) => response.json())
	// 	  .then((json) => console.log(json));
	// })

	// if (window.fetch) {
	// 	// agar hamara window fetch method ko support karta hai to exectehoga 
	// } else {
	//  //  if not supported, then xmlhttpsrequiest ajax call hoga 
	// }