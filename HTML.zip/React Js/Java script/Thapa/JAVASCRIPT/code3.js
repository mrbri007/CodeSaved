// console.log('Jquery make it easy to work with AJAX ');


// let fetchBtn = document.getElementById("fetchBtn");
// fetchBtn.addEventListener('click', buttonclickhandler)

// function buttonclickhandler() {
	// console.log('Passes Successfully');
	
	// creating a object
	// const xhr = new XMLHttpRequest()

	// open the object
	// xhr.open("GET", "hello2.txt", true) 
	// xhr.open("GET", "hello.txt", true) 
	// Railway pe ticket booking
	// xhr.open("POST", "https://dummy.restapiexample.com/api/v1/create", true) 
	// xhr.getResponseHeader('Content-type', 'application/json')
	// xhr.open("GET", "https://jsonplaceholder.typicode.com/users", true) 
	// server ne response send kiya nahi kiyta to due to many reason, then website crash or hang
	// xhr.open("GET", "https://jsonplaceholder.typicode.com/users", false) 

	// What to do on progress(optional)
	// xhr.onprogress = function(){
	// 	console.log('This is working in progress');
	// }

	// READYSTATE value: 0-4 
	// 0  : open() not called yet.
	// 1  : OPENED	open() has been called.
	// 2  : send() has been called
	// 3  : LOADING	Downloading
	// 4  : DONE
	// xhr.onreadystatechange = function(){
	// 	console.log('This is READYSTATE', xhr.readyState);
	// }

	// What to do when response is ready and display 
// 	xhr.onload = function(){
// 		if (this.status == 200) {
// 			console.log(this.responseText);
// 		}
// 		else{
// 			console.log('404 NOT Found');
// 		}
// 	}

// 	//Sending the request 
// 	// xhr.send()

// 	params = `{"name":"hello342","salary":"123","age":"23"}`;
// 	xhr.send(params)
// }

// NOTES 
	// kis tarah ka request hoga : GET/POST
	// GET : only fetch
	// POST : request ke sath data bhi send karenge  
	// path of url : data kaha se aayega
	// anysn true karne se onload function baad mai load hota hai par jab tak vo print hota hai tab pahele ke clog print ho jata hai 
	


// let backupBtn = document.getElementById("backupBtn");
// backupBtn.addEventListener('click', backhandlder)

// function backhandlder() {
// 	const xhr = new XMLHttpRequest()
// 	xhr.open("GET", "https://reqres.in/api/products/3", true) 

// 	xhr.onload = function(){
// 		if (this.status == 200) {
// 			let myobj = JSON.parse(this.responseText)
// 			console.log(myobj);
// 			document.getElementById("list").innerHTML = (myobj);


// 			let list = document.getElementById("list")
// 			// Appending li in list id  
// 			let str ="";
// 			for(key in myobj){
// 				str += `<li> ${myobj[key].employee_name}</li>`;
// 			}
// 			list.innerHTML = str

// 		}else{
// 			console.log('404 NOT Found');
// 		}
// 	}
// 	xhr.send()
// 	console.log('We are done fetching API');
// }

		// When receiving data from a web server, the data is always a string.
		// Parse the data with JSON.parse(), and the data becomes a JavaScript object.

		// xhr.onreadystatechange : include 5 state like onload , onprogress etc
		// onload  is the last step (5 state)
		// JSON :  to store data and exchange from/to server 
		// JSON is a text format for storing and transporting data 

			// function statement 
			// function name(){}

			// function expression
			//  let a = function (){}

			// Anonymous Function : callback function
			//  function(){}
			// functionn call hote samay function return hota hai

					// // function myfun() {
	// // 	// return (variable, expression, array , object, number)
	// // }

	// // return statement execute hota hai when function gets called 
	// // function value return karta hai vaha pe jajha pe function call kiy ajata hai  
	// // like kind of replacement
	// // jaha pe function call hoga vahape return ho jayega value 
	// function myfun(a, b) {
	// 	 let d = a + b
	// 	 // return statemney undefiend if not defined
	// 	//  return 0
	// 	//  return 1 
	// 	 return [1,3,6,4]
	// 	// return (d)
	// 	// return (a + b)
	// }
	// // when function gets called then[ myfun(10, 30)] ye exceute hoga and then function myfun(a, b) { mai then transfer hoaga and then return (a+b) mai jayega and transfer ho jayeg ajaha pe call kiya agaya tha myfun(10, 30) // let a = 40 

	// let a = myfun(10, 30)
	// // let a = 40 
	// console.log(a);

	// // function name() {
	// // 	 return()
	// // }
	// // var a = name() = return()
	// // console.log(return());
	
	// // jo return mai lika hai value vahi return hoga
