// Array Every method
// The every() method executes a function for each array element.
// The every() method returns true if the function returns true for all elements.
// The every() method returns false if the function returns false for one element.
	// const company = [
	// 	{
	// 		name :"Apple",
	// 		category : "Tech"
	// 	},
	// 	{
	// 		name :"Microsoft",
	// 		category : "Tech"
	// 	},
	// ]
	// const allcomapny = company.every((element)=>{
	// 	return element.category === "Tech"
	// })
	// console.log(company)
	// console.log(allcomapny)
	// const arr = [1,2,3,4,5]
	// const result = arr.every((element)=>{
	// 	return element <= 10
	// })
	// console.log(arr)
	// console.log(result)

// let a = "b"
// console.log(a)

// let c = {[a]: "d"}
// console.log(c)

// let e = {a: "d"}
// console.log(e)

// details examine
// [a] value containe "b"
// so c obejct represent like this
// var c = {b : "d"}

// Callback function : jab function ko as a argument pass kiya jata hai
// Callback function is a function(it can be any function Anonymous function , arrow function) passed into another function as an argument, which is then invoked inside the outer function to complete some kind of action or routine 
//one way

		// // execute 3
		// function myfun1(){
		// 	console.log("Passed Successfully")
		// }
		// // execute 2
		// function myfun2(callback){
		// 	callback() // something to be called
		// }
		// // execute 1
		// myfun2(myfun1) //function as an argument



		// function myfun1(statusaCode){
		// 	console.log(`${statusaCode} Passed Successfully`)
		// }
		// function myfun2(callback){
		// 	let a = 202;
		// 	callback(a) // transfer to myfun1()
		// }
		// myfun2(myfun1) 



		// function myfun1(statusaCode){
		// 	console.log(`${statusaCode} : Passed Successfully`)
		// }
		// function myfun2(a, callback){
		// 	callback(a) // transfer to myfun1()
		// }
		// myfun2(404, myfun1) 



		// function myfun2(callback){
		// 	let a = 404;
		// 	callback(a) 
		// }
		// myfun2(function myfun1(statusaCode){
		// 	console.log(`${statusaCode} : Passed Successfully`)
		// }) 



		// // Anonymous function
		// function myfun2(callback){
		// 	let a = 404;
		// 	callback(a) 
		// }
		// myfun2(function (statusaCode){ //myfun1 : no use so it is anonymous function
		// 	console.log(`${statusaCode} : Passed Successfully`)
		// }) 


		// Arrow function : map , settimout
		function myfun2(callback){
			let a = 200;
			callback(a) 
		}
		myfun2((statusaCode)=>{ 
			console.log(`${statusaCode} : Passed Successfully`)
		}) 

		// Synchronous and Asynchronous callback function in js 
		// Asynchronous : Asynchronous code allows the program to be executed immediately
		// function myfun1(){
		// 	console.log("Passed Successfully")
		// }
		// function myfun2(callback){
		// 	callback() 
		// }
		// myfun2(myfun1);
		// console.log("Wait a minute")
		// Synchronous : every statement of the code gets executed one by one. So, basically a statement has to wait for the earlier statement to get executed.
		// setTimeout(() => {
       	// console.log("Let us see what happens");
   		//  }, 2000);
		// console.log("Wait a minute")
  


