// React Notes 
	// pacakage.json : metadata of react means all the info ahs been curated in this file 
	// robot.txt : when we hoist our website on google and google crawler and seo kind of thing 
	// node module incleded all the depenndcies of react bia creted through installation process
	// manifest.json : it provide the info ablout the app on json format

	// Important Takeaway !!
	// functional components should always JSX return
	// export default function Main1() {
	// 	<div>
	// 		<h1>Javascript Library</h1>
	// 		<p>JSX is an extension of the JavaScript language based on ES6</p>
	// 	</div>
	// }
	// CAT : Create/add/transfer Component (Journey of Component)
	// To write JSX in components, need to import React from 'react' befpre v16
	// How React is actually looking into it or  Without JSX:
	// import React from 'react'
	// export default function Main1() {
	//   return (
	// 	React.createElement('div', {}, React.createElement('h1', {}, 'Hello world')
	//   ))
	// }
	// CSS : Internal/external as it is /Inline/CSS Modules
	// 1.internal CSS as a object
	// const mystyleobj =  [{
	// backgroundColor: "DodgerBlue",
	// 	color : "red"
	// }]
	// 2.Inline styling : style = {{color: "red"}}
	// 3.external : Seperate File (className and Id)
	// 4.CSS Modules 
	//  node_module se pata chalta hai ki kon konsi dependency(package) add ki hai or by default create-react-app install ke sath mila hai   
	// rafce   
	//  CSS as a object  


	// import React from 'react'
	// After React 17.0v, Now no need to write 'import React from 'react' but before React v16

	  // NESTED COMPONENTS
    // A module can not have multiple export and this is function (components)

	// webpack / babel : via installation internally install ho jata hai externally store anhi karna padta hai 
	// Babel is a JavaScript compiler // so that we can write modern js 
	// jo modern js ko convert karta hai ek js format mai jo browser understand kar sake 
	// via importing react, it can eget accessed 


	// jsx use karte samaay hum react ko import karte hai 

	// JS include html within js using{}
	// js expression : combination of operahand and opertor and 

	// {} : only Javascript Expression not statement like for lopp / if-else condition
	// html element  = jsx element
	// html attribute  = jsx attribute
	// there is some differenece between them 
	// jsx attribute :  must be in camelCase

	// For example, to open a link in a new tab, you would add rel="noopener noreferrer". 
	// To indicate that two pages are related, you could add rel="related".
	// warning/error throw
	// class ek reserved   keyword  haui so can not us e
	// index.js must have less code and amke app.js and list all the component file

	// componet bascially html ka banaya jata hai 
	// import karte samaay jo hame data receive hota hai vo object hot a hai

	// one file(component) has only default export and impoert kitne bhi ho sakte ahi
	// expoert kitne bhi hi sate hi and vo bhi with same {} and defaulr ek hi hoga  par

	// react props : custome atyribute
	// in html : predefinef attribute hotahai  

	// an array is a special varible, which can hold mpore than one value ata time
	// the array object let you stopte multiple value ina single varible 

	// 3 ways  to cretw an array 
	// var a = ['lorem1', "lorem1", "lorem1"]
	// var a = new Array('lorem1', "lorem1", "lorem1")
	// console.log(a);
	// console.log(a[2]);
	// var a = a[0]
	// a[0] = "lorem"
	// console.log(a);
	

	// props and array of object  sath mao use karte hi 




	// har ek componnet ke ek unique id hoti hai jise ham key as it is as key name and value kuch bhi de sakte hai like number or stirng
	// for  updateing in future 

	// const myfun = function(age) {
	// 	if (age > 7) {
	// 	  return true;
	// 	} else {
	// 	  return false;
	// 	}
	// 	};
		
	// 	myfun(12);

//direct change nahi hoga and react mai kisi value ko update karna ho to usestate  hook ka use karte hi 

//React Hooks : v6
// statevarible ko chnage karne ke liye React Hooks ka use karte hai
// direct value ko update nahi kar sakte hai
// count++  
// usestatehook ek function hai return array with two items 
// lopp ki tarah hota hai bar bar click karne par


// see this process
// first : statevarible mai intialvalue store ho ajyega and then updaterfunction on click button par statevarible ki value change ho ajyegi and then updatedvalue = intialvalue and store ho jayega in count varible mai then process goes on



// const btn = {
// 	padding: "12px 20px 12px",
// 	backgroundColor: "#000",
// 	border: "none",
// 	color: "#fff",
// 	borderRadius: "4px"
// }



// NPM  : package warehouse which contains 800000 package
// iss package/code ka use developer apne project mai karte hai 
// npm is installed with node.js
// all npm package are defined in files called package.json
// npm ke throgh jo bhi package use karenge vopacakge.json ami store hp kajyeag
// package,jsodn : the content must be written in JSON
// pacakge.json ko install karne ke liye : npm init via cmd
// amazon : product warehouse to deliver product to consumer

// cmd (window user)vd cli(linux user)
// npm can manage dependecies
// react digital clock : install in terminal 
// it cretes dependecy on your project 
// npm ke through jab pacakge install karte hai tab vah ek dependecy crete karta hai on your project 

{/* <p>A simple digital clock implementation in React.</p>
		<p>1. Installation : 
				npm install react-digital-clock </p>
		<p>2. Usage Import component : 
				import Clock from 'react-digital-clock';</p>
		<p >3. Use component :{" "}</p> */}


// context api in react js 
// componnet stree
// parents componets -- child components 1 --  child components 2 --child components 3 ---child components 4
// this is herichy

// parent comp ke pass kuch data hia amd c ko chahiye means c ko data access karne ke liye form parents ko child a ko send kareg and so on
// but agr koi data c ko chahiye hota hai to hame usse pahele parents compents and then child compnents a and child componets B ko bhi transfer karke phir c ko deliver hota hai 
// but ab parentrs compnents  ----- ditcat child compenets c using context api 

// React Context API is a way to share data between components easily. It lets you pass data from one component to another, ./
// it allows you to easily access data at differen levelsof the compinents tree, without passing props to evevry level

// redux vs context api 
// A --B--C--D--E--F--G--H : Data communication before context api 
// A ------------------- H : Data communication after context api 


// 3 steps  
// createContext() : so that data can be sent 
// provider : so that data can be parsed
// consumer : so that data can be received








// relaod : server side routing ka use kar rahe hai 
// client side routing/rendering
// react router : install via pacakge npm
// to connect your app to the browser's url : browserroute
// '/' : represemt home page and elemet / page /components rendering show to home page
// '/' : single represent home/root page
// path: visit url
// routes define karna padega



// a alternative : link 
// href alternative : to

