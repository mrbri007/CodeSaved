// React Hooks 
	// 1. UseState()
	// 2. UseEffect()
	// 4. UseLayouteEffect()
	// 3. UseRef()
	// 5. UseContext()
	// 6. UseReducer()
	// 7. UseMemo()
	// 8. UseCallback()
	// 9. CustomeHook() : (Building Your Own Hooks) 

// usestate : To Update State varible  
// UseEffect : Your component needs to do something after render.
// UseContext : Data rendering between parents components and defined child components
// Hooks : function used to functional comaponents v16
// two types of components : functional and class
// class has: state managment and lifecycle method but not in functional componnets 
// now in react v16, we can use state managment and lifecycle method by using Hooks 

// Rules : import first/defined at top level/inside functional components / can not use conditional statement
// input :  value and onnchange and name must be included
