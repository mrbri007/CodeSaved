// import hello from './module-2.mjs'
// console.log(hello);

import hello, {b,c,d} from './module-2.mjs'
// import {b,c,d} from './module-2.mjs'
console.log(hello);
console.log(b);
console.log(c);
console.log(d);