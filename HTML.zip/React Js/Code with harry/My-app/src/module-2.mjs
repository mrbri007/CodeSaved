const a = "lorem-1";
// const b = "lorem-2";
// const c = "lorem-3";
// const d = "lorem-4";

// Note 
// set "type" : "module" in the package.json 
// use the .mjs extension 

// default export 
export default a; 
// export default b; 
// export default c; 
// export default d; 

// Named export 
// export {b}; 
// export {c}; 
// export {d}; 
