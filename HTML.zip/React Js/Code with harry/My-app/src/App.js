// import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar';
// import Main from './components/Main';
import TextForm from './components/textform';
import React , { useState } from 'react'



// imr : function based componeent we are using so no need of react 
// import React from 'react'
// Make it organized and clean
// function App() {
//   const [mode, setmode] = useState('dark') // whether dark mode is enabled or not
//   // const [mode, setmode] = useState('light') // whether dark mode is enabled or not
//   const togglemode = ()=> {
//     if(mode === 'light'){
//       setmode = 'dark'
//     }
//     else{
//       setmode =  'dark'
//     }
//     }
//   }
//   return (
//     <>
//       <Navbar title = 'TextUtils' abouttext="hello" mode={mode} togglemode={togglemode}/>   
//       <div className='container my-3'>
//        <TextForm heading="Test Yourself With Exercises"/>
//      </div>
//     </>
//   );

// export default App;

function App() {
  // useState 
  const [mode, setmode] = useState('dark')   // whether dark mode is enabled or not

  // function 
  const togglemode = ()=> {
    if(mode === 'light'){
      setmode('dark')
    }
    else{
      setmode('light')
    }}
  return (
    <>
    <Navbar title = 'TextUtils' abouttext="hello" mode={mode} togglemode={togglemode}/>   
    <div className='container my-3'>
     <TextForm heading="Test Yourself With Exercises"/>
   </div>
  </>
  )}

export default App;




// function App() {
//   return (
//     <>
//       {/* <Navbar title = {456} abouttext="ReactJs"/>    */}
//       {/* <Navbar title = 'TextUtils' abouttext="hello"/>    */}
//       {/* <Navbar title = 'Lenskart'/>    */}
//       {/* <Navbar/> */}

//     {/* bootstrap ki class conatiner property */}
//     <div className='container my-3'>
//       <TextForm heading="Test Yourself With Exercises"/>
//     </div> 


//    {/* <TextForm/> */}
//     {/* <div className='container my-3'>
//       <Main/>  
//     </div> */}


//     </>
//   );
// }

// export default App;
// let library = "React" 
// function App() {
//   return (
//     <>
//     <nav>
//       <ul>
//         <li>Home</li>
//         <li>About</li>
//         <li>Contact us</li>
//       </ul>
//     </nav>
//     <div classNameName='blank'>
//     <h1>Javascript Framework : {library}</h1>
//     <p>React apps are made out of components. A component is a piece of the UI (user interface) that has its own logic and appearance. A component can be as small as a button, or as large as an entire page.</p>
//     </div>
//     </>
//   );
// }

// export default App;
// function App() {
//   return (
//     // JSX 
//     // <h1>Hello world</h1>
//     <div classNameName="App">
//       <header classNameName="App-header">
//         <img src={logo} classNameName="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           classNameName="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React with TeCh
//         </a>
//       </header>
//     </div>
//     //JSX
//   );
// }

// export default App;

// Notes 
// create react app ki help se jo app.js bana hai uske resolve hone ke baad vo local:3000 host par dikhega 
// It is website page

// react js -2 : JSX 
	// there are two types of component in react js
	// function based componenet (now)
		// easy / simple / synax-friendly

	// className based componenet (before)
		// confusing syntax 

// Developer experience kafi acha hota hai
// JSX makes it easier to write and add HTML in React.
// JSX = 95% HTML with a little difference like  
// className = reserved keyword 
// so classNameName = use hota hai 

// return  : only one element will be returned
// but one solution 
// function App() {
//   return (
//     <> //JSX fragment
//     <h1>Hello world</h1>
//     <div classNameName="App">
//       <header classNameName="App-header">
//         <img src={logo} classNameName="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           classNameName="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React with TeCh
//         </a>
//       </header>
//     </div>
//     </>  //JSX fragment
//   );
// } 

// IP address : Mobile (run) same wifi/laptop 
// http://localhost:3000/

// To write javascript in JSX, Use {}

// Adding bootrap in react js 
// public file will be available for all user so dont put any creditials information like password and so on 

// app hosting using npm start (Not recommeneded)
  // for limited user hold and development practise 
  // Note that the development build is not optimized.

// app hosting using npm run build (recommenede)
  // you need to do that 
  // optimized  version and delpoy on server
  // To create a production build, use npm run build.

  // component = form 
  // details filled = props 


