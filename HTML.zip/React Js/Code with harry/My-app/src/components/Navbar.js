// rfc : Components are like functions that return HTML elements.

// Props are passed to components via HTML attributes. 
// Props are arguments passed into React components.
// React Props are like function arguments in JavaScript and attributes in HTML.

// props = string/object/array/number
// many props -- group --- object --- object value render
// props ko change nahi kar sakte ho in function


import React from 'react'
// import PropTypes from 'prop-types'

export default function Navbar(props) {
  return (
	<div>
	<nav className={`navbar navbar-dark bg-${props.mode} navbar-expand-lg ${props.mode}`}>
  <div className="container-fluid">
    <a className="navbar-brand" href="/">{props.title}</a>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="https://react.dev/learnnavbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
      <ul className="navbar-nav me-auto mb-2 mb-lg-0">
        <li className="nav-item">
          <a className="nav-link active" aria-current="page" href="/">Home</a>
        </li>
        <li className="nav-item">
          <a className="nav-link active" aria-current="page" href="/">{props.abouttext}</a>
        </li>
        <li className="nav-item">
          <a className="nav-link active" aria-current="page" href="/">service</a>
        </li>
        <li className="nav-item">
          <a className="nav-link active" aria-current="page" href="/">Blog</a>
        </li>
        <li className="nav-item">
          <a className="nav-link active" aria-current="page" href="/">Contact Us</a>
        </li>
      </ul>
      <form className="d-flex" role="search">
        <button className="btn btn-outline-light" type="submit">Sign Up</button>
      </form>

      <div className={`form-check form-switch text-${props.mode === 'light'?'dark':'light'}`}>
          <input className="form-check-input" type="checkbox" onClick={props.togglemode} role="switch" id="flexSwitchCheckDefault"/>
          <label className="form-check-label" htmlFor="flexSwitchCheckDefault">Enaled dark mode</label>
      </div>


    </div>
  </div>
</nav>  
  </div>
  )
}
 
// object 
// Navbar.protoTypes = {
	//  string hai par number value send nahi kar sakte ho
	// title : PropTypes.string,   
	// title : PropTypes.string.isRequired,  
	// defined value hona chahiye otherwise error 
	// some props is imp so .isRequired and most of the componenet write it 
	// abouttext : PropTypes.string}


// mostv of the case use hota hai  
// Navbar.defaultProps = {
// 	title : 'Lorem',
// 	abouttext : 'Lorem-1'
// }