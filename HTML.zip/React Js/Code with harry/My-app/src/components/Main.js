import React, { useState } from 'react'

export default function Main() {

	// object 
	// let stylename = {
	// 	color:"#fff",
	// 	backgroundColor:'#000'
	// }

	// useState Hook
	const[stylename, setstylename] =  useState({
		color:"#000",
		backgroundColor:'#fff'
	})

	const [btntext, setbtntext] = useState("Enable Dark mode")

	// Updatation function 
	const togglestyle = ()=>{
		if(stylename.color === '#000'){
			//  this is object
			setstylename({
				color:"#fff",
				backgroundColor:'#000',
				// outline :  '1px solid #fff'
			})
			setbtntext("Enable light mode")
		}

		else{
			//  this is object
			setstylename({
				color:"#000",
				backgroundColor:'#fff'
			})
			setbtntext("Enable Dark mode")

		}
	}

	// bootstrap wala change nahi hoga already predefined
	return (
		<>
		{/* <div classNameName='container' style={stylename}> */}     
		<div classNameName='container' >
			<h3>About Us</h3>
			<div className="accordion" id="accordionExample">
				<div className="accordion-item">
					<h2 className="accordion-header">
						<button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne" style={stylename} >
							Accordion Item #1
						</button>
					</h2>
					<div id="collapseOne" className="accordion-collapse collapse show" data-bs-parent="#accordionExample">
						<div className="accordion-body" style={stylename}>
							<strong>This is the first item's accordion body.</strong> It is shown by default, until the collapse plugin adds the appropriate classNamees that we use to style each element. These classNamees control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the though the transition does limit overflow.
						</div>
					</div>
				</div>




				<div className="accordion-item">
					<h2 className="accordion-header">
						<button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" style={stylename}>
							Accordion Item #2
						</button>
					</h2>
					<div id="collapseTwo" className="accordion-collapse collapse" data-bs-parent="#accordionExample">
						<div className="accordion-body" style={stylename}>
							<strong>This is the second item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classNamees that we use to style each element. These classNamees control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the though the transition does limit overflow.
						</div>
					</div>
				</div>

				


				<div className="accordion-item">
					<h2 className="accordion-header">
						<button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree" style={stylename}>
							Accordion Item #3
						</button>
					</h2>
					<div id="collapseThree" className="accordion-collapse collapse" data-bs-parent="#accordionExample">
						<div className="accordion-body" style={stylename}>
							<strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classNamees that we use to style each element. These classNamees control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the though the transition does limit overflow.
						</div>
					</div>
				</div>



				<div className="accordion-item">
					<h2 className="accordion-header">
						<button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree" style={stylename}>
							Accordion Item #4
						</button>
					</h2>
					<div id="collapseThree" className="accordion-collapse collapse" data-bs-parent="#accordionExample">
						<div className="accordion-body" style={stylename}>
							<strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classNamees that we use to style each element. These classNamees control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the though the transition does limit overflow.
						</div>
					</div>
				</div>




				<div className="accordion-item">
					<h2 className="accordion-header">
						<button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree" style={stylename}>
							Accordion Item #5
						</button>
					</h2>
					<div id="collapseThree" className="accordion-collapse collapse" data-bs-parent="#accordionExample">
						<div className="accordion-body" style={stylename}>
							<strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classNamees that we use to style each element. These classNamees control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the though the transition does limit overflow.
						</div>
					</div>
				</div>

			</div>
		</div>
				<div className='container my-3'>
					<button onClick={togglestyle} type="button" className='btn btn-light my-3 mx-1'>{btntext}</button>
				</div>
		</>
	)
}

// Only chrome exention to refer the particular element
// $0.style.color ='red '