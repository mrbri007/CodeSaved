// usestate ko import kiya react se 
// To use the useState Hook, we first need to import it into our component.
// import React, {useState} from 'react'

// // varibale mai stored value  = text(default value = Enter your here)
// //  text ko update karne ke liye setetxt function ka use karenge 
// // imp syntax 
// // console.log(useState('Enter your here2'));

// // react ka function based compinent aur iske ander form render karunga from bootrsatp
// export default function TextForm(props) {
// 	const myfun1 = ()=>{
// 		console.log('lorem isnpum -1');	
// 		setText('lorem mdcijfvnifjnvifjvnfijnvfijnjncjidi')    
// 	}

// 	const myfun2 = ()=>{
// 		console.log('lorem isnpum - 2');
// 	}
// 	// function component ke ander rakhna hai
// 	// text  = varibale hai and value = 'Enter your here'
// 	// text ko normal varibale ki tarah update nahi kar sakte ho like below in react
// 	// text = "dbhcbdkcdlcn"

// 	// function ko use karna padega (updatation function) in react to ipate the balue of varibale

//   const [text, setText] = useState('Enter your here');
// //   text = "cdcb db dibn dov vd" // wrong way to change the state
// //   setText = "cdcb db dibn dov vd" // correct way to change the state
//   return (
// <div>
// 	<form>
// 		<div className="mb-3">
// 			<h3>{props.heading}</h3>
// 			{/* <label htmlFor="mybox" className="form-label">Learn More</label> */}
// 			<textarea className="form-control" value={text} id="mybox" rows="8" onChange={myfun2}></textarea>
// 			<button type="button" className='btn btn-primary my-3' onClick={myfun1}>Convert to UpperCase</button>
// 		</div>
// 	</form>
// </div>
//   )
// }

// export default function TextForm() {
// 	const [color, setColor] = useState("red");
  
// 	return (
// 	  <>
// 		<h1>My favorite color is {color}!</h1>
// 		<button
// 		  type="button"
// 		  onClick={() => setColor("blue")}
// 		>Blue</button>
// 		<button
// 		  type="button"
// 		  onClick={() => setColor("red")}
// 		>Red</button>
// 		<button
// 		  type="button"
// 		  onClick={() => setColor("pink")}
// 		>Pink</button>
// 		<button
// 		  type="button"
// 		  onClick={() => setColor("green")}
// 		>Green</button>
// 	  </>
// 	);
//   }

// import { useState } from "react";

// export default function Textform() {
// 	const[brand, setBrand] = useState("Apple")

//   return (
// 	<>
// 	<h1>This is {brand}</h1>
// 	<button className="mx-1" type="button" onClick={() => setBrand("Apple")}>Google</button>
// 	<button className="mx-1" type="button" onClick={() => setBrand("Google")}>Google</button>
// 	<button className="mx-1" type="button" onClick={() => setBrand("Microsoft")}>Microsoft</button>
// 	<button className="mx-1" type="button" onClick={() => setBrand("Facebook")}>Facebook</button>
// 	<button className="mx-1" type="button" onClick={() => setBrand("Netflix")}>Netflix</button>
// 	</>
//   )
// }

// import { useState } from "react";

// export default function Textform() {
// 	const[car, setBrand] = useState({
// 		brand: "Ford",
//     	model: "Mustang",
//     	year: "1964",
//     	color: "red"
// 	})

//   return (
// 	<>
// 		<h1>This is {car.brand}</h1>
// 		<p>This is {car.color} {car.modal} from {car.year}</p>
// 	</>
//   )
// }

// import { useState } from "react";
// export default function Textform() {
// 	const[brand, setbrand] = useState("Apple")
// 	const[modal, setmodal] = useState("14pro")
// 	const[color, setcolor] = useState("black")
// 	const[year, setyear] = useState("1945")

//   return (
// 	<>
// 	<h1>This is {brand}</h1>
// 	<p>This is {color} {modal} from {year}</p>
// 	<button className="mx-1" type="button" onClick={()=> setbrand("vivo")}>brand</button>
// 	<button className="mx-1" type="button" onClick={()=> setmodal("13pro")}>modal</button>
// 	<button className="mx-1" type="button" onClick={()=> setcolor("white")}>color</button>
// 	<button className="mx-1" type="button" onClick={()=> setyear("2000")}>year</button>

// 	</>
//   )
// }

// import React, {useState} from 'react'
// export default function TextForm(props) {
// 	const [count, setCount] = useState(0);

// 	function handleClick() {
// 	  setCount(count + 1);
// 	}
  
// 	return (
// 		<>
// 	  	<h3>You pressed me {count} times</h3>
// 	  	<button type="button" className='btn btn-primary my-3' onClick={handleClick}>Adiing count</button>
// 	  </>
// 	);
// }

// import { useState } from 'react';

// export default function MyInput() {
//   const [text, setText] = useState('hello');

//   function handleChange(e) {
//     setText(e.target.value);
//   }

//   return (
//     <>
//       <input value={text} onChange={handleChange} />
//       <p>You typed: {text}</p>
//       <button type="button" className='btn btn-primary my-3' onClick={() => setText('hello')}>Reset</button>
//     </>
//   );
// }



import React, {useState} from 'react'
export default function TextForm(props) {
	const[text, settext] = useState('')
	// const[text, settext] = useState('Enter text here')

	const handleupclick = () => {
		// console.log('This is uppercase' + text);
		let newtext = text.toUpperCase()
		settext(newtext)
		
		// settext("UpperCase Letter ")
	}

	const handleloclick = () => {
		let newtext = text.toLowerCase()
		settext(newtext)
		
	}

	const resetbtn = () => {
		let newtext = ""
		settext(newtext)
		
	}

	// Using RegGX 
	const handleExtraSapce = () => {
		let newtext = text.split(/[ ]+/); // more than one space - -split -- array
		settext(newtext.join(' ')); // add one space
		
	}

	const handleCopy = () => {
		let text = document.getElementById('mybox')
		text.select();
		navigator.clipboard.writeText(text.value)
		
	}

	const handleonchange = (event) => {
		// console.log('This is previous value +  new value');     
		settext(event.target.value)
	}

  return (
		<div>
			<form>
				<div className="container">
					<h3>{props.heading}</h3>
					{/* <label htmlFor="mybox" className="form-label">React useState Hook</label> */}
					<textarea className="form-control" value={text} id="mybox" rows="8" onChange={handleonchange}></textarea>
					{/* text ek aisa varible hai jo state se belong karta hai means state varible */}
					{/* previous value +  new value */}
					<button type="button" className='btn btn-primary my-3 mx-1' onClick={handleupclick}>Convert to UpperCase</button>
					<button type="button" className='btn btn-primary my-3 mx-1' onClick={handleloclick}>Convert to lowerCase</button>
					<button type="button" className='btn btn-primary my-3 mx-1' onClick={resetbtn}>Reset</button>
					<button type="button" className='btn btn-primary my-3 mx-1' onClick={handleCopy}>Copy Text</button>
					<button type="button" className='btn btn-primary my-3 mx-1' onClick={handleExtraSapce}>Remove Extra Space</button>
				</div>


				{/* adding your functionality  */}
				<div className='container my-3'>
					<h3>Your text summary</h3>
					{/* <p>{text.split(" ").length} and {text.length} character</p> */}
					<p>Words {text.split(" ").length} and {text.length} character</p>
					<p>Time to read : {0.008 * text.split(" ").length}  </p>
					{/* text.split("").length : gives you an array of words and no of words*/}
					
					{/* words : 1 why */}
					{/* console.log( ); */}
					{/* a = "" */}
					{/* a.split.(' ') : split kar rh hu by ek space(' ') se to vo array ki length 1 ho ja rahi hai  */} 


					<h3>Check the preview </h3>
					<p>{text}</p>
				</div>
			</form>
		</div>
  )
}


// import React, {useState} from 'react'
// export default function TextForm(props) {

// 	// useState Hook 
// 	const [fWord, findWord] = useState("");
// 	const [rWord, replaceWord] = useState("");

// 	// Function : 
// 	const handlefindChange = (event) => {
// 		findWord(event.target.value);
// 	};

// 	const handleReplaceChange = (event) => {
// 		console.log(replaceWord(event.target.value)) ;
// 	};

// 	const handleReplaceClick = () => {
// 		// let newText = text.replaceAll(fWord,rWord);
// 		// setText(newText);
// 	};

//   return (
// 		<div>
// 			{/* TextArea  Of Find Words:  */}
// 		<button type="button"  value={fWord} onChange = {handlefindChange}>fWord</button>
// 			{/* TextArea Of Replace Words : */}
// 		<button type="button"  value={rWord} onChange = {handleReplaceChange}>rWord</button>
// 			{/* add event on button  :  */}
// 		<button type="button"  value={fWord} onChange = {handleReplaceClick}>fWord</button>
// 		</div>
//   )
// }


