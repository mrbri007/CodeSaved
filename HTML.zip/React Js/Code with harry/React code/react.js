// Notes : React Js 
	// To execute js code, you will have to install nodejs included npm installation 
	// Nodejs : Js ka runtime hai jo js code ko execute karne mai help karta hai without web browser
	// window powershell : to check version 
	// Type : node/npm --version
	// thunder client : API test

	// without using npm(package), we can create a react application by writing code but not recommeneded
	// install package(create react app) by using npm(package installer/manager) 

	// npm install create react app = download karke use kar sakte ho (purchasing)
	// npx install create react app = without downloading package(create react app) ke use kar sakte ho (lending) 

	// react component must be stored in src file


// react js -1 : JS refresher 
	// "use strict"
	// a = 10

	// let a = 10;
	// console.log(a);

	// console.log(this);

// react js -2 : JSX 
	// there are two types of component in react js
	// function based componenet (now)
		// easy / simple / synax-friendly

	// class based componenet (before)
		// confusing syntax 





	


