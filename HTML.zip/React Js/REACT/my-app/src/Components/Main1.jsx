import React from "react";

export default function Main1() {
  return (
    <>
      <h1>React</h1>
      <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Blanditiis quod ea officiis quis culpa minima ipsam laudantium doloremque ab cupiditate. Quasi excepturi aut dicta.</p>
      <button className="btn btn-primary">Click me</button>
    </>
  );
}
