// Section 1
  // import About from "./Components/About";
import Navbar from "./Components/Navbar";
// import TextForm from './Components/TextForm';
// import Usestate from "./PRACTISE/Usestate";
// import Event  from './Components/Event';
// import UseState from "./Components/UseState";


// Thapa Techinal
import Main from "./Thapa/Main-1";


  function App() {
    return (
      <>
      {/* COMPONENTS 1 : Navbar.js*/}
      {/* Checking PropsType : if both string then No ERROR*/}
      <Navbar title="MacOS" company='Meta'/>
      {/*  Checking PropsType : if one is Number and another one is string then throw ERROR */}
      {/* <Navbar title={10} company='Meta'/> */}
      {/* .isrequired : title must have value othwrwise throw error */}
      {/* <Navbar/> */}
      {/* Defined : No use of defaultProps  */}
      {/* <Navbar title="MacOs" company='Meta'/> */}
      {/* Not Defined : Use of defaultProps */}
      {/* <Navbar/> */}
      {/* defined only title NOTs company*/}
      {/* <Navbar title="MacOs"/> */}
      {/* COMPONENTS 2 : TextForm.js */}
      {/* <div className="container my-3">
        <TextForm heading='Customer Feedback'/>
      </div> */}
      {/* <div className="container my-3">
        <About/>
      </div> */}
      {/* COMPONENTS 3 : Event.js */}
      {/* <Event/> */}
      {/* COMPONENTS 4 : UseState.js */}
      {/* <UseState/> */}

      {/* PRACTISE */}
      {/* <div className="container my-3">
      <Usestate/>
      </div> */}



      {/* // Thapa Technical  */}
      <Main/>

      </>
    );
  }
  export default App;




// // import { BrowserRouter, Routes, Route} from "react-router-dom";
// // import Home from "./Navigation/Home";
// // import Blog from "./Navigation/Blog";
// // import About from "./Navigation/About";
// // import Contact from "./Navigation/Contact";
// // import Error from "./Error";
// // import MainNav from "./Navigation/MainNav";
  
//   // function App() {
//   //   return (
//   //     <>
//   //       <BrowserRouter>                                                  
//         // <Routes> 
//           {/* It represet the collection of route */}
//             {/* Just for Understanding  */}
//             {/* Single forward slash '/' : indicate root/home element*/}
//             {/* <Route path="/" element={<div>Home Page</div>}/> */}

//             {/* Best way to do it */}
//             {/* <Route path="/" element={<Home/>}/>
//             <Route path="/Blog" element={<Blog/>}/>
//             <Route path="/About" element={<About/>}/>
//             <Route path="/Contact" element={<Contact/>}/>
//             <Route path="*" element={<Error/>}/> */}

//             {/* Nested Router  */}
//             {/* Home : main router including 3 child router and any data passed will be showed by default to its child router duu to outlet */}
//             {/* <Route path="/" element={<MainNav/>}>
//                 <Route index element={<Home/>}/>
//                 <Route path="/Blog" element={<Blog/>}/>
//                 <Route path="/About" element={<About/>}/>
//                 <Route path="/Contact" element={<Contact/>}/>
//                 <Route path="*" element={<Error/>}/>
//             </Route>

//         </Routes>
//         </BrowserRouter>
//         <h1>hello world</h1> */}
//   //   </>
//   //   );
//   // }
  
//   // export default App;
  




