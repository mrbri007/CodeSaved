import React from 'react'

export default function Error() {
  return (
	<>
	<div>
      <h1>Error 404</h1>
      <p>
        Reload the page: It might be that the error 404 has appeared for the
        simple reason that the page did not load properly. This can be checked
        quite easily by clicking on the button in your browser or also
        by pressing the F5 button. Check the URL: Regardless of whether you have
        entered the URL address manually or been directed via a link, could be
        that a mistake has been made. For this reason you should check the
        specified path of the website. It could be that either you, or the
        person who entered the link, has mistyped something. Apart from spelling
        mistakes, it could also be that forward slashes have been left out or
        misplaced. But bear in mind that this can only really be checked with
         URLs, as they contain unreadable words instead of
        incomprehensible abbreviations, letters, numbers, and symbols. Go back
        through the directory levels: For example, if a URL of the following
        structure example.com/Directory1/Directory2/Directory3 causes a 404
        error page, then you can always go back to the previous directory level
        (in this example: example.com/Directory1/Directory2 in order to check
        whether the desired page is linked there. All you need to do is clear
        the last directory in the URL. The link for the page you are looking for
        should be visible on the previous page. If it is not to be found on that
        page then you can also go back to the previous page and look for the
        correct link there. But if it so happens that this method is also
        successful and you eventually end up back on the homepage, then move
        onto the next tip. Use the websites search function: Many websites
        offer a search function as part of their homepage. By entering one or
        several keywords, it can help you find the specific page that you are
        looking for. Use a search engine: You also have the possibility of using
        the website of your choice to find a website. As long as the desired
        site exists, you should be able to find it by entering the website
        domain and/or a keyword transcription of the subject matter.
      </p>
    </div>
	</>
  )
}
