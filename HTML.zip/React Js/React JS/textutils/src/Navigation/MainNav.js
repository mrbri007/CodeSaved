import React from 'react'
import Header from '../RouterApp/Header'
import {Outlet } from 'react-router-dom'


export default function MainNav() {

  return (
	<>
		   {/* <header>
        <h2>Apple</h2>
        <nav>
          <ul>
            <li>
              <NavLink to="/">Home</NavLink>
            </li>

            <li>
              <NavLink to="/Blog">Blog</NavLink>
            </li>

            <li>
              <NavLink to="/About">About</NavLink>
            </li>
            <li>
              <NavLink to="/Contact">Contact</NavLink>
            </li>
          </ul>
        </nav>
      </header> */}
      <Header/>
      <Outlet/>
	</>
  )
}
