import React from 'react'
// import { NavLink } from 'react-router-dom'
// import Header from '../RouterApp/Header'
import { useNavigate } from "react-router-dom";


export default function Blog() {
  let a = useNavigate();
  const hello = () => {
    a("/Contact");
    // alert("Hello world");
  };
  return (
    <>
    {/* <header>
      <h2>Apple</h2>
      <nav>
        <ul>
          <li>
            <NavLink to="/">Home</NavLink>
          </li>

          <li>
            <NavLink to="/Blog">Blog</NavLink>
          </li>

          <li>
            <NavLink to="/About">About</NavLink>
          </li>
          <li>
            <NavLink to="/Contact">Contact</NavLink>
          </li>
        </ul>
      </nav>
    </header> */}


    {/* <Header/> */}
    <section>
      <h2>iPod Pro</h2>
      <p>
        Client side routing allows your app to update the URL from a NavLink
        click without making another request for another document from the
        server. Instead, your app can immediately render some new UI and make
        data requests with fetch to update the page with new information.
      </p>
      <button type="Button" onClick={hello}>Click Me</button>
      <img src={"https://shorturl.at/qzKV5"} alt="f" />
    </section>
  </>
  )
}
