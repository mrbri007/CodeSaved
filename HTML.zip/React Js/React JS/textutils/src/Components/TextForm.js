// To use the useState Hook, we first need to import it into our component.
import React, {useState} from 'react'

export default function TextForm(props) {
// useState Hook
// const[text, setText] = useState("Enter your text here")
const[text, setText] = useState("")

// Function 1 
// state varible(will change/update) = rendering
const handleUpClick = () => {
	setText(text.toUpperCase())
	// console.log("Passed Successfully")
}

const handleloClick = () => {
	setText(text.toLowerCase())
	// console.log("Passed Successfully")
}

const handleclearClick = () => {
	setText('')
	// console.log("Passed Successfully")
}

// Function 2
const handleOnChange = (event) => {     
	// previous text  + user text = event.target.value
	setText(event.target.value)
	// console.log("when we listen event, we can use (event) as a parameter in function")
}

const handleFindChange = (event) => {
    text(event.target.value);
  };

  return (
	<>
	<div className="container">
		<h2>{props.heading}</h2>
		<div className="mb-3 ">
		<textarea className="Form-control" id="mybox" rows={8} cols={170} value={text} onChange={handleOnChange}>
		</textarea>
		</div>
		<button className="btn btn-primary " onClick={handleUpClick}>Convert to Uppercase</button>
		<button className="btn btn-primary mx-2" onClick={handleloClick}>Convert to Lowercase</button>
		<button className="btn btn-primary mx-2" onClick={handleclearClick}>Reset</button>
		<button className="btn btn-primary mx-2" value={text} onChange = {handleFindChange}>Find Word</button>
	</div>
	<div className="container my-3">
		<h2>Your Text Summary</h2>
		<p> {text.split(" ").length} words and {text.length} character </p>
		<p>Time {0.008 * text.split(" ").length }</p>
		<h2>Preview</h2>
		<p>{text}</p>
	</div>
	</>
  )}


