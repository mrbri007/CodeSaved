import React from 'react'
import PropTypes from 'prop-types'

// Navbar(props) // Function Argument
export default function Navbar(props) {
  return (
	<>
	  <nav className="navbar navbar-expand-lg bg-body-tertiary">
        <div className="container-fluid">
          <a className="navbar-brand" href="/">{props.title}</a>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="/navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon" />
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <a className="nav-link active" aria-current="page" href="/">Apple</a>
              </li>
              <li className="nav-item">
                <a className="nav-link active" href="/">Google</a>
              </li>
              <li className="nav-item">
                <a className="nav-link active" href="/">Microsoft</a>
              </li>
              <li className="nav-item">
                <a className="nav-link active" href="/">Amazon</a>
              </li>
              <li className="nav-item">
                <a className="nav-link active" href="/">{props.company}</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
	</>
  )
}

// ----- Notes 
// PropTypes : Make sure the data you receive is valid. 

// function_name.prototype = {
// You can declare that a prop is a specific JS type
// 	key_name: PropTypes.bool,
// 	key_name: PropTypes.func,
// 	key_name: PropTypes.number,
// 	key_name: PropTypes.array,
// 	key_name: PropTypes.object,
// 	key_name: PropTypes.string,
// 	key_name: PropTypes.symbol,
// }

Navbar.prototype = {
	title : PropTypes.string,
	company : PropTypes.string
}

// When an invalid value is provided for a prop, a warning will be shown in the JavaScript console.
// Navbar.prototype = {
// 	title : PropTypes.string,
// 	company : PropTypes.string
// }

// Navbar.prototype = {
//  	//  .isrequired : title must be defined, not undefined otherwise throw error 
// 	title : PropTypes.string.isRequired, 
// 	company : PropTypes.string
// }

// If defined value in Navbar.js components then it will NOT be used
// Navbar.defaultProps = {
// 	title : "title_name",
// 	company : "company_name"
// }

// If not defined value in Navbar.js components then it will be used
// Navbar.defaultProps = {
// 	title : "title_name",
// 	company : "company_name"
// }

// there will another default key with value in Navbar.js because of defaultProps 
// <Navbar title="MacOs" />
// Navbar.defaultProps = {
// 	title : "Hello world",
// 	company : "aaaaaaaaaaaaaaaaaaaaaaaaaaaa"
// }
