// ----- COMPONENTS 1
	// To Understand the concept of Event Handling in React
	// import React, {useState} from 'react'
	// export default function TextForm() {
	// 	const [color, setColor] = useState("red");
	// 	return (
	// 	<>
	// 	<div>
	// 		<h1>My favorite color is {color}!</h1>
	// 		<button 
	// 		  className='btn btn-primary mx-1'
	// 		  type="button"
	// 		  onClick={() => setColor("blue")}
	// 		>Blue</button>
	// 		<button
	// 		  className='btn btn-danger mx-1'
	// 		  type="button"
	// 		  onClick={() => setColor("red")}
	// 		>Red</button>
	// 		<button
	// 		  className='btn btn-warning mx-1'
	// 		  type="button"
	// 		  onClick={() => setColor("Pink")}
	// 		>Pink</button>
	// 		<button
	// 		  className='btn btn-success mx-1'
	// 		  type="button"
	// 		  onClick={() => setColor("green")}
	// 		>Green</button>
	// 	</div>
	// 	</>
	// 	);
	//  }




// // ----- COMPONENTS 2
	// import React, {useState} from 'react'

	// export default function Event() {

	// // useState Hook
	// const fav_color = "lightcoral"
	// const [color, setcolor] = useState(fav_color)

	// // Function 1 
	// const change_color_1 = () =>{
	// 	let a = 'blue'
	// 	setcolor(a)}

	// // // Function 2       
	// const change_color_2 = () =>{
	// 	setcolor("green")}

	// // Function 3
	// const change_color_3 = () =>{
	// 	setcolor("Orange")}

	// // Function 4
	// const change_color_4 = () =>{
	// 	setcolor("cyan")}

	//   return (
	// 	<>
	// 	<div style={{
	// 		textAlign: "center",
	// 		height : "150px",
	// 		backgroundColor : color
	// 		}} 

	// 		onClick={change_color_1} 
	// 		onDoubleClick={change_color_2} 
	// 		onMouseEnter={change_color_3}
	// 		onMouseLeave={change_color_4}
	// 		> 

	// 		<h1>Event Handling</h1>
	// 		<p>An event is an action that could be triggered as a result of the user action.</p>
	// 	</div>
	// 	</>
	//   )}




// // ----- COMPONENTS 3
	// import React, {useState} from 'react'
	// const heading = "Customer Feedback"

	// export default function Event() {
	// // useState Hook
	// const [text, settext] = useState("Enter your text here")

	// // Function 
	// const handleUpClick = () =>{
	// 	console.log("This is working ")
	// 	settext(text.toUpperCase())
	// }

	// // Function 
	// const handleOnChange = (e) =>{
	// 	console.log("This is working ")
	// 	settext(e.target.value)
	// }
	//   return (
	// 	<>
	// 	<div className="container">
	// 		<h2>{heading}</h2>
	// 		<div className="mb-3 ">
	// 		<textarea className="Form-control" 
	// 					id="mybox" 
	// 					cols="70" 
	// 					rows="10" 
	// 					value={text} 
	// 					onChange={handleOnChange}>
	// 		</textarea>
	// 		</div>
	// 		<button className="btn btn-primary" onClick={handleUpClick}>Convert to Uppercase</button>
	// 	</div>
	// 	</> 
	//   )
	// }




// // ----- COMPONENTS 4
import React from 'react'

// Note: Function can be inside or outside is okay
// const Btn = "Click Me"
// const alertfun = ()=>{
// 	alert("This is good")
// }

export default function Event() {
const primary_btn = "Click Me"

// Function 1 
const btn1 = () => {
	alert("This is good")
}

// Function 2
const btn2 = (parameter)=>{
	alert(parameter)
}

  return (
	<div className='text-center my-5'>

		{/* Button 1  */}
		<button type="button" 
				className='btn btn-dark mx-2' 
				onClick={btn1}>
				{primary_btn}
		</button>

		{/* Button 2  */}
		<button type="button" 
				className='btn btn-dark my-2'
				onClick={() => btn2("To pass an argument to an event handler, use an arrow function.")}>{primary_btn}
		</button>

	</div>
  )
}


