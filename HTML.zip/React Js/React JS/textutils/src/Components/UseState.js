import React, {useState} from 'react'
export default function UseState() {

	// Example 1 of 4: Counter (number)
	const [count, setcount] = useState(0)
	const handleUpClick1 = () =>{
		setcount(count + 1)
	}
	
	// Example 2 of 4: Text field (string)
	const [text, settext] = useState("Enter your text here")
	const handleUpClick2 = (event) =>{
		settext(event.target.value)
	}
             
	// Example 3 of 4: Checkbox (boolean) 

	// Example 4 of 4: Form (two variables) 
	
   

  return (
	<>
	<div className='my-5'>
		<div>
			<h2>Example 1 of 4: Counter (number)</h2>
			<button type="button" onClick={handleUpClick1}>You pressed me {count} times</button>
		</div><br />
		<div>
			<h2>Example 2 of 4: Text field (string)</h2>
			<input type="text" value={text} onChange={handleUpClick2}/>
			<p>Preview : {text}</p>
			<button type="button" onClick={() => settext("")}>Reset</button>
		</div>
	</div>
	</>
  )
}

// Notes 
// Call useState at the top level of your component to declare a state variable.
// useState is a React Hook that lets you add a state variable to your component.
// Thus e. target. value is the value property of some DOM element, in this case that means the text entered in the search input. Save this answer. The e is the argument of an event handler you attach to a certain event on a certain component
// Events are objects with certain properties, and e.target almost always represents a DOM element.
// Thus e.target.value is the value property of some DOM element, in this case that means the text entered in the search input.


