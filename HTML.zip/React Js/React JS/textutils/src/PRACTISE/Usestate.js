import React, {useState} from 'react'
export default function Usestate() {
// Create multiple state Hooks:
// const [brand, setbrand] = useState("Lambo")
// const [color, setcolor] = useState("Black")
// const [price, setprice] = useState("$199m")
// const hello1 = () =>{
// 	setcolor("blue")
// }
// Or, we can just use one state and include an object instead!
const [car , setcar] = useState({
	brand : "lambo",
	color : "Black",
	price : "$199m",
})
// Because we need the current value of state, we pass a function into our setCar function. This function receives the previous value.We then return an object, spreading the previousState and overwriting only the color.
const hello2= ()=>{
	setcar(previousState => {
		  return { ...previousState, color: "blue" }
	})
}
// const hello2= ()=>{
// 	setcar({color: "blue"})
// }
  return (
	<>
	<div>
		<h2>React : UseState Hook</h2>
		{/* <p> It is {brand} and {color} and {price}</p> */}
		<p> It is {car.brand} and {car.color} and {car.price}</p>
		{/* <button type="button" onClick={hello1}>Click me </button> */}
		<button type="button" onClick={hello2}>Click me </button>
	</div>
	</>
  )
}
