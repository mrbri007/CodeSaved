// import logo from './logo.svg';
import './App.css';
import React from 'react';

// Project 
import Navbar from './Components/Navbar';
import ProductList from './Components/ProductList';
import Footer from './Components/Footer';

function App() {
  const ProductList = [
    {
      price:9999,
      name:"Iphone",
      quanity:0,
    },
    {
      price:9999,
      name:"Oppo",
      quanity:0,
    },
  ]

  return (
    <React.Fragment>
      <Navbar/>  
      <ProductList ProductList={ProductList}/>  
      <Footer/>  
    </React.Fragment>
  );
}

export default App;

// Notes 
// function app ek component hai and return JSX
// Tag  = object ye jsx /react ke element hai
// Attribute like src/className/alt = object properties

// jab data ko componenet ke sath pass karte hai to props use karte hai
// jab components mai properties add/use karte hai tab use props(read only means can not change) karte hai