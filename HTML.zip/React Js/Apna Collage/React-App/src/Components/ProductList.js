import React from 'react';
import Product from './Product.js'

// Two ways of arguement you can take
// props : object hai isme sare object aa jayenge and cant change it 
// jsx mai for loop kam nahi karta hai 

// export default function ProductList(product) {
//   console.log(product);

// object ko destruct karke us particular name ko likh do
// map/for each function not for in lopp does not work 
export default function ProductList(props) {
  
  return (
    props.ProductList.map((Product, i)=>{
      return <Product Product={Product} key={i}>
    })
  )
}
                                                 