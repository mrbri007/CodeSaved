// In-built package from create-react-app installaltion
import React from 'react';
import ReactDOM from 'react-dom/client';

import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

// Add 'app component' to element with id root 
const root = ReactDOM.createRoot(document.getElementById('root'));

// JSX : combination of html and js with some different syntax
root.render(

  // React inbuilt component 
  // Adding more components 
  <React.StrictMode>
    <App/>  
  </React.StrictMode>
);

reportWebVitals();

// Notes
// <App> <Navbar> : components 
// first import and then use 

// Google Search :: (html to jsx compiler) https://htmltojsx.in/  
