import React from 'react'

function App() {

  // localStorage.clear() // To clear the local storage 
  // sessionStorage.clear() // To clear the session storage 
  // Data : key and value pair mai save hota haii
  // localStorage.setItem('user', 'Brijesh')
  // localStorage.setItem('age', 20)
  // const a = localStorage.getItem('user')
  // const b = localStorage.getItem('age')
  // console.log(a,b);
  // localStorage.removeItem('user')

  // To set data as an array in local storage 
  // const arr= {
  //   user : 'Brijesh',
  //   age : 20,
  //   location: 'India'
  // }
  // console.log(arr);
  // localStorage.setItem('user', arr) 
  // You can not save directly in local storage cus it will show [object]
  // when you save data in object format like key and value pair -you need to make it stringfy 
  // localStorage.setItem('user', JSON.stringify(arr)) 

  // to get the object data 
  const a = localStorage.getItem('user')
  console.log(a);
  // console.log(typeof(a)); //String Format
  
  const b = JSON.parse(localStorage.getItem('user')) //Object Format
  console.log(b)
  
  

  
  
  return (
    <div>
      <h1>Local Storage</h1>
    </div>
  )
}

export default App
