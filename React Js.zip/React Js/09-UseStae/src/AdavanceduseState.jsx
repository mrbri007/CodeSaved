import React, { useState } from 'react'

function AdavanceduseState() {
	const [num, setnum] = useState(10)
	// const [num, setnum] = useState({user: 'Brijesh', age: 20})

	// Function, array , object = reference varibale
	// Destructing Array - How to update the array value

	// const [num, setnum] = useState({user: 'Brijesh', age: 20})
	// const [arr, setarr] = useState([10,20,30,40,50])

	// const [obj, setobj] = useState({user: 'Brijesh', age: 20})




	function btnclicked() {
		// // Asynchronous Mode 
		// // num = 10
		// console.log(num);
		// setnum(20)
		// // num = 10
		// console.log(num);
		// // After Click 
		// // num = 30

		// Both has the same value so it will not be rendering
		// setnum(10)

		// console.log(num.user);
		// console.log(num.age);		

		// both has the same data but reference point is different 
		// const newArrvalue = {...num};
		// console.log(newArrvalue);
		// newArrvalue.user= 'Kendall Jenner'
		// newArrvalue.age= 30
		// setnum(newArrvalue);

		// const updateArr = [...arr];
		// console.log(updateArr);
		// updateArr.push(45)
		// setarr(updateArr);

		// shortcut
		// setobj(previos=>({...previos, age:588}));

// Batch Update
		// incremented by 1
		// setnum(num+1)
		// setnum(num+1)
		// setnum(num+1)

		// Now  incremented by 3 
		setnum(previous => (previous + 1))
		setnum(previous => (previous + 1))
		setnum(previous => (previous + 1))

	}
	return (
		<div>
			{/* <h6>Advanced State</h6> */}
			<h1>{num}</h1>
			{/* <h1>{obj.user} and {obj.age}</h1> */}
			{/* <h1>{arr[0]}</h1> */}
			{/* <h1>{num.user} and {num.age}</h1> */}
			<button onClick={btnclicked}>click</button>
		</div>
	)
}

export default AdavanceduseState
