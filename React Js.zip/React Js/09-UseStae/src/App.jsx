import React, {useState} from 'react'
import Component from './Component'
import AdavanceduseState from './AdavanceduseState'


export default function App() {
  // function App() {
  //   let a = 20;
  //   function changethevalue(){
  //     console.log(a);
  //     a = 30;
  //     // a++;
  //     console.log(a);    
  //   }


  // usess : snippt shortcut
  //       Readonly   writeonly                value 
  //       variable   ChangeVaribale           value 
  // const [useFirst, setfirst] = useState('String Value')

  // let useFirst = 10 : it is like this
  const [useFirst, setfirst] = useState(20)
  const [username, setusername] = useState('Kendall Jenner')
  const [arr, setArr] = useState([10,20,30])

  function editvalue(){
    setfirst(30)
    setusername('Dua Lipa')
    setArr([50,67,24])
  }

  return (
    <div>
      {/* <h1>Previous Value : {useFirst} </h1>
      <h1>Previous Value : {useFirst}</h1>
      <h1>Previous Value : {username} </h1>
      <h1>Previous Value : {arr} </h1>
      <button onClick={editvalue}>Click</button> */}

      {/* <Component/ > */}
      <AdavanceduseState/ >
    </div>
  )
}

