import React, { useState } from 'react'

function Component() {

  const [num, setNum] = useState(0)	
  
  function increment(){
	// console.log('+');
	setNum(num+1)
  }
  
  function decrement(){
	// console.log('-');
	setNum(num-1)
  }
  
  function jumpby5(){
	// console.log('-');
	setNum(num+5)
  }
  
  function reset(){
	// console.log('-');
	setNum(0)
  }
  return (
	<div>
	  <h1 className='header'>{num}</h1>
	  <button className='btn' onClick={increment}>Increase</button>
	  <button className='btn' onClick={decrement}>Decrease</button>
	  <button className='btn' onClick={jumpby5}>jumpby5</button>
	  <button className='btn' onClick={reset}>Reset</button>
	</div>
  )
}

export default Component
