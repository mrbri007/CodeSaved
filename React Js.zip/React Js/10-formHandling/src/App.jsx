import React from 'react'
import TwowayBinding from './TwowayBinding'

function App() {
  // we will try to prevent the default behaviour of form submit just like a tage - new tab open when clicked

  // function formSubmit() {
  //   console.log('hello world');}

  // we are unable to see that output in console log cus it happens in milli second

  // function formSubmit(e) {
  //   e.preventDefault()    
  //   console.log("Form Submitted");

  // }

  return (
    <div>
      {/* <form onSubmit={formSubmit}>
        <input type="text" placeholder='Enter your name'/>
        <button>Submit</button>
      </form> */}

      {/* you can pass any varible in parameter */}
      {/* <form onSubmit={(e) => { formSubmit(e) }}>
        <input type="text" placeholder='Enter your name' />
        <button>Submit</button>
      </form> */}

      <TwowayBinding/>

    </div>
  )
}

export default App
