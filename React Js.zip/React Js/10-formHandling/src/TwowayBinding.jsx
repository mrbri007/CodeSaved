import React, { useState } from 'react'

function TwowayBinding() {

	const [title, settitle] = useState('')

	function formSubmit(e) {
		e.preventDefault()
		console.log("Form Submitted : ", title);

		// when form submitted- it will show an new input title 
		settitle('')

	}
	return (
		<div>
			<form onSubmit={(e) => {formSubmit(e)}}>
				{/* <input type="text" placeholder='Enter your name' onChange={()=>{
					console.log("typing...")}}/> */}
				{/* You can see the event details like method used here */}
				<input type="text" 
				placeholder='Enter your name' 
				// value={'helloworld'}

				// settitle update hoke title mai dikhta haii 
				value={title}
				onChange={(e)=>{
					settitle(e.target.value)
				}}
				// onChange={(e)=>{
					// console.log(e.target)
					// console.log(e.target.value)
					// console.log(e.type)
					// console.log(e.preventDefault)
					// }} 
					
					/>
				<button>Click Here</button>
			</form>
		</div>
	)
}

export default TwowayBinding
