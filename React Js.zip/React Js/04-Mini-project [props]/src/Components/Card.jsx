import React from 'react'
import {Book, Bookmark} from 'lucide-react'

function Card(props) {

	console.log(props.company)
  return (
	<div>
	   <div class="card">
			<div class="top">
			  <h3>{props.company}</h3>
			  <button class="save-btn">Save <Bookmark size="12px"/></button>
			</div>
			<p class="time">5 days ago</p>
			<h2 class="role">{props.post}</h2>
			<div class="tags">
			  <span>{props.tag1}</span>
			  <span>{props.tag2}</span>
			</div>
			<div class="bottom">
			  <div>
				<p class="pay">{props.pay}</p>
				<p class="location">{props.location}</p>
			  </div>
			  <button class="apply-btn">Apply now</button>
			</div>
		  </div>
	</div>
  )
}

export default Card
