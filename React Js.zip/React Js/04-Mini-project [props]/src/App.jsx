import React from 'react'
import {Book, Bookmark} from 'lucide-react'
import Card from './Components/card'

function App() {

  // const arr = [10,20,30,40,50]

  const jobOpenings = [
  {
    brandLogo: "https://logo.clearbit.com/meta.com",
    company: "Meta",
    datePosted: "5 days ago",
    post: "Senior UI/UX Designer",
    tag1: "Full-time",
    tag2: "Senior level",
    pay: "$120/hr",
    location: "Menlo Park, CA"
  },
  {
    brandLogo: "https://logo.clearbit.com/apple.com",
    company: "Apple",
    datePosted: "10 days ago",
    post: "Graphic Designer",
    tag1: "Full-time",
    tag2: "Mid level",
    pay: "$85/hr",
    location: "Cupertino, CA"
  },
  {
    brandLogo: "https://logo.clearbit.com/amazon.com",
    company: "Amazon",
    datePosted: "2 weeks ago",
    post: "Product Designer",
    tag1: "Part-time",
    tag2: "Senior level",
    pay: "$110/hr",
    location: "Seattle, WA"
  },
  {
    brandLogo: "https://logo.clearbit.com/netflix.com",
    company: "Netflix",
    datePosted: "3 days ago",
    post: "Visual Designer",
    tag1: "Contract",
    tag2: "Remote",
    pay: "$95/hr",
    location: "Los Gatos, CA"
  },
  {
    brandLogo: "https://logo.clearbit.com/google.com",
    company: "Google",
    datePosted: "1 day ago",
    post: "Junior UX Designer",
    tag1: "Full-time",
    tag2: "Junior level",
    pay: "$70/hr",
    location: "Mountain View, CA"
  },
  {
    brandLogo: "https://logo.clearbit.com/microsoft.com",
    company: "Microsoft",
    datePosted: "4 days ago",
    post: "UX Researcher",
    tag1: "Contract",
    tag2: "Mid level",
    pay: "$100/hr",
    location: "Redmond, WA"
  },
  {
    brandLogo: "https://logo.clearbit.com/nvidia.com",
    company: "Nvidia",
    datePosted: "6 days ago",
    post: "3D UI Designer",
    tag1: "Full-time",
    tag2: "Senior level",
    pay: "$130/hr",
    location: "Santa Clara, CA"
  },
  {
    brandLogo: "https://logo.clearbit.com/tesla.com",
    company: "Tesla",
    datePosted: "8 days ago",
    post: "Interaction Designer",
    tag1: "Part-time",
    tag2: "Junior level",
    pay: "$65/hr",
    location: "Austin, TX"
  },
  {
    brandLogo: "https://logo.clearbit.com/adobe.com",
    company: "Adobe",
    datePosted: "12 days ago",
    post: "Creative Designer",
    tag1: "Full-time",
    tag2: "Mid level",
    pay: "$90/hr",
    location: "San Jose, CA"
  },
  {
    brandLogo: "https://logo.clearbit.com/oracle.com",
    company: "Oracle",
    datePosted: "10 weeks ago",
    post: "UI Designer",
    tag1: "Contract",
    tag2: "Remote",
    pay: "$75/hr",
    location: "Remote"
  }
];

// console.log(jobOpenings);


  return (
    // <div className='parent'>
    //  <Card name='Amazon'/>
    //  <Card name='IBM'/>
    //  <Card name='Netflix'/>
    // </div>


    <div className='parent'>
     {/* <Card name={arr}/> */}
     {/* <Card name={arr[0]}/>
     <Card name={arr[3]}/> */}

    {/* run till the length of array  */}
     {/* {arr.map(function(elem){ */}
      {/* // return elem
      // return elem*2
      // return <h1>{elem*2}</h1>
     })} */}

    {/* elem = object */}
    {/* {jobOpenings.map(function(property){
      return <Card company={property.company} 
                   post={property.post}
                   location={property.pay}
                   pay={property.pay}
                   tag1={property.tag1}
                   tag2={property.tag2}
                   
    />
    })} */}

    {/* Each Element get the indexed value  */}
    {jobOpenings.map(function(property, indexvalue){
      return <div key={indexvalue}>
            <Card company={property.company} 
                   post={property.post}
                   location={property.pay}
                   pay={property.pay}
                   tag1={property.tag1}
                   tag2={property.tag2}
            />
        </div>
    })}

    </div>
  )
}

export default App
