import React from 'react'

function App() {
  return (
    <div>
      <div>
        <div class="bg-sky-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Error, odio.</div>
        <div class="bg-sky-100">Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, qui?</div>
        <div class="bg-sky-200">Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, qui?</div>
        <div class="bg-sky-300">Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, qui?</div>
        <div class="bg-sky-400">Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, qui?</div>
        <div class="bg-sky-500">Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, qui?</div>
        <div class="bg-sky-600">Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, qui?</div>
        <div class="bg-sky-700">Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, qui?</div>
        <div class="bg-sky-800">Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, qui?</div>
        <div class="bg-sky-900">Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, qui?</div>
        <div class="bg-sky-950">Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, qui?</div>
      </div>

    </div>
  )
}

export default App
