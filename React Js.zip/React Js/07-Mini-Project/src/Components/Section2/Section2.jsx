import React from 'react'

function Section2() {
  return (
	<div className='bg-green-900/10 h-screen w-full'>
	  	<h1>section-02</h1>
	</div>
  )
}

export default Section2
