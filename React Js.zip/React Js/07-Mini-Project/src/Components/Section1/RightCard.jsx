import React from 'react'
import Rightcardcontent from './Rightcardcontent'

function RightCard(props) {
  return (
	<div id='right' className='shrink-0 h-full w-80 bg-amber-900 rounded-4xl overflow-hidden relative'>
		<img className='h-full w-full object-cover' src={props.img} alt="" />
		{/* <img className='h-full w-full object-cover' src="https://images.unsplash.com/photo-1731484635300-0d77364ee085?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" /> */}
		<Rightcardcontent id={props.id} tag={props.tag}/>
	</div>
  )
}

export default RightCard
