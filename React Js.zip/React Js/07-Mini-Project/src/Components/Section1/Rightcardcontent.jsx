import React from 'react'

function Rightcardcontent(props) {
  return (
	<div>
		<div className='absolute top-0 left-0 h-full p-6 flex flex-col justify-between'>
			<h2 className='bg-white text-2xl font-medium rounded-full h-12 w-12 flex items-center justify-center'>
				{props.id+1}
			</h2>
			<div>
				<p className='text-xl leading-tight mb-10 text-white'>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Odit temporibus, sunt inventore deleniti adipisci odio.</p>
				<div className='flex items-center justify-between'>
					<button className='bg-white text-black font-medium px-8 py-2 rounded-full'>{props.tag}</button>
					<button className='bg-white text-black font-medium px-3 py-2 rounded-full'><i className="ri-arrow-right-line"></i></button>
				</div>
			</div>
		</div>
	</div>
  )
}

export default Rightcardcontent
