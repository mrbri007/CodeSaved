import React from 'react'

function Herotext() {
  return (
	<div>
		<div className='p-6'>
			<h3 className='mb-7 text-6xl font-mono uppercase tracking-tight'>Prospective Customer Segmentation</h3>
			<p className='text-xl tracking-tighter font-medium'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Harum recusandae obcaecati corrupti temporibus neque doloremque deleniti numquam? Laudantium, dolorum amet.</p>
			{/* <a href="example.com" className='underline mt-5'>Learn More</a> */}
		</div>
	</div>
  )
}

export default Herotext
