import React from 'react'

import Arrow from './Arrow'
import Herotext from './Herotext'

// leading-[1.1] - Custome value
function Left() {
  return (
	<div className='h-full w-1/3 flex justify-between flex-col'>
		<Herotext/>
		<Arrow/>
	
	</div>
  )
}

export default Left
