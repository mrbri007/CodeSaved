import React from 'react'
import Left from './Left'
import Right from './Right'

function Hero(props) {
  return (
	<div className='py-3 px-18 h-[90vh] justify-between flex items-center gap-10'>
	  <Left/>
	  <Right users = {props.users} />
	</div>
  )
}

export default Hero
