import React from 'react'
import RightCard from './RightCard'


function Right(props) {
  return (
	<div className='h-full w-2/3 p-6 flex flex-nowrap gap-6 overflow-auto'>
		{/* <RightCard />
		<RightCard />
		<RightCard />
		<RightCard />
		<RightCard /> */}
		{props.users.map(function(elem, idx){
			return <RightCard key={idx} id={idx} img = {elem.img} tag={elem.tag}/>
		})}
	</div>
  )
}

export default Right
