import React from 'react'

function Navbar() {
  return (
	<div className='flex items-center justify-between px-12 py-6'>
		<h4 className='uppercase font-bold text-[24px] '>Livspace</h4>
		<ul className='flex justify-center items-center gap-8 font-medium uppercase'>
			<li>Home </li>
			<li>About </li>
			<li>Servive </li>
			<li>Blog </li>
			<li>Contact Us </li>
		</ul>
	</div>
  )
}

export default Navbar
