import React from 'react'
import Section1 from './Components/Section1/Section1'
import Section2 from './Components/Section2/Section2'

function App() {
  const users = [

    {img : 'https://images.unsplash.com/photo-1731484635300-0d77364ee085?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', intro : 'High-Paying', tag: 'High-Paying '},
    {img : 'https://images.unsplash.com/photo-1718251479972-5c9922947679?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', intro : 'Full-time', tag: ' Full-time'},
    {img : 'https://plus.unsplash.com/premium_photo-1763734616794-c334f798cbe9?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', intro : 'Part-Time', tag: 'Part-Time '},
    {img : 'https://plus.unsplash.com/premium_photo-1760977857371-be870b1f6994?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', intro : 'Both', tag: 'Both '},
    {img : 'https://plus.unsplash.com/premium_photo-1668485966810-bcaa10f47781?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', intro : 'Internship', tag: 'Internship '}
  ]

  return (
    <div>
      <Section1 users ={users} />
      <Section2 />
    </div>
  )
}

export default App
