// var a = document.querySelector('btn')
// a.addEventListener('click', function(){
//   console.log("hello wordl");
// })

// var a = document.querySelector('btn')
// a.addEventListener('click', btn);
// // a.addEventListener('click', btn()); - Automatically get clicked
// function btn(){
//   console.log("Hello wordl")
// }

