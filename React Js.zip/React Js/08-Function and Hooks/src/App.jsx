import React from 'react'

function App() {

  // function btn() {
  //   console.log('Hello wordl');
  // }

  // function mouse() {
  //   console.log('Mouse entered');
  // }

  function inputchanging(val) {
    console.log('Event : ', val);
  }

  return (
    <div className='container'>
      {/* <button onClick={btn()}>Get Automatically Clicked</button> */}
      {/* <button onClick={btn}>Click Me</button> */}
      {/* <button onMouseEnter={mouse} onClick={btn}>Click Me</button> */}

      {/* <button onClick={function btn() {
        console.log('Hello wordl');
      }}>Click Me</button> */}


      {/* <button onClick={() => {
        console.log('Hello wordl');
      }}>Click Me</button> */}


      {/* <input onChange={() => {
        console.log("typing..")
      }} type="text" placeholder='Enter your name' /> */}

      {/* 
      <input onClick={()=>{
        console.log("Clicked")
      }} type="text" placeholder='Enter your name' /> */}

{/* 
      <input onChange={function (elem) {
        console.log(elem)
      }} type="text" placeholder='Enter your name' />


      <input onChange={function (elem) {
        console.log(elem.target)
      }} type="text" placeholder='Enter your name' />


      <input onChange={function (elem) {
        console.log(elem.target.value)
      }} type="text" placeholder='Enter your name' />

      <input onClick={function (elem) {
        console.log(elem.target)
      }} type="text" placeholder='Enter your name' /> */}

      {/* <input onChange={inputchanging()} type="text" placeholder='Enter your name' /> */}
      {/* <input onChange={inputchanging} type="text" placeholder='Enter your name' /> */}
      <input onChange={function(elem){
        inputchanging(elem.target.value)
      }} type="text" placeholder='Enter your name' />


    </div>
  )
}

export default App


