// var h2 = document.createElement('h2')
// // console.log(h2)
// h2.innerHTML = "hello from js";
// console.log(h2);
// document.body.appendChild(h2)

	// Default Export 
import abc from './app.js'
console.log(abc)

// Named Export 
import {username} from './app.js'
console.log(username)
