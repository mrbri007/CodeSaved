const arr = ['10','20'];

// Named Export 
export const username  = "brijesh"

// Default Export 
export default arr