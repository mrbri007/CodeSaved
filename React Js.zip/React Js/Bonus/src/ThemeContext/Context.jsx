import React from 'react'
import { useState } from 'react';
import { createContext } from 'react';

export const kendallJenner = createContext()

const Context = (props) => {

	const [theme, settheme] = useState('light')
	return (
		<div>
			{/* <kendallJenner.Provider value='Brijesh'> */}
			
			{/* <kendallJenner.Provider value={theme}> */}
			{/* <kendallJenner.Provider value={settheme}> */}
			<kendallJenner.Provider value={[theme, settheme]}>
				{props.children}
			</kendallJenner.Provider>
		</div>
	)
}
