import React from 'react'
import { useContext } from 'react'
import { kendallJenner } from '../ThemeContext/Context'

const Section2 = () => {

	// const first = useContext(kendallJenner)
	// console.log(first);

	const [theme, settheme] = useContext(kendallJenner)
	console.log(theme);

	return (
		<div className='nav2'>
			{/* <h1>This is {first}</h1> */}
			<h1>This is {theme}</h1>
		</div>
	)
}

export default Section2
