import React from 'react'
import Section2 from './Section2'
import { useContext } from 'react'
import { kendallJenner } from '../ThemeContext/Context'

export const Section1 = () => {

	const data = useContext(kendallJenner)
	console.log(data);

	const [theme] = useContext(kendallJenner)

	return (
		<div className={theme}>
			<h1>This is {data}</h1>
			<Section2 />
		</div>
	)
}
