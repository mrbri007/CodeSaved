import React from 'react'
import { useContext } from 'react';
import { kendallJenner } from '../ThemeContext/Context';

export const Button = () => {

	// const [theme] = useContext(kendallJenner)
	const [settheme] = useContext(kendallJenner)

	function btnclick(){
		// console.log("btn clciked");
		settheme('dark')
	}
	return (
		<div>
			<button onClick={btnclick}>Button: {theme}</button>
		</div>
	)
}
