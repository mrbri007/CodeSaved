import React from 'react'
import { Section1 } from './Components/Section1'
import { Button } from './Components/Button'

const App = () => {
  return (
    <div>
       <Section1 />
       <Button />
    </div>
  )
}

export default App
