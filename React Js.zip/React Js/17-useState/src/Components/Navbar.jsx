import React from 'react'
import { Navlinks } from './Navlinks'
import { useContext } from 'react'
import { ThemeDataContext } from '../Context/Themecontext'

// context API
const Navbar = (props) =>{
	// this is how you import and use the context
	const data = useContext(ThemeDataContext)
	console.log(data);
  return (
	<div>
		<h1>Models.com</h1>
		<h1>{data}</h1>
		<Navlinks b ={props.a}/>
	</div>
  )
}

// // props : object
// // this is called destrucing of array
// REMOVE PROPS 
// export const Navbar = ({children, a}) => {
// 	console.log(children);
// 	console.log(children[0]);
//   return (
// 	<div>
// 		<p>{children[0]}</p>
// 		<Navlinks b ={a}/>
// 	</div>
//   )
// }

// export const Navbar = (props) => {
// 	// console.log(props);
// 	// console.log(props.children);
// 	console.log(props.children[0]);
//   return (
// 	<div>
// 		<p>{props.children[0]}</p>
		// it will print -  <h2>Children Element</h2>  
// 		<Navlinks b ={props.a}/>
// 	</div>
//   )
// }
