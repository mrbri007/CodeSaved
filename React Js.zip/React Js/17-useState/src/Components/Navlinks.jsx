import React from 'react'
import { ThemeDataContext } from '../Context/Themecontext'
import { useContext } from 'react'

export const Navlinks = (props) => {
		const data = useContextontext(ThemeDataContextontext)
	
	return (
		<div>
			<ul>
				<li>Vogue Magzine</li>
				<li>Fashion Model</li>
				<li>Runway</li>
				<li>Photoshoot</li>
				<li>{props.b}</li>
				<li>{data}</li>
			</ul>
		</div>
	)
}
