import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { Themecontext } from './Context/Themecontext.jsx'

createRoot(document.getElementById('root')).render(

  // step 1 : themecontext wrap into app
  // Parents
  // child
  <Themecontext> 
    <App /> 
    <h2>Hello world</h2>
  </Themecontext>,
)
