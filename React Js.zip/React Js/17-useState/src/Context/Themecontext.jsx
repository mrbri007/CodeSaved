import React from 'react'
import { createContext } from 'react'

// we will send ThemeDataContext and anyone can import and use 
// this is how you create an CONTEXT
export const ThemeDataContext = createContext()
// ThemeDataContext - ye context provide karta haii

export const Themecontext = (props) => {
  return (
	<div>
		{/* this was previous methos {props.children} */}

		{/* Part 2  */}
		{/* this is how you are going to provide data it */}
		<ThemeDataContext.Provider value='Brijesh'>
			{props.children}
		</ThemeDataContext.Provider>
	</div>
  )
}
