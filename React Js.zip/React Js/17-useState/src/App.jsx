import React from 'react'
import { Navbar } from './Components/Navbar'
import { useState } from 'react'

const App = () => {

  const [theme, settheme] = useState('Light')
 
    return (
      <div>
        {/* <Navbar a={theme} /> */}

        {/* this is how you can pass element or data through children */}
        <Navbar a={theme}>
          <h2>Children Element</h2> 
          <h2>Children Element</h2>
          <h2>Children Element</h2>
          <h2>Children Element</h2>
        </Navbar>

        {/* it tells that components consist of any child element */}
        {/* In console log : you can check */}
        {/* one element : object */}
        {/* multiple element : array */}
      </div>
    )
}

export default App
