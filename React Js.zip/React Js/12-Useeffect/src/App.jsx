import React from 'react'
import { useState } from 'react';
import { useEffect } from 'react'

function App() {

	// function random(){
	// 	// console.log('hello world');
	// 	// const a = Math.random()
	// 	// console.log(a)
	// }
	// // random()

	const [num, setNum] = useState(0)
	const [num2, setNum2] = useState(10)

	// useEffect(function(){
	// 	console.log('Callback function');
	// })

	// useEffect(function(){
	// 	console.log('Callback function');
	// },[]) // dependency of array run at only one time

	// useEffect(function(){
	// 	console.log('Callback function');
	// },[num]) // dependency of array run at only one time
	// // },[num, num2]) // dependency of array run at only one time

	function achanging(){
		console.log("asgdjsahg")
	}

	useEffect(function(){
		achanging()
		// console.log('Callback function');
	},[num])

	// useEffect(function(){
	// 	achanging()
	// },[num])
	

  return (
	<div>
	  {/* <p>useEffect Hook in React </p> */}
	  <h4>A-Value: {num}</h4>
	  <h4>B-Value: {num2}</h4>
	  <button onClick={()=>{
		setNum(num+1)
	  }}>Click Me</button>
	  <button onClick={()=>{
		setNum2(num2+1)
	  }}>Click Me</button>
	</div>
  )
}

export default App
