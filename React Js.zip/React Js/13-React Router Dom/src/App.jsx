import React from 'react'
// import { Route, Routes } from 'react-router-dom'
import Home from './Pages/Home'
import About from './Pages/About'
import Contact from './Pages/Contact'
import Navbar from './Navbar'

function App() {
  return (
    <div>
      <h3>React Routung Dom</h3>
      {/* <a href="https://reactrouter.com/home">React Router Dom</a> */}
      <p>Run command: npm i react-router-dom</p>

        {/* // container - Routes and specific to the url - route */}

      {/* // it will show throughout the page */}
      <Navbar/>
      <Routes> 
          <Route path='/' element={<Home/>} />
          <Route path='/about' element={<About/>} />
          <Route path='/contact' element={<Contact/>} />
      </Routes>
      {/* // it will show throughout the page */}
      <h2>Footer Section</h2>


    </div>
  )
}

export default App
