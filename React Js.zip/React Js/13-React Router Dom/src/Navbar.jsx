import React from 'react'
import { Link } from 'react-router-dom'

const Navbar = () => {
	return (
		<div>
			<h2>Sheriyans Coding School</h2>
			<div>
				{/* .it will prevent reloading */}
				<Link to="/">Home</Link>
				<Link to="/about">About</Link>
				<Link to="/contact">Contact</Link>
			</div>
		</div>
	)
}

export default Navbar
