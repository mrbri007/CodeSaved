import './index.css'
import App from './App.jsx'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom' //import

createRoot(document.getElementById('root')).render(
  // set up like this
  <BrowserRouter>
    <App />
  </BrowserRouter> 
)
