import React from 'react'
import { Navbar } from './Components/Navbar'
import { useState } from 'react'

export const App = () => {

  const [theme, setTheme] = useState('light')
  return (
    <div>
      <h2>Context API</h2>
      <Navbar appstate = {theme}/>
    </div>
  )
}
