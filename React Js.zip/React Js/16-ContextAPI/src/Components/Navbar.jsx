import React from 'react'
import { Navlinks } from './Navlinks'

export const Navbar = (props) => {
  return (
	<div>
		<h2>Models.com</h2>
		<Navlinks navbartheme={props.appstate} />
	</div>
  )
}
