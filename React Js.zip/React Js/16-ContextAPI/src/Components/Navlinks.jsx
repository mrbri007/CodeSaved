import React from 'react'

export const Navlinks = (props) => {
  return (
	<div>
		<h1>hello world</h1>
		<h1>hello world</h1>
		<h1>hello world</h1>
		<h1>hello world</h1>
		<h1>hello world</h1>
		<h1>hello world</h1>
		<h4>{props.navbartheme}</h4>
	</div>
  )
}
