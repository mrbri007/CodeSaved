import React from 'react'

// You can name anything like props
function Card(props) {
	console.log(props.title, props.age)
	// console.log(props.title)
	// console.log(props.age)
  return (
	<div className='Parents'>
		<div className='child'>
			{/* <h1>Props Handling</h1> */}
			{/* <h1>{props.age}</h1> */}
			{/* <h1>{props.title}</h1> */}
			<h1>{props.title}, {props.age}</h1>
			<img src="https://images.unsplash.com/photo-1761839257658-23502c67f6d5?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" />
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odio, numquam?</p>
			<button>Learn More</button>
		</div>
	</div>
  )
}

export default Card
