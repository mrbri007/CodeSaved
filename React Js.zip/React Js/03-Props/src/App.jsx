import React from 'react'
import Card from './Components/Card'

function App() {
  return (
    <div>
      <Card title = "Kendall jenner" age={20}/>
      <Card title = "Dua lipa" age={25}/>
      <Card title = "Ana de armas" age={30}/>
    </div>
  )
}

export default App
