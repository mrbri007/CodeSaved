import React from 'react'
import Card from './Components/card'
import Navbar from './Components/Navbar'

// To print varibale values in HTML using {}
const a = "kendall jenner"
const b = 30

function App() {
  return (
    <div>
        <>
          {/* 
          <div>
            <h1>Card Componenets</h1>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptatem natus fugit iste dolores. At laudantium voluptatibus mollitia velit aut cumque!</p>
          </div>

          <p>Fahsion model {a}</p>
          <p>Fahsion model {b}</p> 
          */}

          {/* Compoenents based Architecture */}
          <Navbar/>
          <Navbar/>
          <Card />
          <Card />
        </>
    </div>
  )
}

export default App
