import React from 'react'

function card() {
  return (
	<div>
		<div className='card'>
			<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae sint nihil placeat iure facilis eos.</p>
		</div>
	</div>
  )
}

export default card
