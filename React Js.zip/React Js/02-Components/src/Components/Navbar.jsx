import React from 'react'

function Navbar() {
  return (
	<div>
		<div className='navbar'>
	  		<p>Navbar</p>
		</div>
	</div>
  )
}

export default Navbar
