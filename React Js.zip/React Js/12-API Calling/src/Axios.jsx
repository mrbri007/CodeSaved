import React from 'react'
import axios from 'axios'; // Import Axios
import { useState } from 'react';

function Axios() {

	// const getData = async () => {
	// 	// const response = await axios.get('https://jsonplaceholder.typicode.com/users')
	// 	// console.log(response);
	// 	// console.log(response.data); // get directly data

	// 	const {data} = await axios.get('https://jsonplaceholder.typicode.com/users')
	// 	console.log(data); // you can use this way : destructing array
	// }


	// const getData = async () => {
	// const response = await axios.get('https://picsum.photos/v2/list')
	// console.log(response);
	// console.log(response.data);  // array of object datatypes

	const [data, setdata] = useState([])

	const getData = async () => {
	const response = await axios.get('https://picsum.photos/v2/list')
	setdata(response.data);  // array of object datatypes
	

	 }

	return (
		<div>
			{/* <p>RUN command before using Axios mehthod : It is too easy</p> */}
			<p>npm i axios</p>
			<button onClick={getData}>Axios Method</button>
			{/* <a href="https://picsum.photos/"></a> */}


			{data.map(function(elem, idx){
				return <h1>hello {elem.author} {idx}</h1>
			})}
		</div>
	)
}

export default Axios
