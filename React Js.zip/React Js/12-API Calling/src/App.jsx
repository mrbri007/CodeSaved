import React from 'react'
import Axios from './Axios'

function App() {

  // function getData(){
  //   console.log("API connects both frontend and backend");
  //   const response  = fetch('https://jsonplaceholder.typicode.com/todos/1')

  //   // we are getting data in Promise methods like async mode
  //   console.log(response)
  // }
  // what we will do is use async and await method 
  // async function getData(){
  //                       // jab tak api call nhi hota tab tak wait 
  //      const response  = await fetch('https://jsonplaceholder.typicode.com/todos/1')
  //      console.log(response)
  // }

  const getData = async () => {
    const response = await fetch('https://jsonplaceholder.typicode.com/users') // 200 user data = 200 array in object
    // const response = await fetch('https://jsonplaceholder.typicode.com/todos') // 200 user data = 200 object
    // const response = await fetch('https://jsonplaceholder.typicode.com/todos/1')
    // console.log(response) // Api call ho gyi haii - response aa gya haii
    // console.log(response.json()) // reponse ka data json format haii and i want to get the json data and it is async then we will use async and await method

    const data = await response.json()
    console.log(data)

  }


  return (
    <div>
      {/* <p>API connect frontend and backend</p>
      <button onClick={getData}>Click Here</button>
      <a href="https://jsonplaceholder.typicode.com/"> JSON DATA </a> */}
      <Axios />
    </div>
  )
}

export default App
