import React from 'react'

const Navbar = (props) => {
 function changetheme(){
	props.b('dark')
 }

  return (
	<div>
	  <h1>Navbar Page</h1>
	  {/* <p>This is Props Driling [Navbar] : {props.theme}</p> */}
	  {/* <button onClick={()=>{
		props.b('Dark')
	  }}>UseState New Value</button> */}
	  <button onClick={changetheme}>UseState New Value</button>
	</div>
  )
}

export default Navbar
