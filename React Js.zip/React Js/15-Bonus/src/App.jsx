import React, { useState } from 'react'
import Navbar from './Navbar'

const App = () => {
  const [theme, settheme] = useState('light')

  return (
    <div>
      {/* <p>Bonus Topics: App.jsx </p> */}
      {/* <p>Select one p tag: Press Ctrl + Shift + L → selects ALL occurrences </p> */}
      <h1> App.jsx</h1>
      <p> UseState Value : {theme}</p>
      {/* we will pass data from top to bottom */}
      {/* <Navbar theme = {theme}/> */}

      {/* settheme ek function jo change karta haii useState ke variable ko */}
      {/* we will pass data from bottom to top */}
      <Navbar a={theme} b={settheme} />
    </div>
  )
}

export default App
