import React from 'react'

import Header from './Components/Header/Header'
import Button from './Components/Button/Button'

function App() {
  return (
    <div>
      <Header/>
      <Button/>
    </div>
  )
}

export default App
