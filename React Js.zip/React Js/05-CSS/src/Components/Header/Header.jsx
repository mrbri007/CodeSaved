import React from 'react'
import styles from './Header.module.css'

function Header() {
  return (
	<div className={styles.header}>
	  Lorem, ipsum dolor sit amet consectetur adipisicing elit. Illum, repellendus. Mollitia laborum iure esse et delectus rem doloribus quis, vero veniam! Minima cupiditate harum ea id natus neque praesentium recusandae, exercitationem itaque dolor. Aliquid blanditiis est sunt expedita harum, quia commodi similique quisquam impedit officiis eius vitae minima illo itaque?
	</div>
  )
}

export default Header
