import React from 'react'
import styles from './Button.module.css'


function Button() {
  return (
	<div className={styles.btn}>
	  Read More
	</div>
  )
}

export default Button
