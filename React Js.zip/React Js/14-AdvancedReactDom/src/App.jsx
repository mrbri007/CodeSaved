import React from 'react'
import { Navbar } from './Components/Navbar'
import { Footer } from './Components/Footer'
import Home from './Pages/Home'
import About from './Pages/About'
import Product from './Pages/Product'
import { Routes, Route } from 'react-router-dom'
import { NotFound } from './Pages/NotFound'
import Men from './Pages/Men'
import { Women } from './Pages/Women'
import { Kids } from './Pages/Kids'
import Course from './Pages/Course'
import { CourseDetails } from './Pages/CourseDetails'
import { History } from './Pages/History'

const App = () => {
  return (
    <div className='h-screen bg-[#111] text-white flex flex-col'>
      <Navbar />
      <History/>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/course" element={<Course />} />
        <Route path="/course/:courseID" element={<CourseDetails />} />
        {/* <Route path="/course/:id" element={<CourseDetails />} /> */}
        {/* <Route path="/course/:anyrandomtext" element={<CourseDetails />} /> */}
        {/* /course/adasdas- any random text - go to the above page */}

        {/* <Route path="/product" element={<Product />} /> */}
        {/* unknown URL */}
        <Route path="*" element={<NotFound />} />

        {/* Nested Url */}
        {/* <Route path="/product/Men" element={<Men />} /> */}

        {/* Best Pratcise */}
        <Route path="/product" element={<Product />}>
          <Route path="Men" element={<Men />} />
          <Route path="women" element={<Women />} />
          <Route path="kids" element={<Kids />} />
        </Route>

      </Routes>
      <Footer />
    </div>
  )
}

export default App
