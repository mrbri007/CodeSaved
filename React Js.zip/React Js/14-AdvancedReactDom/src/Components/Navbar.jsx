import React from 'react'
import { Link } from 'react-router-dom'

export const Navbar = () => {
	return (
		<div className='flex items-center justify-between px-8 py-4 text-xl font-mono w-full border-b-[.5px]'>
			<h2>MODELS.COM</h2>
			<div className='flex gap-8 uppercase '>
				{/* It will prevent relaoding */}
				<Link to="/">Home</Link>
				<Link to="/about">About</Link>
				<Link to="/contact">Product</Link>
				<Link to="/course">Course</Link>
			</div>
		</div>
  )
}
