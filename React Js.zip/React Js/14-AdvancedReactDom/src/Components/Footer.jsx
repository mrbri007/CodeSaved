import React from 'react'

export const Footer = () => {
  return (
    <div className='uppercase w-full flex items-center justify-center py-4 text-xl font-mono border-t-[.5px]'>
      <h2>Kendall Jenner</h2>
    </div>
  )
}
