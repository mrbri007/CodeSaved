import React from 'react'
import { Link, Outlet } from 'react-router-dom'

export const Product = () => {
  return (
	<div>
		<Link className='text-2xl' to='/product/men'>Men</Link>
		<Link className='text-2xl' to='/product/women'>Women</Link>
		<Link className='text-2xl' to='/product/kids'>Kids</Link>
		<Outlet/>
	</div>
  )
}
