import React from 'react'
import { useNavigate } from 'react-router-dom';

export const History = () => {

	const naviagetohomepage = useNavigate()
	return (
		<div>
			<button onClick={() => {
				naviagetohomepage('/')
			}}>Return to home page</button>
			<button onClick={() => {
				naviagetohomepage(-1)
			}}>Previous Page</button>
			<button onClick={() => {
				naviagetohomepage(+1)
			}}>Next Page</button>
		</div>
	)
}
