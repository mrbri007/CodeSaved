import React from 'react'

const Men = () => {
  return (
	<div>
	  <h1>New Collection</h1>
	</div>
  )
}

export default Men
