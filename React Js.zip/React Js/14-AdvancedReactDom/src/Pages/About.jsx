// import React from 'react'
// import { useNavigate } from 'react-router-dom';
// export const About = () => {
// 	const naviagetohomepage = useNavigate()
// 	const btnclicked = () => {
// 		naviagetohomepage('/')
// 	}
// return (
// 	<div>
// 		<h1>about</h1>
// 		<button onClick={btnclicked}>Return to home page</button>
// 	</div>
// )
// }

import React from 'react'
import { useNavigate } from 'react-router-dom';

export const About = () => {
	const naviagetohomepage = useNavigate()

	return (
		<div>
			<h1>about</h1>
			{/* new components */}

			{/* <button onClick={()=>{
			naviagetohomepage('/')
		}}>Return to home page</button>
		<button onClick={()=>{
			naviagetohomepage(-1)
		}}>Previous Page</button>
		<button onClick={()=>{
			naviagetohomepage(+1)
		}}>Next Page</button> */}
		</div>
	)
}


