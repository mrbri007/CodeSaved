import React from 'react'
import { useParams } from 'react-router-dom'

export const CourseDetails = () => {

	// url ke andar ka parameter de dega
	// course/hello
	// course/adjsahgdahgsdha
	// course/kuchbhilikhogetohprinthoga
	// console.log:
	// courseId : hello
	// courseID ek object haii containing Hello value

	const params = useParams()
	// console.log(params);
	// Dynamic routing
  return (
	<div>
		<h1>{params.courseID} : Page</h1>
	</div>

  )
}
