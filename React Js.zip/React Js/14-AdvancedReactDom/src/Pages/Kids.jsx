import React from 'react'

export const Kids = () => {
  return (
	<div>
		<h1>Kids</h1>
	</div>
  )
}
